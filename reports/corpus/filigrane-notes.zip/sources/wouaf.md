# WOUAF: Weight Modulation for User Attribution and Fingerprinting in Text-to-Image Diffusion Models (2023)

Identifiant arXiv 2306.04744, première version en juin 2023, troisième version du 24 avril 2024. Changhoon Kim, Kyle Min, Maitreya Patel, Sheng Cheng, Yezhou Yang, Arizona State University et Intel Labs. Publié à CVPR 2024. Code public : https://github.com/kylemin/WOUAF, et une démo HuggingFace financée par Intel.

## 1. L'apport en trois phrases

WOUAF déplace le fingerprint du message vers les poids : chaque utilisateur reçoit un décodeur VAE de Stable Diffusion dont les canaux de sortie sont multipliés par un facteur affine dérivé de sa clé, si bien qu'aucun fine-tuning n'est nécessaire à l'attribution. Le distributeur entraîne une fois un réseau de mapping et un décodeur, puis génère un modèle par utilisateur en un passage avant, ce qui fait passer le coût d'attribution de plusieurs dizaines de minutes à moins d'une seconde. Le papier revendique 0,99 d'exactitude sans dégrader le FID, et 11 % de robustesse de plus que Stable Signature sur les post-traitements.

## 2. Méthode, équations et hyperparamètres réellement donnés

Le cadre est celui de Stable Diffusion : un autoencodeur $(E, D)$ et un U-Net $\epsilon_\theta$. La clé utilisateur est un vecteur binaire $\phi \in \{0,1\}^{d_\phi}$ tiré selon $\mathrm{Bernoulli}(0,5)$. Un réseau de mapping $M : \mathbb{R}^{d_\phi} \to \mathbb{R}^{d_M}$ la transforme en une représentation intermédiaire, puis une couche affine $A_l$ par couche du décodeur produit une échelle par canal de sortie. La modulation s'écrit, pour la couche $l$ et le canal de sortie $j$,

$$\phi W_{i,j,k} = u_j \cdot W_{i,j,k}, \quad u_j = A_l(M(\phi)),$$

et n'est appliquée qu'au décodeur $D$ de l'autoencodeur, pas au U-Net. Section 4.5 : moduler aussi $\epsilon_\theta$ détruit la qualité, cette variante plafonnant à 89 % d'exactitude pour un FID de 63,48.

Deux pertes. La première est une entropie croisée binaire sur les $d_\phi$ bits, calculée sur l'image reconstruite :

$$\mathcal{L}_\phi = \mathbb{E}_{z=E(x),\,\phi \sim \Phi}\left[\sum_{i=1}^{d_\phi} \phi_i \log \sigma(F(D(\phi,z))_i) + (1-\phi_i)\log(1-\sigma(F(D(\phi,z))_i))\right],$$

où $F$ est un ResNet-50 qui décode le fingerprint. La seconde est une perte de qualité perceptuelle $\mathcal{L}_{quality} = \mathbb{E}[\ell(x, D(\phi,z))]$, avec $\ell$ la distance LPIPS. La version robuste ajoute une troisième perte, $\mathcal{L}_{robust}$, identique à $\mathcal{L}_\phi$ mais appliquée à $T(D(\phi,z))$, où $T$ est une composition aléatoire de post-traitements différentiables implémentés avec Kornia.

Hyperparamètres réellement donnés : $d_\phi = 32$ par défaut, $d_M = 4 d_\phi$, réseau de mapping à deux couches, 50 000 itérations, taille de lot 32, taux d'apprentissage $10^{-4}$ avec AdamW, modulateur de poids repris de StyleGAN2-ADA, Euler avec $T = 20$ pas et guidance 7,5, fine-tuning sur le split Karpathy de MS-COCO. La capacité annoncée est de plus de 4 milliards de fingerprints, soit $2^{32}$, et le seuil d'attribution sur une base d'un million d'entrées est fixé à $32 \times 0,95 \approx 30$ bits.

Les huit post-traitements d'entraînement sont donnés : effacement de 5 à 20 %, rotation dans $(-30°, 30°)$, flou de noyau 3, 5 ou 7, recadrage de 5 à 20 %, luminosité dans $(-0,3, 0,3)$, bruit gaussien d'écart type uniforme sur $[0, 0,2]$, JPEG de 90 à 50, et une combinaison aléatoire des sept avec probabilité 0,5.

## 3. Protocole et métriques

Trois mesures. L'exactitude d'attribution est la proportion de bits corrects, $\frac{1}{d_\phi}\sum_i \mathbf{1}(\phi_i = \hat{\phi}_i)$, sur MS-COCO test et un tirage de LAION-Aesthetics, deux jeux exclus de l'entraînement. La qualité est le FID et le CLIP-score. Le coût est le temps de génération d'un modèle utilisateur, comparé à DAG (8,4 heures) et Stable Signature (moins d'une minute).

Deux variantes : WOUAF-conv, qui module les seules couches convolutives, et WOUAF-all, qui module aussi l'auto-attention. La robustesse est tracée en courbes (figure 5) sur huit post-traitements en balayant l'intensité, pas en tableau de valeurs uniques, ce qui complique la comparaison avec les autres papiers. L'attribution croisée teste 1 000 images MS-COCO authentiques, 1 000 Stable Diffusion non fingerprintées et 1 000 ProGAN, StyleGAN, StyleGAN2.

## 4. Résultats chiffrés

Tableau 1, MS-COCO. Stable Diffusion original : CLIP 0,73, FID 24,48. DAG : attribution 0,70, 8,4 heures, FID 26,54. Stable Signature : 0,99 en moins d'une minute, FID 24,55. WOUAF-conv : 0,99 en moins d'une seconde, FID 24,43. WOUAF-all : 0,99, moins d'une seconde, FID 24,42, CLIP 0,73. Sur LAION, WOUAF-all atteint 0,99 d'attribution pour un FID de 19,91, contre 20,02 pour Stable Signature et 19,67 pour le modèle original.

Section 4.4, attribution croisée : aucune image d'une autre source n'est attribuée à tort à une entrée de la base d'un million. C'est un résultat de faux positifs, rare ici, et il vaut d'être noté.

Section 4.6 et figure 5 : l'amélioration moyenne d'exactitude d'attribution est de 11 % sur Stable Signature et de 29 % sur DAG, sur l'ensemble des huit post-traitements. La dégradation reste monotone avec l'intensité de l'attaque, ce qui est le comportement attendu.

Section 5.1, attaque par classifieur : un ResNet-50 entraîné sur 10 000 images (5 000 originales, 5 000 fingerprintées) atteint 98 % en entraînement, puis seulement 0,66 sur WOUAF-conv et 0,56 sur WOUAF-all en test, soit le hasard. La signature est donc difficile à détecter, ce qui est un argument de confidentialité, pas de sécurité cryptographique.

Section 5.2 et 5.3, figure 6 : les autoencodeurs font chuter l'attribution vers 50 % à mesure que la compression augmente, et la purification par fine-tuning aussi, mais au prix d'une dégradation visible. C'est une courbe de compromis : l'attaquant qui accepte de perdre en qualité gagne en anonymat.

## 5. Ce que les papiers de Fernandez reprennent ou contredisent

WOUAF est le concurrent direct que Fernandez cite cinq fois, et la comparaison est explicite dans les deux sens. Même point de départ : Stable Signature fine-tune un décodeur par utilisateur pendant une minute, WOUAF obtient 0,99 en moins d'une seconde par un passage avant. Sur le déploiement, l'avantage est net et Fernandez ne le conteste pas : `sources-et-citations.md` le range parmi les concurrents directs.

La contradiction porte sur deux axes. D'abord la qualité : WOUAF-all obtient un FID de 24,42 sur MS-COCO, soit mieux que le Stable Diffusion original à 24,48 et mieux que Stable Signature à 24,55, alors que `stable-signature.md` revendique 24,55 comme équivalent à l'original. L'écart est faible, mais il est en faveur de WOUAF et il est mesuré sur le même jeu.

Ensuite la robustesse : WOUAF revendique +11 % en moyenne sur les post-traitements et affirme dépasser Stable Signature dans presque tous les scénarios de la figure 5. `stable-signature.md` ne rapporte pas cette comparaison. Un jury peut donc opposer à Fernandez une supériorité revendiquée et non réfutée sur son propre terrain.

Ce que Fernandez reprend : la structure générale du fingerprinting par utilisateur, la clé binaire tirée à 0,5, et surtout la mesure d'exactitude d'attribution sur une base de taille réaliste. Il s'en écarte sur un point décisif, l'accès au modèle. WOUAF suppose que le distributeur contrôle le décodeur et peut livrer un modèle par utilisateur, ce qui est impossible avec une API fermée. C'est précisément l'argument que Fernandez développe dans `wam.md` et dans `across-modalities.md` pour justifier le watermark post-hoc, et c'est la faille que le jury peut exploiter dans l'autre sens : un fingerprint dans les poids ne protège que les modèles ouverts.

Dernier point, méthodologique. WOUAF mesure l'attribution en exactitude de bits et fixe un seuil à 30 bits sur 32, sans courbe TPR/FPR. VINE montre, tableau 1, que cette mesure surestime la détectabilité : SSL affiche une bonne exactitude avec un TPR@0,1 % de 1,76 % après régénération. Le reproche vaut aussi pour WOUAF, qui ne publie pas de TPR à FPR fixé.

## 6. Réutilisable en 24 h

La modulation de poids est la brique la plus copiable : une couche affine par couche du décodeur et un produit canal par canal, quelques dizaines de lignes. L'usage le plus rapide n'est pas de réentraîner Stable Diffusion, c'est de greffer la modulation sur un décodeur existant et de changer de clé sans réentraîner.

Deuxième usage, l'attaque de détection : entraîner un petit classifieur binaire sur des paires d'images fingerprintées et non fingerprintées, puis mesurer s'il retrouve le watermark. Le papier obtient 0,56 à 0,66, point de départ honnête pour une épreuve de stealthiness en une heure, et l'expérience est décrite assez précisément pour être reproduite.

Troisième usage, le coût d'attribution : la comparaison 8,4 heures, une minute, une seconde est un argument de pitch, et elle se vérifie sans GPU.

Piège principal, la confusion des rôles. WOUAF n'est pas un watermark de contenu mais un fingerprint de modèle : il répond à « quel utilisateur a généré cette image », pas à « cette image est-elle générée ». Toute comparaison de PSNR avec Tree-Ring ou InvisMark est donc biaisée, puisque WOUAF modifie le décodeur, pas l'image. Le second piège est le coût du pré-entraînement : le dépôt `kylemin/WOUAF` fournit le code d'entraînement et de modulation, pas un modèle Stable Diffusion déjà fingerprinté, et une équipe qui veut une démo en 24 h doit se contenter de la modulation sur un décodeur existant.
