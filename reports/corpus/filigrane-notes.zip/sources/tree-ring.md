# Tree-Ring Watermarks: Fingerprints for Diffusion Images that are Invisible and Robust (2023)

Identifiant arXiv 2305.20030, troisième version du 4 juillet 2023. Yuxin Wen, John Kirchenbauer, Jonas Geiping, Tom Goldstein, University of Maryland. Publié à NeurIPS 2023. Code et poids de démonstration : https://github.com/YuxinWenRick/tree-ring-watermark.

## 1. L'apport en trois phrases

Tree-Ring déplace le watermark du pixel vers le bruit initial du modèle de diffusion : au lieu de modifier l'image après génération, il impose une structure dans la transformée de Fourier du tenseur de bruit $x_T$, puis laisse la génération se dérouler normalement. La détection inverse le processus par DDIM pour retrouver un bruit approché et mesure la distance entre ce bruit et la clé dans un masque annulaire de basse fréquence, ce qui donne une p-value exacte et non une simple exactitude de bits. Le résultat est un watermark sans entraînement, invisible par construction, et robuste aux manipulations géométriques qui détruisent les méthodes par résidu.

## 2. Méthode, équations et hyperparamètres réellement donnés

Le point de départ est le constat que la transformée de Fourier d'un bruit gaussien est encore un bruit gaussien. L'embedder choisit donc un masque $M$ et une clé $k^* \in \mathbb{C}^{|M|}$, et construit le bruit initial tel que

$$F(x_T)_i \sim \begin{cases} k^*_i & \text{si } i \in M \\ \mathcal{N}(0,1) & \text{sinon} \end{cases}$$

Le masque $M$ est un disque de rayon $r$ centré sur les basses fréquences. Trois familles de clés. Tree-RingZeros met des zéros dans le disque, d'où l'invariance maximale aux translations, recadrages et dilatations, mais s'éloigne d'une gaussienne et interdit plusieurs clés. Tree-RingRand tire la clé d'une gaussienne, ce qui préserve la distribution au prix de la rotation. Tree-RingRings impose une valeur constante par anneau, invariant par rotation et proche d'un gaussien isotrope. C'est la variante recommandée.

La détection commence par l'inversion DDIM, $x'_T = D^\dagger_\theta(x'_0)$, avec un prompt vide puisque le texte de génération est inconnu du détecteur. Le score est

$$\eta = \frac{1}{\sigma^2}\sum_{i \in M}|k^*_i - y_i|^2, \quad y = F(x'_T), \quad \sigma^2 = \frac{1}{|M|}\sum_{i \in M}|y_i|^2,$$

et sous $H_0$ cette statistique suit une loi du chi-deux non centrée à $|M|$ degrés de liberté et de paramètre de non-centralité $\lambda = \frac{1}{\sigma^2}\sum_i |k^*_i|^2$. La p-value est donc

$$p = \Phi_{\chi^2}(z),$$

évaluable avec `scipy.stats.ncx2`. C'est un vrai test statistique, donc le taux de faux positifs se fixe par avance et pas par seuillage empirique.

Hyperparamètres réellement donnés : rayon $r = 10$ dans l'expérience principale, 50 pas d'inférence pour la génération et pour la détection, guidance 7,5, DDIM sans bruit ajouté, prompt vide à l'inversion. L'ablation sur le rayon conclut qu'un rayon de 16 offre le meilleur compromis entre FID et détection, ce qui contredit légèrement le réglage principal et mérite d'être noté. Aucun entraînement, aucun fine-tuning, un seul GPU RTX A4000 pour toutes les expériences. Le papier ne donne pas de dimension de tenseur explicite, seulement que les modèles testés sont Stable Diffusion v2 en latent et un modèle ImageNet en pixels.

## 3. Protocole et métriques

Deux modèles : Stable Diffusion v2, évalué sur des prompts MS-COCO 2017, et un modèle de diffusion conditionnel ImageNet-1k. Les métriques de détection sont l'aire sous la courbe ROC et le TPR à 1 % de FPR, calculés sur 1 000 images marquées et 1 000 images non marquées par exécution, moyennés sur cinq graines. La qualité est mesurée par le FID sur 5 000 images pour Stable Diffusion et 10 000 pour ImageNet, plus le score CLIP OpenCLIP-ViT/G pour la fidélité au prompt.

Six attaques sont appliquées : rotation de 75 degrés, JPEG de qualité 25, recadrage aléatoire à 75 % avec remise à l'échelle, flou gaussien de noyau $8\times8$, bruit gaussien $\sigma = 0,1$, et color jitter avec un facteur de luminosité tiré uniformément entre 0 et 6. Trois baselines : DwtDct, DwtDctSvd, dont la méthode déployée dans Stable Diffusion, et RivaGAN. Ce sont des méthodes de stéganographie, donc comparées en exactitude de bits, ce qui est une limite de protocole assumée.

## 4. Résultats chiffrés

Tableau 1, Stable Diffusion, FID du modèle original 25,29 et score CLIP 0,363. Tree-RingRings atteint 1,000 d'AUC et 1,000 de TPR@1% en propre, 0,975 et 0,694 en moyenne adversariale, pour un FID de 25,93 et un CLIP de 0,364. Tree-RingZeros fait 0,963 et 0,715 en adversariale pour un FID de 26,56, Tree-RingRand 0,918 et 0,702 pour 25,47. Les baselines s'effondrent : RivaGAN 0,854 et 0,448, DwtDctSvd 0,702 et 0,262, DwtDct 0,574 et 0,092.

Tableau 2, détail par attaque, AUC pour Tree-RingRings : 1,000 en propre, 0,935 en rotation 75 degrés, 0,999 en JPEG 25, 0,961 en recadrage et remise à l'échelle, 0,999 en flou, 0,944 en bruit, 0,983 en color jitter. Tree-RingRand confirme la prédiction théorique et tombe à 0,486 en rotation, tandis que Tree-RingZeros tombe à 0,877 en bruit et 0,907 en color jitter. Sur ImageNet (tableau 4 et tableau 1), Tree-RingRings obtient 0,966 et 0,603 en adversariale, contre 0,882 et 0,509 pour RivaGAN.

Figure 3, exemples de p-values : 0,27 sur une image non marquée, $3{,}73\times10^{-60}$ sur la même image marquée, $7{,}41\times10^{-16}$ après color jitter de facteur 6, $1{,}51\times10^{-8}$ après flou $8\times8$, $2{,}90\times10^{-5}$ après bruit $\sigma=0,1$. La p-value reste donc interprétable après attaque, ce qui est rare dans la littérature.

Ablation sur le rayon (figure 6a) : la robustesse monte avec $r$, la qualité baisse, et le compromis retenu est $r=16$. Figure 7 : le watermark tient encore sous flou gaussien de noyau 40, ce qui est une attaque très forte.

## 5. Ce que les papiers de Fernandez reprennent ou contredisent

C'est la famille que Fernandez présente comme opposée à la sienne. Dans `sources-et-citations.md`, Tree-Ring est cité quatre fois comme « l'approche sémantique, dans le sampling ». La contradiction est structurelle et se lit en trois endroits.

Premièrement, la détectabilité. Tree-Ring exige les poids du modèle pour inverser, donc seul le propriétaire peut vérifier. Fernandez construit tout son programme sur le contraire : WAM, Stable Signature, DistSeal et Video Seal publient un extracteur qu'un tiers peut exécuter. `public-detection.md` va jusqu'à découper la clé en partie publique et partie privée. Un jury peut donc opposer à Tree-Ring qu'il n'est pas déployable par un régulateur, et opposer à Fernandez que son détecteur public est attaquable par construction.

Deuxièmement, la robustesse géométrique. `syncseal.md` mesure Tree-Ring à 0,39 d'exactitude binaire moyenne sur sa grille de transformations, et à 0,94 en rotation 30 degrés, mais le papier note qu'il tombe sur une simple translation, ce qui est cohérent avec la théorie de Fourier puisque la translation multiplie les coefficients par une phase. SyncSeal le remonte à 0,88 de moyenne. C'est la seule comparaison chiffrée directe entre les deux camps, et elle est défavorable à Tree-Ring en moyenne, la rotation restant son point fort.

Troisièmement, la sensibilité aux éditions génératives. VINE (W-Bench) ne teste pas Tree-Ring, qui ne figure pas dans sa liste de onze méthodes, mais il montre que la régénération stochastique ramène SSL, la méthode de Fernandez 2022, à 1,76 % de TPR@0,1 % et la régénération déterministe à 9,70 %. Un watermark de basse fréquence dans le bruit initial n'a pas été évalué sur ce banc, et c'est un trou que le jury peut exploiter dans les deux sens.

Ce qui est repris : la p-value comme sortie du détecteur. Fernandez l'utilise partout, dans Three Bricks, TextSeal, et dans le test binomial de Stable Signature. Tree-Ring est l'un des premiers papiers d'image à faire de la détection un test statistique plutôt qu'un seuil sur une exactitude de bits, et c'est probablement son héritage méthodologique le plus durable.

## 6. Réutilisable en 24 h

Le dépôt `YuxinWenRick/tree-ring-watermark` est public, avec des notebooks pour Stable Diffusion v1.5, v2.1 et un modèle ImageNet. Une inversion DDIM sur 50 pas coûte quelques secondes par image, trop pour du volume, assez pour une démonstration.

Trois usages concrets. Premier, la calibration du FPR : le code de p-value avec `scipy.stats.ncx2` se réimplémente en vingt lignes, et il donne un détecteur honnête, avec un seuil choisi et pas ajusté. C'est la brique à copier si l'épreuve demande de comparer des détecteurs à FPR fixé. Deuxième, l'attaque la moins chère contre Tree-Ring : une translation de quelques pixels, ou un recadrage décalé, fait chuter l'AUC à 0,486 dans la variante Rand et coûte presque zéro en PSNR, ce qui est une démonstration de fragilité en quelques minutes. Troisième, le masque annulaire lui-même : imposer une structure sur les basses fréquences du bruit initial est une ligne de code dans n'importe quel pipeline de diffusion, et c'est le point d'entrée le plus rapide pour une piste « watermark dans le sampling ».

Deux pièges. Le rayon : $r=10$ dans les tableaux, $r=16$ recommandé en ablation, et les chiffres ne sont pas comparables entre les deux. L'inversion : sans le bon nombre de pas et sans prompt vide, la p-value dérive, et un détecteur mal réglé produit des faux positifs sur des images naturelles, que la figure 4 montre proches d'un gaussien sans l'être exactement.
