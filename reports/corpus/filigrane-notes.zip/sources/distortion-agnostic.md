# Distortion Agnostic Deep Watermarking (2020)

Identifiant arXiv 2001.04580. Xiyang Luo, Ruohan Zhan, Huiwen Chang, Feng Yang, Peyman Milanfar. Google Research et Stanford University, travail réalisé pendant un stage chez Google. Soumis le 13 janvier 2020, publié à CVPR 2020.

## 1. Ce que le papier apporte historiquement

C'est le premier travail qui pose explicitement la question de la généralisation hors distribution pour le watermarking profond : les méthodes de l'époque, HiDDeN et ReDMark en tête, modélisent les distorsions à l'entraînement et se spécialisent, ce qui donne un beau diagonal quand on croise transformations d'entraînement et transformations de test. La réponse proposée consiste à ne modéliser aucune distorsion, et à tirer la robustesse de deux sources indépendantes : un réseau adverse qui apprend à produire les pires perturbations, et un code correcteur de canal qui ajoute de la redondance. Le résultat est une meilleure moyenne sur des transformations jamais vues, en particulier sur les changements de couleur, ce qui déplace le critère d'évaluation de l'exactitude binaire vers la stabilité entre familles.

## 2. Méthode, équations et hyperparamètres

Le système reprend l'encodeur et le décodeur de HiDDeN et ajoute deux composants : un code de canal avant l'encodeur, et un réseau d'attaque entre l'encodeur et le décodeur.

Formulation. Le problème visé est un min-max sous contrainte de norme :

$$\min_{\Theta_{enc},\Theta_{dec}}\max_{\|\delta\|_2\leq\epsilon}\left\{L_M\left(F_{dec}\left(F_{enc}(I_{co};\Theta_{enc})+\delta;\Theta_{dec}\right),X\right)\right\}.$$

Comme l'optimisation directe est coûteuse et trop restrictive, la perturbation est restreinte à la sortie d'un réseau convolutif :

$$\min_{\Theta_{enc,dec}}\max_{\{\|G_{adv}(I_{en})-I_{en}\|\leq\epsilon\}}\left\{L_M\left(F_{dec}(G_{adv}(I_{en}));X\right)\right\}.$$

Le réseau d'attaque est volontairement petit, deux couches :

$$G_{adv}(I)=\mathrm{Conv}_3\circ\mathrm{LeakyReLU}\circ\mathrm{Conv}_{16}(I).$$

Sa perte est

$$L_{adv}=\alpha^{adv}_1\|I_{adv}-I_{en}\|^2-\alpha^{adv}_2 L_M(F_{dec}(I_{adv});X),$$

où le premier terme limite la force de la distorsion et le second récompense la destruction du message. Les auteurs notent que le compromis entre les deux poids et la taille du réseau d'attaque est le point délicat : une attaque trop forte empêche l'encodeur de s'adapter, une attaque trop simple ne produit pas de robustesse. Ils testent aussi une variante résiduelle avec connexion de saut et une variante plafonnée $G_{adv}(I)=I+\epsilon\tanh(\mathrm{CNN}(I))$.

Perte du watermark. L'image : $L_I=\alpha^I_1\|I_{co}-I_{en}\|^2+\alpha^I_2 L_G(I_{en})$, avec une perte GAN et normalisation spectrale pour la qualité perceptuelle. Le message : $L_M=\alpha^M\|X'_{dec}-X'\|^2$. L'objectif complet :

$$L_W=L_I+L_M+\alpha^{adv}_W\|X'_{adv}-X'\|^2.$$

Code de canal. Un message $X\in\{0,1\}^D$ est transformé en $X'\in\{0,1\}^N$ avec $N>D$, puis décodé après réception bruitée. Le canal est modélisé comme un canal binaire symétrique, chaque bit étant retourné indépendamment avec probabilité $p$, ce qui n'est pas exact mais fonctionne empiriquement. Le code utilisé est NECST, un modèle appris de codage conjoint source canal, choisi parce que les codes classiques comme LDPC exigent une estimation du niveau de bruit, impossible ici. Le modèle de canal est entraîné séparément, avec un niveau de bruit tiré uniformément dans $[0,\text{maxstrength}]$, et n'est jamais entraîné conjointement avec le watermark, pour éviter la coadaptation.

Réglages. $D=30$ bits de message utile, $N=120$ bits transmis à l'encodeur, images COCO redimensionnées à $128\times128$, 3 000 images d'évaluation. L'architecture est celle de HiDDeN, seule la taille du message embarqué change, de 30 à 120.

## 3. Protocole et métriques

Deux baselines HiDDeN : le modèle identité, sans distorsion, et le modèle combiné, entraîné sur JPEG qualité 50, dropout 0,3, crop 0,3 et flou gaussien $\sigma=1,0$, avec le proxy JPEG différentiable. Cinq modèles spécialisés, un par distorsion, servent à montrer le diagonal. Les distorsions de test sont séparées en connues, celles du modèle combiné, et inconnues, six familles choisies pour couvrir couleur, bruit, géométrie et compression : saturation, teinte, redimensionnement, bruit gaussien, sel et poivre, encodage GIF, chacune à trois intensités. Métriques : exactitude binaire et PSNR, en RGB et en YUV. Les modèles sont ajustés pour avoir un PSNR légèrement supérieur au modèle combiné, afin que la comparaison ne soit pas biaisée par la qualité.

## 4. Résultats chiffrés

Qualité (tableau 1). PSNR RGB : identité 40,3 dB, combiné 32,3, méthode proposée 33,7. En Y : 47,5, 34,2, 35,7.

Distorsions connues (figure 1 et figure 7). Le modèle proposé est comparable au combiné sur crop et dropout, meilleur sur JPEG, moins bon sur le flou gaussien. Les modèles spécialisés montrent un diagonal net, donc une généralisation faible. Sur les petites intensités, l'écart avec le combiné est quasi nul.

Distorsions inconnues (tableau 2). Moyenne sur les 18 conditions, les scores sous 50 % étant ramenés à 50 % : identité 78,37 %, combiné 84,26 %, proposé 88,30 %. Détail parlant : bruit gaussien 0,10, 63,2 / 80,4 / 89,5 ; teinte 0,2, 65,1 / 70,8 / 94,0 ; teinte 0,4, 34,0 / 45,3 / 70,7 ; saturation 15,0, 93,4 / 94,2 / 98,5 ; GIF 16, 65,0 / 88,6 / 91,7 ; redimensionnement 0,5, 66,5 / 67,3 / 67,1. Le gain se concentre sur la couleur et le bruit additif ; le redimensionnement reste un mur, et le sel et poivre est légèrement défavorable, 77,1 contre 79,6 à 0,15.

Ablation (tableau 3). Exactitude pour identité seule, code de canal seul, adversaire seul, les deux : JPEG 50, 50,2 / 51,3 / 85,0 / 81,7 ; crop 0,09, 53,0 / 60,5 / 90,6 / 93,5 ; flou 1,0, 59,6 / 50,2 / 86,2 / 92,8 ; dropout 0,3, 81,3 / 90,3 / 95,0 / 97,9. Deux lectures. L'adversaire porte l'essentiel du gain. Le code de canal seul ne suffit pas, et combiné à l'adversaire il aide surtout quand l'exactitude est déjà haute, avec un cas contradictoire sur JPEG où l'adversaire seul fait mieux, 85,0 contre 81,7.

Complexité de l'attaque (tableau 4). Le passage de $\mathrm{Conv}(3,16)$ à $\mathrm{Conv}(3,32,32)$ dégrade le JPEG de 81,7 à 75,0 et le flou de 92,8 à 81,5 : une attaque plus puissante n'aide pas, elle déstabilise. La variante résiduelle donne 84,5 en JPEG et 86,3 en flou. La variante plafonnée s'effondre à 57,3 en JPEG. FGSM, testé comme alternative, donne 50,1 en JPEG et 50,1 en flou, donc un échec complet par sur-apprentissage de l'attaque.

## 5. Ce que Fernandez reprend, ce qu'il change

Ce papier est cité quatre fois dans le corpus, et il est le représentant de la thèse « ne pas modéliser la distorsion ». Fernandez en garde l'idée générale mais en rejette la mécanique.

Ce qui est repris. Tous ses modèles entraînent avec des pools d'augmentations tirées au sort plutôt qu'avec une distorsion calée sur un scénario de déploiement. WAM regroupe explicitement les transformations en familles, Video Seal en cinq familles avec des intensités balayées, SyncSeal en trois transformations géométriques et deux valuémétriques par image. La leçon du tableau 2, à savoir que la variance entre familles compte autant que la moyenne, est devenue un mode d'évaluation standard, avec des tableaux par famille plutôt qu'un score agrégé.

Ce qui est changé. Premièrement, pas de réseau adverse séparé : les augmentations sont fixes et différentiables, ce qui est moins cher et plus stable, et évite le problème du tableau 4 où une attaque trop complexe dégrade le résultat. Deuxièmement, pas de code de canal NECST : la redondance est obtenue autrement, par répétition spatiale, par code BCH quand il est utilisé, ou par le fait même d'un message court protégé par un test statistique. TrustMark indique explicitement qu'un BCH pourrait corriger les quelques bits faux mais ne l'applique pas dans ses résultats. Troisièmement, la métrique change : Fernandez ne publie pas seulement l'exactitude binaire mais des p-values calibrées et des TPR à FPR fixé, ce qui rend visible ce que l'exactitude cache, à savoir qu'un score de 0,9 sur 30 bits et un score de 0,9 sur 256 bits n'ont pas la même valeur de preuve.

Il faut noter que SSL latent compare directement Distortion Agnostic sur COCO $128\times128$, 30 bits à 33 dB, en BER : 0,00 en identité, 0,18 en JPEG, 0,07 en flou, 0,02 en recadrage, 0,12 en redimensionnement, 0,06 en teinte. HiDDeN donne 0,00, 0,23, 0,01, 0,00, 0,15, 0,29. Distortion Agnostic gagne donc sur JPEG, la teinte et le redimensionnement, perd sur le flou et le recadrage. C'est cohérent avec son profil.

## 6. Réutilisable en 24 h

Le code n'est pas publié, mais les deux briques se réimplémentent séparément.

Première brique, le réseau d'attaque de deux couches. Une variante de dix lignes, $\mathrm{Conv}3$ puis LeakyReLU puis $\mathrm{Conv}16$, s'insère entre encodeur et décodeur, avec la perte $L_{adv}$ et une alternance une mise à jour sur deux. C'est un moyen rapide de tester si une attaque apprise bat un pool d'augmentations fixes sur un modèle donné. Le résultat du papier suggère de commencer petit : une attaque large et profonde est contre-productive.

Deuxième brique, le protocole hors distribution : transformations connues et inconnues, trois intensités par famille, moyenne tronquée à 50 %. Reproductible en une heure, c'est le meilleur garde-fou contre l'auto-illusion.

Le piège principal est le canal binaire symétrique. Il l'utilise comme approximation et le reconnaît : les erreurs d'un watermark ne sont pas indépendantes entre bits, elles sont corrélées spatialement, un crop détruit des blocs entiers. Un code de canal calibré sur un BSC surestime donc sa capacité de correction dans les cas réels de recadrage. Pour un hackathon, mieux vaut une redondance explicite par zones, comme WAM, qu'un code appris sur un modèle de bruit faux.
