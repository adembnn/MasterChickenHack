# InvisMark: Invisible and Robust Watermarking for AI-generated Image Provenance (2024)

Identifiant arXiv 2411.07795, deuxième version du 19 novembre 2024. Rui Xu, Mengya Hu, Deren Lei, Yaxi Li, David Lowe, Alex Gorevski, Mingyu Wang, Emily Ching, Alex Deng, Microsoft Responsible AI. Accepté à WACV 2025 selon le commentaire arXiv, mais le papier ne publie ni code ni poids, cohérent avec un document d'ingénierie produit.

## 1. L'apport en trois phrases

InvisMark est la réponse industrielle de Microsoft au watermark d'image haute résolution : 256 bits, dont un UUID de 128 bits protégé par un code BCH, dans des images de 2K et plus, avec 51,4 dB de PSNR moyen qui écrase les baselines. La méthode combine un encodeur MUNIT, un décodeur ConvNeXt-base et une optimisation robuste qui sélectionne les pires transformations toutes les 200 itérations. Son intérêt n'est pas la nouveauté architecturale mais le réalisme du protocole : deux jeux de 900 images, des transformations fortes, et une attaque de falsification assumée que les autres passent sous silence.

## 2. Méthode, équations et hyperparamètres réellement donnés

Cadre classique : encodeur $E$, décodeur $D$, message $\omega \in \{0,1\}^l$, image marquée $\tilde{x} = E(x,\omega)$, extraction $\tilde{\omega} = D(\tilde{x})$. Perte :

$$\mathcal{L} = \alpha_q \mathcal{L}_q(x,\tilde{x}) + \alpha_r \mathcal{L}_r(\omega,\tilde{\omega}),$$

avec une perte de qualité en quatre termes,

$$\mathcal{L}_q = \beta_{YUV}\mathcal{L}_{YUV} + \beta_{LPIPS}\mathcal{L}_{LPIPS} + \beta_{FFL}\mathcal{L}_{FFL} + \beta_{GAN}\mathcal{L}_{GAN},$$

avec $\mathcal{L}_{YUV}$ l'erreur quadratique moyenne en YUV, $\mathcal{L}_{LPIPS}$ la similarité perceptuelle, $\mathcal{L}_{FFL}$ une perte frequentielle contre les artefacts, et $\mathcal{L}_{GAN}$ une perte de Wasserstein avec discriminateur. Tous les $\beta$ valent 1,0, et la perte de qualité est calculée à résolution réduite, détail d'implémentation important pour tenir 51 dB.

La perte de récupération est le point intéressant :

$$\mathcal{L}_r(\omega,\tilde{\omega}) = \mathcal{L}_{BCE}(\omega, D(\tilde{x})) + \sum_{\substack{I \subseteq [0,n] \\ |I| = k}} \max_{i \in I} \gamma_i \mathcal{L}_{BCE}(\omega, D(\Phi_i(\tilde{x}))),$$

avec $\gamma_i = 0,5$ et $k = 2$, les pires transformations étant réévaluées tous les 200 pas. Le modèle ne s'entraîne donc pas sur un tirage aléatoire mais sur les deux transformations les plus coûteuses, recalculées périodiquement. Approximation grossière du minimax, assumée pour le coût.

Architecture : encodeur MUNIT avec connexions résiduelles, convolutions $1\times1$ de post-traitement reprises de TrustMark, résidu calculé à basse résolution puis remis à l'échelle, ce qui autorise toute résolution. Décodeur ConvNeXt-base pré-entraîné, dernière couche remplacée par une couche pleinement connectée à $l$ dimensions avec sigmoïde. ResNet a été essayé puis abandonné à cause de l'instabilité des couches de normalisation par lot.

Entraînement en trois phases : décodeur seul avec $\alpha_q$ faible pour stabiliser, montée de $\alpha_q$ jusqu'à $\alpha_{q,max} = 10,0$, puis activation de l'optimisation robuste. Les transformations sont tabulées (tableau 1) : JPEG qualité 50 minimum, luminosité, contraste et saturation entre 0,75 et 1,25, flou de noyau 5 avec $\sigma$ de 0,1 à 1,5, bruit gaussien d'écart type 0,04, posterize 4 bits, ColorJiggle, décalage RGB de 0,05, flip de probabilité 1,0, rotation jusqu'à 10 degrés, effacement de 2 à 10 %, perspective 0,1, et recadrage redimensionné de 75 à 100 % de la surface.

Le papier ne donne ni taille de lot, ni nombre d'itérations, ni type de GPU, ni durée d'entraînement. C'est une omission notable pour un papier qui prétend à la reproductibilité industrielle, et il faut le dire.

## 3. Protocole et métriques

Deux jeux de 900 images : DIV2K, benchmark de super-résolution en 2K, et 900 images du jeu DALL·E 3 public. L'entraînement se fait sur 100 000 images DALL·E 3 internes, non publiques, ce qui interdit toute reproduction exacte.

Trois métriques : PSNR et SSIM pour l'imperceptibilité, exactitude de bits pour la récupération, 50 % étant le hasard, et pour le message long un taux de succès exigeant les 128 bits d'UUID complets après BCH. Tout est calculé à la résolution d'origine, avec redimensionnement pour les méthodes qui ne la supportent pas.

Cinq méthodes : InvisMark, TrustMark-Q, SSL, StegaStamp et dwtDctSvd. TrustMark-Q et SSL utilisent leurs poids publics, StegaStamp est réentraîné faute de poids, et le papier signale ne pas avoir reproduit les chiffres que TrustMark attribue à SSL et StegaStamp, ces deux méthodes faisant mieux qu'annoncé.

## 4. Résultats chiffrés

Tableau 2, imperceptibilité. DIV2K : InvisMark 51,4 dB et 0,998 de SSIM, TrustMark 41,9 et 0,995, SSL 42,6 et 0,989, StegaStamp 37,4 et 0,978, dwtDctSvd 38,3 et 0,974. DALL·E 3 : 51,4 et 0,998, 41,9 et 0,994, 42,7 et 0,990, 37,5 et 0,976, 40,2 et 0,981. Près de 9 dB d'avance sur le deuxième.

Tableau 3, robustesse à 100 bits, exactitude en pourcentage. InvisMark sur DIV2K : 100 en propre, 99,5 en JPEG, 97,4 en rotation, 97,3 en recadrage redimensionné, et 99,7 à 100 partout ailleurs. Sur DALL·E 3 : 100, 97,5 en JPEG, 98,7 en rotation, 99,8 en recadrage, le reste entre 99,8 et 100. Les baselines sont loin : TrustMark 68,7 en rotation et 69,9 en bruit, SSL 53,9 en JPEG, StegaStamp 50,9 en flip.

Tableau 5 : à 256 bits, le PSNR tombe à 47,9 sur DIV2K et 47,8 sur DALL·E 3, SSIM 0,997. Tableau 6, taux de succès après BCH : 100 % en propre, 98,9 % en JPEG sur DIV2K, 92,7 % sur DALL·E 3, 95,2 % en recadrage, et 92,7 % au pire, pour 99 % d'exactitude moyenne revendiquée.

Section 3.3, régénération par Stable Diffusion 2-1 avec des pas de bruitage de 1 à 100 : l'exactitude reste haute au-dessus de 30 dB de PSNR, s'effondre entre 25 et 30, et devient le hasard en dessous de 25. C'est une courbe, pas un chiffre unique, et elle situe la limite.

Section 3.3, falsification, le résultat le plus intéressant. Un attaquant qui a l'encodeur extrait le résidu entre image originale et image marquée, puis l'ajoute à une autre image : le décodeur retrouve 97,6 % des bits sur cette nouvelle image, contre 67,0 % pour TrustMark. Le watermark est donc copiable, et le décodeur valide une image jamais marquée. La mitigation est une empreinte du contenu dans le manifeste C2PA, pas une correction cryptographique.

## 5. Ce que les papiers de Fernandez reprennent ou contredisent

InvisMark n'apparaît pas dans les notes actuelles de Fernandez, alors qu'il est le concurrent le plus direct de `wam.md` sur l'image fixe et qu'il publie des chiffres supérieurs en imperceptibilité. C'est un angle mort à combler avant le hackathon.

La contradiction est nette sur la qualité. `wam.md` revendique 38,3 dB, `stable-signature.md` 30 dB environ, InvisMark 51,4 dB à 100 bits. Un jury peut donc demander pourquoi le watermark de Fernandez, présenté comme l'état de l'art post-hoc, perd 13 dB face à un concurrent de la même année. Sa réponse est que son watermark est aveugle et robuste aux attaques géométriques fortes, alors qu'InvisMark s'effondre à 25 dB sous régénération et que son PSNR élevé vient d'un résidu fragile. C'est vrai, mais il faut le dire avec le chiffre.

Deuxième contradiction, la géométrie. `syncseal.md` mesure TrustMark à 0,71 et WAM à 0,83 en moyenne, et la synchronisation les monte à 0,97 et 0,99. InvisMark revendique 97,3 % en recadrage et 97,4 % en rotation sans synchronisation, ce qui rend la comparaison avec WAM délicate, les grilles n'étant pas les mêmes.

Troisième point, la falsification. `copy-removal.md` et `forging.md` documentent chez Fernandez des attaques de copie et de retrait, et InvisMark fournit une mesure indépendante du même phénomène : 97,6 % de bits récupérés sur une image jamais marquée. C'est un point où les deux camps se rejoignent, et où un participant peut construire une démonstration transverse sans écrire de code d'entraînement.

Ce que Fernandez reprend : le code correcteur, l'UUID, et le manifeste C2PA comme couche d'authentification. `wam.md` fait le même constat sur la capacité, 32 bits ne suffisant pas pour un manifeste complet. InvisMark apporte la preuve chiffrée que le watermark seul ne suffit pas, puisque le résidu transplanté trompe le décodeur.

## 6. Réutilisable en 24 h

Pas de code public, pas de poids, donc l'usage direct est impossible. Ce qui se réutilise, c'est le protocole et deux idées.

Première idée, le noiser avec sélection des pires cas : réévaluer les transformations tous les 200 pas et n'entraîner que sur les deux plus coûteuses, quelques lignes dans n'importe quelle boucle, et le meilleur rapport effort-résultat du papier.

Deuxième idée, le message long avec BCH. Encoder 128 bits d'UUID plus 128 bits de redondance et mesurer un taux de succès plutôt qu'une exactitude moyenne est une métrique plus honnête pour un usage de provenance, et elle se calcule sans réentraîner, en post-traitant les bits d'un décodeur existant.

Troisième usage, la transplantation de résidu. Elle exige l'encodeur, donc ne marche que contre un système ouvert, mais tient en dix lignes : extraire $\tilde{x} - x$, redimensionner, ajouter à une autre image, décoder. Avec 97,6 % d'exactitude, c'est une démonstration spectaculaire et la meilleure preuve qu'un watermark sans liaison au contenu n'authentifie rien.

Piège principal : croire que 51 dB signifie invisible. La figure 6 zoome sur des artefacts rouges dans les zones plates, que le papier reconnaît visibles. Un jury qui juge à l'œil doit tester sur des gradients, pas seulement des portraits.
