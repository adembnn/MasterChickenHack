# ReDMark, Residual Diffusion Watermarking (2018)

Identifiant arXiv 1810.07248. Mahdi Ahmadi, Alireza Norouzi, S.M. Reza Soroushmehr, Nader Karimi, Kayvan Najarian, Shadrokh Samavi, Ali Emami. Isfahan University of Technology et University of Michigan. Soumis en décembre 2018, contemporain de HiDDeN, qu'il cite et compare directement.

## 1. Ce que le papier apporte historiquement

ReDMark est la réponse architecturale à HiDDeN : au lieu d'un encodeur qui produit une image marquée, il produit un résidu ajouté à l'image, ce qui stabilise l'entraînement et permet d'introduire un facteur d'échelle réglable après entraînement. Il transpose l'insertion dans un domaine transformé choisi, ici la DCT, tout en gardant l'entraînement de bout en bout, et il impose une convolution circulaire pour diffuser chaque bit sur une zone large de l'image. Il propose enfin une approximation différentiable du JPEG par bruit uniforme sur l'arrondi, plus simple que les masques de coefficients de HiDDeN.

## 2. Méthode, équations et hyperparamètres

Trois modules : un réseau d'insertion, une couche d'attaques différentiables, un réseau d'extraction, tous deux entièrement convolutifs avec connexions résiduelles.

Insertion. L'image de couverture $H\times W$ est découpée en blocs $M\times N$ et réarrangée en un tenseur $MN\times h\times w$, chaque colonne étant un bloc vectorisé. Une couche de transformation applique une base linéaire réversible, implémentée comme une convolution $1\times1$ de $n_T$ masques. Pour la DCT, la matrice est donnée par

$$D(\theta,k)=\frac{1}{MN}\cos\left(\frac{(2\lfloor k/M\rfloor+1)\lfloor\theta/M\rfloor\pi}{2M}\right)\cos\left(\frac{(2(k-\lfloor k/M\rfloor M)+1)(\theta-\lfloor\theta/M\rfloor M)\pi}{2N}\right),$$

avec une formule équivalente pour Hadamard. La sortie de la transformée est concaténée au watermark, puis passe par une convolution $1\times1$ et quatre convolutions circulaires $2\times2$ à activation ELU, 64 filtres par couche. Le résidu est ajouté à l'image avec un facteur de force $\alpha$, fixé à 1 pendant l'entraînement et réglable à l'inférence.

Diffusion. La convolution circulaire, en repliant les bords au lieu de bourrer de zéros, fait que chaque neurone partage l'information entre blocs voisins. Le motif de diffusion est mesuré en insérant un seul bit non nul et en regardant la différence avec un watermark nul. GT-Net place l'énergie en haute fréquence, JT-Net en basse, MT-Net de façon répartie ; tous évitent le DC.

Attaques. Bruit blanc uniforme ou gaussien, sel et poivre, recadrage aléatoire implémenté comme un dropout de blocs, lissage par masque moyenne $a\times a$, filtres FIR quelconques, et JPEG. Pour le JPEG, l'arrondi non dérivable est remplacé par un bruit uniforme :

$$Iw^*_{DCT}=\left(\frac{Iw_{DCT}}{Q}+\sigma\right)Q=Iw_{DCT}+\sigma Q,\qquad \sigma\sim\mathcal{U}[-0.5,0.5].$$

L'effet est plus fort sur les coefficients à fort pas de quantification, donc en haute fréquence, ce qui pousse le réseau à réduire l'insertion dans ces zones. Un méta-modèle « multi-attaques » tire une attaque au sort à chaque itération, avec une roue de probabilités.

Extraction. Même couche de transformation que l'insertion, puis convolution $1\times1$, trois convolutions $2\times2$ à 64 filtres et ELU, et une convolution finale à un canal avec sigmoïde.

Perte et réglages. $L=\gamma L_1+(1-\gamma)L_2$, avec $L_1$ la SSIM entre image et image marquée, et $L_2$ l'entropie croisée binaire sur les bits. $\gamma=0.75$ pour GT-Net et JT-Net, $0.5$ pour MT-Net. Blocs $8\times8$, patchs d'entraînement $32\times32$, watermark $4\times4$, soit 16 bits pour 1024 pixels, capacité 0,0156 bit par pixel. Taux d'apprentissage $10^{-4}$, momentum 0,98, un million d'itérations, environ 9 heures sur GTX 1080 Ti. Données : CIFAR10 et patchs Pascal VOC, environ 334 000 patchs $32\times32$ en gris. Trois réseaux : GT-Net avec bruit gaussien $\sigma=3$, JT-Net avec JPEG qualité 70, MT-Net avec sel et poivre 4 %, gaussien $\sigma=3$, JPEG 70 et moyenne $3\times3$ à probabilités égales.

## 3. Protocole et métriques

Entraînement sur patchs, évaluation sur images complètes. On insère 1024 bits dans des images $512\times512$, avec redondance de facteur 4 : le plan de watermark $64\times64$ est formé en répétant chaque bit quatre fois, l'image est découpée en 32 fois 32 sous-images de $32\times32$, et le décodage applique un vote majoritaire sur les quatre copies. Jeu de test : les 49 images standard de l'Université de Grenade, chaque mesure étant moyennée sur 20 watermarks aléatoires par image. Métriques : PSNR, SSIM, et BER en pourcentage, le symbole N signalant un BER proche de 50 %, donc non robuste. Trois niveaux par attaque, plus le recadrage en grille.

## 4. Résultats chiffrés

Imperceptibilité et robustesse (tableaux II et III). À $\alpha=1$, MT-Net donne 35,93 dB et SSIM 0,966, JT-Net 39,77 dB et 0,985, GT-Net 44,14 dB et 0,992. À $\alpha=0,6$, MT-Net passe à 40,24 dB et SSIM 0,987, JT-Net à 43,66 et 0,994, GT-Net à 47,52 et 0,996, au prix d'un BER plus élevé.

Quelques points du tableau II, MT-Net à $\alpha=0,8$ : bruit gaussien $\sigma=5, 15, 25$ donne 0,1 %, 6,4 %, 18,2 % de BER ; recadrage 10 %, 20 %, 30 % donne 6,0 %, 11,5 %, 17,1 % ; recadrage en grille 20 %, 30 %, 40 % donne 4,4 %, 8,5 %, 13,4 % ; sel et poivre 0,1 %, 0,6 %, 2,7 %. Le recadrage en grille est le résultat qui compte : annuler 30 % des blocs ne coûte que 13,4 % de bits, ce qui est la démonstration de la diffusion.

Comparaison directe à HiDDeN (tableau IV), à qualité comparable et pour MT-Net $\alpha=1$, en BER : JPEG qualité 50, 25,4 % contre 37,0 % ; Cropout 30 %, 7,5 % contre 6,0 % ; Dropout 30 %, 8,0 % contre 7,0 % ; Crop 3,5 %, 0,0 % contre 12,0 % ; filtre gaussien $\sigma=2$, 50,0 % contre 4,0 %. ReDMark gagne nettement en JPEG et en recadrage, perd en flou gaussien, et fait jeu égal en dropout. Profil d'un modèle spécialisé JPEG et attaques spatiales.

Comparaison à Random Matching Pursuit (tableau V), à SSIM égal, en BER : JPEG 50, 25,68 % pour MT-Net à $\alpha=0,4$ contre 26,74 % ; JPEG 70, 16,49 % contre 17,64 % ; JPEG 90, 9,30 % contre 1,98 %. JT-Net à $\alpha=0,8$ écrase la référence sur les trois qualités avec 6,75 %, 2,32 % et 1,31 %.

## 5. Ce que Fernandez reprend, ce qu'il change

ReDMark apparaît dans les références de Fernandez comme représentant de la génération intermédiaire, celle qui règle un axe à la fois, avec une mention explicite dans la carte des citations. Trois éléments sont repris.

Le premier est la paramétrisation résiduelle avec facteur de force. On la retrouve presque à l'identique dans la Stable Signature, où l'encodeur produit $\delta$ et l'image marquée vaut $x_w=x_o+\alpha\delta$, et dans MBRS, où $I_{EN,S}=I_{CO}+S\cdot I_{DIFF}$ sert à balayer le compromis qualité robustesse sans réentraîner. 

Le deuxième est la couche d'attaque dans la boucle, avec tirage aléatoire d'une transformation par itération. Tous les travaux de Fernandez utilisent des pools d'augmentations tirées au sort, et WAM comme Video Seal regroupent explicitement les transformations par familles pour mesurer la robustesse.

Le troisième est la diffusion. L'idée qu'un bit doit être réparti sur toute l'image plutôt que sur un bloc est ce qui permet à WAM de localiser des messages de 32 bits sur des zones de 10 % et de tenir le splicing, et ce qui distingue les méthodes content-aware des méthodes par blocs.

Ce qui est changé : Le domaine DCT fixe et le découpage en blocs $8\times8$ disparaissent : les méthodes de Fernandez insèrent dans un espace de features appris ou dans le latent d'un décodeur, sans base imposée. La perte SSIM cède la place à des combinaisons de MSE, LPIPS, pertes perceptuelles et adversariales. La capacité passe de 16 bits par patch à 48, 96, 256 bits par image entière. Enfin, ReDMark mesure un BER moyen, alors que Fernandez mesure des p-values calibrées et des TPR à FPR fixé, changement de métrique qui rend les chiffres des deux générations non comparables directement.

ReDMark n'est pas dans le banc de Pixel Seal ni de Video Seal : aucune mesure de sa chute sous attaques combinées n'existe dans le corpus Fernandez, seulement les comparaisons du papier lui-même.

## 6. Réutilisable en 24 h

Le code n'est pas publié au moment de la rédaction, les auteurs annoncent un dépôt GitHub sans lien stable dans le texte. La méthode se réimplémente en quelques heures : DCT par convolution $1\times1$, quatre convolutions circulaires, facteur $\alpha$, et l'approximation JPEG par bruit uniforme en trois lignes.

Deux expériences utiles. D'abord, vérifier le facteur de force : entraîner une fois, puis balayer $\alpha$ de 0,6 à 1,4 et tracer PSNR contre BER. C'est la démonstration la plus rapide qu'un watermark se règle au déploiement sans réentraînement, et elle prend une heure sur un modèle déjà entraîné. Ensuite, reproduire l'attaque de recadrage en grille : elle est plus sévère qu'un crop classique et met en évidence les méthodes qui insèrent par blocs, ce qui est un test discriminant pour un jury.

Le piège est le flou gaussien : ReDMark y est mauvais par construction, 50 % de BER à $\sigma=2$, et reprendre l'architecture sans changer le pool d'attaques hérite de cette faiblesse. Le second piège est la redondance de facteur 4 et le vote majoritaire : sans eux, les 1024 bits sur $512\times512$ ne tiennent pas, et comparer un modèle sans vote à un modèle avec vote fausse le résultat.
