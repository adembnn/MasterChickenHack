# Robust Watermarking Using Generative Priors Against Image Editing: From Benchmarking to Advances (VINE, 2024)

Identifiant arXiv 2410.18775, deuxième version du 15 mars 2025. Shilin Lu, Zihan Zhou, Jiayou Lu, Yuanzhi Zhu, Adams Wai-Kin Kong, Nanyang Technological University et ETH Zürich. Publié à ICLR 2025. Code : https://github.com/Shilin-LU/VINE.

## 1. L'apport en trois phrases

VINE est deux papiers en un : W-Bench, premier benchmark de robustesse des watermarks d'image face aux éditions génératives, et VINE, méthode qui utilise SDXL-Turbo comme encodeur pour y résister. Le constat est brutal : sur onze méthodes, la plupart ne détectent plus rien après régénération, édition globale ou locale, ou génération image-vers-vidéo, et Stable Signature de Fernandez tombe à 1,76 % de TPR après régénération stochastique. La contribution est double : utiliser le flou comme attaque de substitution, parce que les éditions génératives et le flou partagent une signature frequentielle, et remplacer l'encodeur par un modèle de diffusion à un pas.

## 2. Méthode, équations et hyperparamètres réellement donnés

L'observation de départ est frequentielle (figure 3, 1 000 images) : les éditions génératives effacent les motifs des bandes moyenne et haute fréquence, les basses survivent, et le flou, pixelisation ou défocus, produit le même profil, alors que JPEG et saturation non. D'où des flous variés dans la couche de bruit, en plus des distortions classiques.

La couche de bruit contient donc saturation, contraste, luminosité, JPEG, bruit gaussien, bruit de shot, bruit d'impulsion, bruit de speckle, plus pixelisation, flou de défocus, flou de zoom, flou gaussien et flou de mouvement.

L'encodeur est SDXL-Turbo, un modèle texte-image à un pas. Le watermark de 100 bits et l'image sont fusionnés par un adaptateur de condition, puis passés au VAE et au U-Net, le prompt texte étant mis à nul pendant tout l'entraînement. Le papier explique deux échecs : ajouter une branche de condition supplémentaire au U-Net à un pas ne converge pas correctement, et passer le watermark par le prompt texte ne converge pas du tout. Le VAE est modifié par des connexions résiduelles entre encodeur et décodeur, à travers des convolutions à noyau nul, pour préserver la fidélité de reconstruction. Le décodeur est un ConvNeXt-B avec une couche pleinement connectée de 100 sorties.

La perte est

$$\mathcal{L}_{ALL} = \mathcal{L}_{IMG}(x_o, x_w) + \alpha \mathcal{L}_{BCE}(w, w'),$$

avec

$$\mathcal{L}_{IMG} = \beta_{MSE}\mathcal{L}_{MSE}(\gamma(x_o), \gamma(x_w)) + \beta_{LPIPS}\mathcal{L}_{LPIPS}(x_o, x_w) + \beta_{GAN}\mathcal{L}_{GAN}(x_o, x_w),$$

où $\gamma$ projette en YUV. Trois phases : d'abord $\alpha = 10$ et les trois $\beta$ à 0,01, avec U-Net, décodeur VAE et convolutions nulles gelés ; quand l'exactitude dépasse 0,85, tout est dégelé et les poids passent à $\alpha = 1,5$, $\beta_{MSE} = 2,0$, $\beta_{LPIPS} = 1,5$, $\beta_{GAN} = 0,5$, ce qui donne VINE-B ; enfin un fine-tuning avec Instruct-Pix2Pix dans la couche de bruit, gradient passant par un estimateur straight-through, ce qui donne VINE-R.

Hyperparamètres réellement donnés : résolution 512, OpenImage pour l'entraînement, Adam avec taux $10^{-4}$ et lot de 112, 111 000 itérations sur 8 GPU A100-80GB pour VINE-B, puis taux réduit à $5 \times 10^{-6}$ et 80 000 itérations pour VINE-R sur les mêmes 8 GPU.

## 3. Protocole et métriques

W-Bench couvre quatre familles. Régénération d'image, stochastique avec SDEdit et déterministe par inversion. Édition globale, avec Instruct-Pix2Pix et UltraEdit. Édition locale, avec MagicBrush et UltraEdit local. Génération image-vers-vidéo, avec ControlNet-Inpainting et Stable Video Diffusion. Chaque tâche est évaluée sur plusieurs niveaux de difficulté, et les TPR sont moyennés sur ces niveaux.

Les métriques de qualité sont PSNR, SSIM, LPIPS et FID, sur 10 000 images, à 512 par 512. La métrique principale est le TPR@0,1 % de FPR, calculé en nourrissant le détecteur avec les images marquées et les images originales, et moyenné sur 5 000 images par méthode d'édition. Le papier justifie explicitement ce choix : ni l'exactitude de bits ni l'AUROC ne garantissent un TPR élevé à faible FPR, et les auteurs ont constaté que SSL obtient une meilleure exactitude et un meilleur AUROC que TrustMark tout en ayant un TPR plus faible, parce qu'il produit beaucoup de faux positifs sur les images non marquées. C'est la critique méthodologique la plus utile du papier, et elle vise directement la façon dont Fernandez mesure ses propres résultats.

## 4. Résultats chiffrés

Tableau 1, sur 11 méthodes. SSL, la méthode de Fernandez 2022, affiche 30 bits de capacité, 41,77 dB, SSIM 0,9796, LPIPS 0,0350, FID 3,54, puis en TPR@0,1 % : 1,76 en régénération stochastique, 9,70 en déterministe, 25,06 et 10,58 en édition globale, 50,10 et 25,28 en édition locale, 31,46 et 3,65 en image-vers-vidéo. TrustMark fait 9,22 et 34,20 en régénération, MBRS 99,53 et 99,35 mais avec un PSNR de 27,37, StegaStamp 91,09 et 92,13 avec 29,65 dB.

VINE-B : 100 bits, 40,51 dB, SSIM 0,9954, LPIPS 0,0029, FID 0,08, TPR 91,03 en stochastique, 99,25 en déterministe, 96,30 et 80,90 en global, 89,29 et 99,60 en local, 89,68 et 25,44 en image-vers-vidéo. VINE-R : 37,34 dB, 99,66, 99,98, 97,46, 86,86, 94,58, 99,96, 93,04, 36,33. Le point faible des deux est Stable Video Diffusion, à 25,44 et 36,33, ce que le papier reconnaît.

Tableau 7, coût. SSL prend 2,1938 s par image et 1 072 Mo de mémoire GPU, VINE 0,0795 s et 4 982 Mo, TrustMark 0,0705 s et 648 Mo, MBRS 0,0053 s et 938 Mo. VINE est donc 27 fois plus rapide que SSL, mais consomme près de huit fois plus de mémoire que TrustMark, et l'écart de qualité entre VINE-B et VINE-R (40,51 contre 37,34 dB) est le prix de la robustesse.

Tableau 2, ablation. Le passage d'un U-Net simple à SDXL-Turbo, puis l'ajout de l'adaptateur de condition, puis des connexions résiduelles, puis du fine-tuning Instruct-Pix2Pix, chaque brique est mesurée séparément, et le papier donne les TPR de chaque configuration, ce qui en fait une des rares ablations réellement lisibles de la littérature.

## 5. Ce que les papiers de Fernandez reprennent ou contredisent

C'est le papier le plus dangereux pour Fernandez, parce qu'il ne polémique pas : il mesure. La ligne SSL du tableau 1 est une citation directe de son travail de 2022, et les chiffres sont sans appel : 1,76 % de TPR à 0,1 % de FPR après régénération stochastique, 3,65 % après Stable Video Diffusion. Un jury peut donc demander pourquoi un watermark qui revendique 0,99 d'exactitude de bits ne détecte plus rien dès qu'on régénère l'image.

La réponse de Fernandez est double, et elle est déjà dans ses notes. D'abord, SSL est sa méthode de 2022, et il l'a lui-même remplacée : `wam.md` revendique 38,3 dB et une robustesse supérieure sur les transformations géométriques, `distseal.md` pousse plus loin, et `video-seal.md` traite la vidéo. Ensuite, `wam.md` et `distseal.md` ont adopté le TPR à FPR fixé comme métrique principale, précisément pour la raison que VINE invoque, ce qui montre que la critique a été entendue.

Mais deux contradictions subsistent, et elles sont chiffrées. Premièrement, la vitesse : SSL prend 2,19 s par image selon le tableau 7, et un watermark post-hoc qui coûte deux secondes par image est inutilisable en production, ce que Fernandez reconnaît en partie dans `distseal.md` en visant 3 ms. Deuxièmement, la comparaison directe manque : VINE ne teste pas WAM, sorti en novembre 2024, après la soumission de VINE, et `wam.md` ne cite pas VINE. Le jury peut donc opposer à Fernandez un benchmark où sa méthode la plus récente brille par son absence, et à VINE le fait qu'il n'a pas évalué le concurrent le plus proche.

Ce que Fernandez reprend : la critique de l'exactitude de bits comme métrique, le TPR@0,1 % de FPR, et l'idée que les éditions génératives sont l'attaque de référence. `public-detection.md` et `distseal.md` vont plus loin en ajoutant la calibration du FPR sur des images non marquées, ce que VINE ne fait que par appariement marqué et original.

## 6. Réutilisable en 24 h

Le dépôt `Shilin-LU/VINE` est public, avec les poids de VINE-B et VINE-R, et le benchmark W-Bench est décrit assez précisément pour être partiellement reproduit. C'est la meilleure base de démonstration pour un hackathon, parce qu'elle contient à la fois une méthode forte et un protocole d'évaluation tout fait.

Trois usages. Le benchmark seul : reprendre les quatre familles et mesurer n'importe quelle méthode, y compris maison, sur le TPR@0,1 %, ce qui donne un résultat comparable à la littérature en une journée. L'attaque de substitution : le flou suffit à simuler une édition générative, donc on entraîne un petit encodeur robuste sans faire tourner Stable Diffusion. La démonstration de fragilité : appliquer une régénération SDEdit à une image marquée par un watermark post-hoc et constater l'effondrement du TPR prend une heure.

Piège principal, la mémoire. VINE-R demande près de 5 Go de VRAM par image selon le tableau 7, ce qui interdit le traitement par lots sur un petit GPU, et le fine-tuning à 8 A100 n'est pas reproductible en 24 h : utiliser les poids publiés, pas réentraîner. Second piège, Stable Video Diffusion reste le point faible de toutes les méthodes, VINE incluse, et une démo vidéo finira sur des chiffres médiocres.
