# MBRS, Mini-Batch of Real and Simulated JPEG (2021)

Identifiant arXiv 2108.08211. Zhaoyang Jia, Han Fang, Weiming Zhang, University of Science and Technology of China. Soumis le 18 août 2021, publié à ACM Multimedia 2021. Code PyTorch public : https://github.com/jzyustc/MBRS.

## 1. Ce que le papier apporte historiquement

MBRS règle le problème laissé ouvert par HiDDeN et ReDMark : leurs proxies de JPEG sont différentiables mais faux, et le décodeur entraîné sur le proxy ne tient pas sur le vrai codec. La contribution est un protocole d'entraînement, pas une architecture : à chaque mini-lot, on tire au sort entre vrai JPEG, JPEG simulé et absence de bruit, ce qui permet à l'encodeur de recevoir malgré tout un gradient utilisable, par l'élan de l'optimiseur, lors des lots où le vrai JPEG coupe la rétropropagation. Le résultat est spectaculaire et devient la référence : moins de 0,01 % de BER à qualité 50 avec plus de 36 dB de PSNR, là où HiDDeN et le modèle à deux étages de Liu et coll. plafonnent à 15 % et 22 % de BER. Le papier impose aussi deux briques reprises partout, le processeur de message et le bloc de diffusion.

## 2. Méthode, équations et hyperparamètres

Cinq composants : processeur de message, encodeur, couche de bruit, décodeur, discriminateur adverse.

Processeur de message. Le message $M\in\{0,1\}^L$ est reshapé en $\{0,1\}^{1\times h\times w}$ avec $L=h\times w$, passé par une convolution $3\times3$ avec batch norm et ReLU, puis agrandi en $C\times H\times W$ par plusieurs convolutions transposées de pas 2, et enfin raffiné par des blocs Squeeze-and-Excitation. La contrainte de taille est explicite :

$$L=h\times w=\frac{H}{2^n}\times\frac{W}{2^n},\quad n\in\mathbb{Z}^*.$$

Cette relation dit ce que le papier ne répète pas assez : la capacité est structurellement liée au facteur de réduction spatiale, un message de 64 bits pour $128\times128$ impose $n=4$.

Encodeur et décodeur. Tous deux sont bâtis sur des blocs SE, avec des convolutions $3\times3$ et une sortie $1\times1$. L'encodeur concatène les features de l'image et la carte de message, puis ajoute l'image d'entrée avant une convolution $1\times1$, ce qui produit l'image marquée directement, pas un résidu explicite. Les pertes sont $L_{E_1}=\mathrm{MSE}(I_{co},I_{en})$, $L_D=\mathrm{MSE}(M,M')$, et pour l'adversaire $L_A=\log(1-A(I_{en}))+\log(A(I_{co}))$, avec $L_{E_2}=\log(A(I_{en}))$ pour l'encodeur. Total :

$$L=\lambda_E L_{E_1}+\lambda_D L_D+\lambda_A L_{E_2},$$

avec $\lambda_E=1$, $\lambda_D=10$, $\lambda_A=0,0001$. Le poids fort sur le message explique le BER quasi nul.

Couche de bruit MBRS. À chaque mini-lot, tirage uniforme entre trois options : vrai JPEG, JPEG-Mask différentiable, et identité. Le vrai JPEG ne laisse pas passer de gradient, $\partial L_D/\partial\theta_E=0$, mais Adam conserve l'élan des lots précédents, donc la direction de mise à jour de l'encodeur reste correcte. L'approche en deux étages de Liu et coll. est gloutonne, un changement de phase unique ; MBRS alterne en continu.

Facteur de force. Le résidu est $I_{DIFF}=I_{EN}-I_{CO}$ et l'image déployée vaut $I_{EN,S}=I_{CO}+S\cdot I_{DIFF}$. Le facteur ne sert qu'à l'insertion, le décodage reste aveugle.

Diffusion. Le processeur de message et le reshape final du décodeur font que chaque bit n'est porté que par une petite région, d'où une faiblesse au recadrage. Le correctif est une couche entièrement connectée en entrée du processeur et une autre en sortie du décodeur, qui répartit chaque bit sur toute l'image. Le papier le vérifie en comparant un message nul et un message à un seul bit : sans diffusion l'écart est local, avec diffusion il est global.

Entraînement : 10 000 images ImageNet, test sur 5 000 images COCO, PyTorch, RTX 2080 Ti, Adam à $10^{-3}$, lot de 16, 100 époques, facteur de force 1 pendant l'entraînement.

## 3. Protocole et métriques

Robustesse mesurée par BER, qualité par PSNR et SSIM. Baselines : HiDDeN, le cadre à deux étages de Liu et coll., et StegaStamp avec ses poids pré-entraînés publics. Les chiffres de HiDDeN et de Liu sont repris de leurs articles, non reproduits. Deux tailles : $128\times128$ avec 64 bits, et $400\times400$ avec 625 bits, les deux fois avec une capacité supérieure aux articles d'origine pour une comparaison à taille égale. Le test principal est le vrai JPEG qualité 50 via la fonction PIL. Les autres distorsions sont testées avec un modèle entraîné sur JPEG-Mask, vrai JPEG 10, identité, flou $\sigma=2$ et crop, les images recadrées étant complétées en blanc.

## 4. Résultats chiffrés

Comparaison principale (tableau 1). À $128\times128$ et 64 bits, MBRS donne 36,49 dB de PSNR en RGB, SSIM 0,9173 et 0,0092 % de BER, contre 30,09 dB et 15 % de BER pour HiDDeN spécifié JPEG, et 33,51 dB et 22,3 % pour Liu. À $400\times400$ et 625 bits, MBRS donne 39,32 dB, SSIM 0,9504 et 0,0012 % de BER, contre 32,36 dB, SSIM 0,8506 et 0,2418 % pour StegaStamp. 

Autres distortions (tableau 2), modèle sans puis avec bloc de diffusion, contre HiDDeN et Liu entraînés en combiné, à PSNR 33,5 : Cropout 0,3, 32,86 % sans diffusion, 0,0027 % avec, 6 % pour HiDDeN, 2,7 % pour Liu ; Dropout 0,3, 8,12 %, 0,0087 %, 7 %, 2,6 % ; Crop 0,035, 45,86 %, 4,15 %, 12 %, 11 % ; flou gaussien $\sigma=2$, 0,0032 %, 0,011 %, 4 %, 1,4 % ; JPEG 50, 4,14 %, 4,48 %, 37 %, 23,8 %.

Le point à retenir est le renversement : sans diffusion, le modèle est excellent en JPEG et catastrophique en crop, 45,86 %. Avec diffusion, il reste bon partout, avec un BER de 4,15 % sur crop à 30 bits. La diffusion coûte peu en compression et sauve la robustesse spatiale.

Facteur de force (tableau 3). Balayage de 0,6 à 2,4 : PSNR de 46,48 dB à 34,44 dB, SSIM de 0,9890 à 0,8690, et BER à qualité 50 de 11,81 % à 0,00 %.

## 5. Ce que Fernandez reprend, ce qu'il change

MBRS est l'une des baselines les plus réutilisées du corpus. Video Seal l'inclut à 256 bits, Pixel Seal à 256 bits, forging l'utilise comme cible, SyncSeal mesure son gain dessus, et more-bits le cite dans son tableau de comparaison de capacité.

Ce qui est repris. Le tirage par mini-lot entre opérateur réel et opérateur simulé est devenu un réflexe, même quand le vrai opérateur n'est pas différentiable : Pixel Seal et Video Seal entraînent avec des codecs réels ou des proxies selon la phase. Le facteur de force réapparaît partout, de la Stable Signature à WAM. Le bloc de diffusion, enfin, est l'ancêtre direct de la localisation par zones de WAM : l'idée qu'un bit doit être porté par une région large plutôt que par une position fixe est ce qui rend possible l'inpainting et le splicing.

Ce qui est changé, et les chiffres le montrent. Video Seal, sur SA-1B et transformations combinées, mesure MBRS à 0,50 d'exactitude avec $\log_{10}p=-0,4$, contre 0,91 et $-18,4$ pour Video Seal : la robustesse JPEG de MBRS ne se transfère pas aux transformations composées. En valuémétrique, MBRS reste très fort, 0,95 avec $\log_{10}p=-59,8$, mais avec 256 bits, donc un avantage de preuve qui vient du payload plus que de la méthode. Pixel Seal, sur 1 000 images $1280\times1280$, mesure MBRS à 46,3 dB de PSNR, SSIM 0,9928, JND 1,59, puis 0,52 en géométrique et 0,50 en combiné. SyncSeal remonte MBRS de 0,60 à 0,76 en exactitude moyenne sous transformations géométriques, ce qui confirme que sa faiblesse est la synchronisation, pas le message. Forgery trouve MBRS volable par simple moyenne de 100 images, avec 0,91 d'exactitude, et le retrait laisse 0,64.

Fernandez garde la recette d'entraînement et la diffusion, mais abandonne le pixel comme support : le watermark passe dans un latent ou dans les poids d'un décodeur, ce qui rend la robustesse géométrique plus critique. Il abandonne aussi le BER comme métrique principale au profit de la p-value, ce qui relativise les BER quasi nuls de MBRS : 0,0012 % sur 625 bits est excellent, mais la question utile est la probabilité qu'un détecteur s'ouvre par hasard.

## 6. Réutilisable en 24 h

Le dépôt jzyustc/MBRS est public, en PyTorch, avec poids et scripts. C'est la baseline la plus rapide à mettre en route, avec Video Seal.

Trois usages. Premier, servir de victime : le modèle est petit, s'entraîne en 100 époques sur une seule GPU, et il est documenté comme sensible au recadrage et au forging par moyenne. C'est une cible idéale pour une démonstration d'attaque en quelques heures. Deuxième, reprendre le tirage par mini-lot pour n'importe quel codec non différentiable, par exemple H.264 pour une piste vidéo : trois branches, réel, proxy, identité, et l'élan d'Adam fait le reste.

Deux pièges. Le premier est la relation $L=(H/2^n)(W/2^n)$ : elle contraint le couple taille d'image et longueur de message, et un participant qui change la résolution sans changer $L$ obtient une erreur de forme, pas un résultat. Le second est la comparaison de BER entre méthodes de capacités différentes : 0,01 % sur 64 bits et 0,01 % sur 625 bits ne veulent pas dire la même chose, et le papier ne le corrige pas. Un jury qui connaît Video Seal posera la question de la p-value ; mieux vaut la calculer soi-même.
