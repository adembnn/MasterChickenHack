# Les sources de Pierre Fernandez, 12 travaux lus

17 937 mots, une note par travail, texte intégral. Ces sources sont celles qu'il cite et sur
lesquelles il construit. Chaque note dit ce qu'il en garde et ce qu'il change.

## La chaîne historique, dans l'ordre

1. `watermarking-security.md` : Cayre, Fontaine, Furon, IEEE TSP 2005. Distingue robustesse
   (dégradation par traitement classique) et sécurité (capacité d'un attaquant à lire, écrire,
   retirer). Donne le nombre d'images nécessaires à une attaque estimée. C'est la slide 51 de son
   talk, mot pour mot.
2. `hidden.md` : HiDDeN, 2018. Le squelette encodeur, couche de bruit, décodeur. Il le réutilise tel
   quel en phase 1 de Stable Signature, en supprimant les pertes perceptuelle et adversariale.
3. `redmark.md` : ReDMark, 2018. Paramétrisation résiduelle avec facteur de force, attaque dans la
   boucle, diffusion des bits. Il abandonne la DCT fixe et les blocs 8x8, garde le résidu.
4. `stegastamp.md` : StegaStamp, 2019. U-Net à connexion résiduelle, transformation spatiale,
   augmentations physiques, curriculum. Il retire le détecteur et sort le watermark du pixel.
5. `distortion-agnostic.md` : 2020. Ne pas modéliser la distorsion, évaluer par familles de
   transformations. Il remplace le réseau adverse par des pools d'augmentations fixes et des
   p-values calibrées.
6. `mbrs.md` : 2021. Mini-lots mêlant opérateur réel, proxy et identité. Ancêtre direct de la
   localisation par zones de WAM.
7. `tree-ring.md` : 2023. Watermark dans le bruit initial du sampling, détecteur à p-value exacte.
   La famille opposée à la sienne. Son attaque la moins chère, une translation, tient en une ligne.
8. `wouaf.md` : Kim et al., CVPR 2024. Attribution par utilisateur via modulation des poids du
   décodeur. Le concurrent direct, avec la comparaison de coût 8,4 h / 1 min / 1 s.
9. `synthid-text.md` : Nature 2024. La référence du watermark de texte en production, 20 millions de
   réponses, +0,57 % de latence. TextSeal le contredit sur la diversité.
10. `invismark.md` : Microsoft, WACV 2025. Mesure l'attaque de transplantation de résidu : 97,6 % de
    bits récupérés sur une image jamais marquée. L'argument « un watermark sans lien au contenu
    n'authentifie rien ».
11. `vine.md` : NTU et ETH, ICLR 2025. Le banc W-Bench et le chiffre qui contredit Fernandez :
    SSL latent à 1,76 % de TPR à 0,1 % de FPR après régénération, pour 2,19 s par image.
12. `trustmark.md` : 2023. Modèle de bruit à 18 transformations, focal frequency loss, TPR mesuré
    par scénario (inpainting, splicing). Le banc sur lequel Pixel Seal se compare.

## Ce que la chaîne raconte

Trois idées ont survécu à huit ans de papiers : le résidu appris plutôt que le watermark additif,
la transformation dans la boucle d'entraînement plutôt que la robustesse a posteriori, et
l'évaluation par familles d'attaques plutôt qu'un chiffre unique. Fernandez n'invente aucune des
trois, il les pousse à l'échelle et les ouvre en MIT.

Ce qui a changé avec lui : la perte perceptuelle remplacée par un discriminateur adversarial
(Pixel Seal), le watermark déplacé dans les poids du générateur (Stable Signature, DistSeal), et
l'extraction traitée comme une segmentation (WAM). Ce qui ne vient pas de lui : le watermark dans le
sampling (Tree-Ring), la modulation de poids par utilisateur (WOUAF), le marquage de texte
(SynthID-Text), la détection publique (Microsoft).

## Les contradictions à connaître avant le jury

- VINE mesure que les watermarks post-hoc de type SSL s'effondrent à 1,76 % de TPR après
  régénération. Fernandez le reconnaît dans son talk (slide 44) et répond par la famille sémantique.
- InvisMark montre qu'un résidu peut être transplanté d'une image à une autre, donc qu'un watermark
  sans dépendance au contenu ne prouve pas l'authenticité, seulement la présence d'un marqueur.
- WOUAF coûte 8,4 h pour retrouver un utilisateur parmi N, quand l'extraction directe prend une
  seconde. Le compromis sécurité / coût est le vrai sujet des détecteurs publics.
- Cayre 2005 dit que la sécurité se mesure en nombre d'images, pas en résistance à une attaque
  donnée. Aucun des 24 papiers de Fernandez ne donne cette mesure, sauf son papier d'attaques 2024.

## Ordre de lecture selon l'épreuve

- Épreuve de retrait ou de forgery : `watermarking-security.md`, `invismark.md`, `tree-ring.md`.
- Épreuve d'attribution de générateur : `wouaf.md`, `hidden.md`, `mbrs.md`.
- Épreuve de texte : `synthid-text.md`, puis TextSeal et TextSeal2 dans le dossier parent.
- Épreuve de contenu régénéré : `vine.md` d'abord, c'est le papier qui donne les chiffres d'échec.
- Pour construire un watermark robuste en quelques heures : `trustmark.md`, `stegastamp.md`.
