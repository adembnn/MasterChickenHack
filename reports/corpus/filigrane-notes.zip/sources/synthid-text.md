# Scalable Watermarking for Identifying Large Language Model Outputs (SynthID-Text, 2024)

Article publié dans Nature, volume 634, pages 818 à 823, le 23 octobre 2024, DOI 10.1038/s41586-024-08025-4. Vingt-quatre auteurs, tous de Google DeepMind : Sumanth Dathathri, Abigail See, Sumedh Ghaisas, Po-Sen Huang, Rob McAdam, Johannes Welbl, Vandana Bachani, Alex Kaskasoli, Robert Stanforth, Tatiana Matejovicova, Jamie Hayes, Nidhi Vyas, Majd Al Merey, Jonah Brown-Cohen, Rudy Bunel, Borja Balle, Taylan Cemgil, Zahra Ahmed, Kitty Stacpoole, Ilia Shumailov, Ciprian Baetu, Sven Gowal, Demis Hassabis et Pushmeet Kohli. Le texte intégral est en accès libre sur le site de Nature. Vérification faite sur l'API arXiv et sur OpenAlex, il n'existe pas de prépublication arXiv de ce papier : les entrées arXiv trouvées contenant « SynthID » sont des analyses tierces, dont plusieurs papiers de 2025 qui attaquent ou évaluent le système. Code : https://github.com/google-deepmind/synthid-text, référence 7 du papier.

## 1. L'apport en trois phrases

SynthID-Text est le premier watermark de texte déployé à l'échelle d'un produit grand public, Gemini, et la seule évaluation de watermarking qui repose sur vingt millions de réponses réelles avec un test A/B de qualité perçue. La méthode ne touche ni l'entraînement ni les poids : elle remplace l'échantillonnage du token par un tournoi à plusieurs couches entre candidats tirés de la distribution du modèle, ce qui marque le texte sans changer sa distribution marginale. Le détecteur n'a besoin que de la clé et du texte, pour 0,57 % de latence en plus par token, et c'est la référence industrielle que tout le monde cite, y compris ceux qui la battent.

## 2. Méthode, équations et hyperparamètres réellement donnés

Trois composants : générateur de graine, échantillonnage, score. La graine $r_t$ est un hachage des $H$ derniers tokens et de la clé, avec $H = 4$, une fenêtre glissante et un masque de contexte répété. Chaque token $x_t$ reçoit $m$ scores binaires $g_\ell(x_t, r_t) \in \{0,1\}$, produits par des fonctions pseudo-aléatoires indépendantes.

Le tournoi : on tire $M = 2^m$ tokens de $p_{LM}(\cdot \mid x_{<t})$, avec répétitions possibles, on les apparie au hasard, et à la couche $\ell$ le token de chaque paire qui a le plus grand $g_\ell$ gagne, les égalités étant tranchées au hasard. Les gagnants sont réappariés jusqu'à un vainqueur unique, qui devient $x_t$. Le texte est donc biaisé vers les tokens qui scorent haut, mais chaque token reste un tirage de la distribution du modèle, d'où la propriété non distortionnaire.

Le détecteur calcule

$$\mathrm{Score}(x) = \frac{1}{mT}\sum_{t=1}^{T}\sum_{\ell=1}^{m} g_\ell(x_t, r_t),$$

avec quatre variantes : moyenne simple, moyenne pondérée par couche, versions fréquentistes qui donnent une p-value, et une fonction bayésienne paramétrée qui apprend la probabilité a posteriori d'être marqué. C'est cette dernière qui sert par défaut.

Hyperparamètres : $m = 30$ couches sauf mention contraire, $g$ selon $\mathrm{Bernoulli}(0,5)$, $H = 4$, top-$k$ avec $k = 100$, températures 0,5, 0,7 et 1,0, modèles Gemma 2B-IT, Gemma 7B-IT et Mistral 7B-IT v0.2, prompts ELI5, 10 000 prompts de test et 10 000 de développement, 1 500 en distortionnaire, et deux jeux de 10 000 réponses humaines comme négatifs. La détectabilité croît avec $m$ puis sature, chaque couche consommant de l'entropie, et le schéma échoue à faible entropie.

Point d'ingénierie que peu de résumés reprennent : l'intégration au décodage spéculatif. Deux variantes, l'une qui préserve la détectabilité au prix de l'efficacité, l'autre, fast watermarked speculative sampling, qui préserve le taux d'acceptation du petit modèle mais perd en détectabilité. C'est le point que TextSeal2 attaque.

## 3. Protocole et métriques

La métrique principale est le TPR à FPR fixé, mesuré empiriquement, avec un FPR de 1 % dans les figures principales. La qualité est mesurée par perplexité, par benchmarks standards, par une étude humaine contrôlée sur des paires de réponses, et par l'expérience en production.

Cette expérience est le morceau rare : une fraction aléatoire des requêtes Gemini est routée vers le modèle marqué, une fraction équivalente vers le non marqué, et le papier analyse environ 20 millions de réponses avec les pouces du produit. Les taux diffèrent de 0,01 % en faveur du marqué pour les pouces en l'air, et de 0,02 % en défaveur du marqué pour les pouces en bas, les deux dans les intervalles à 95 %. Mesure d'équivalence, pas de supériorité, et les pouces ne mesurent pas la qualité linguistique.

Baselines : Gumbel-max en non distortionnaire et Soft Red List en distortionnaire, les deux meilleures méthodes publiées alors. Les courbes balaient la longueur, et le paramètre de force est réglé pour comparer à qualité égale.

## 4. Résultats chiffrés

Figures 3a et 3b, Gemma 7B-IT, température 0,7, ELI5 : le TPR@1 % du non distortionnaire dépasse celui de Gumbel-max sur toute la plage de longueurs, et l'écart se creuse avec la longueur. Le papier ne donne pas de tableau, seulement des courbes avec intervalles bootstrap à 90 %, donc citer un TPR précis sans passer par la Supplementary Information revient à inventer un chiffre.

Figure 3b : le mécanisme d'abstention, qui refuse de se prononcer quand le score est incertain, atteint 95 % de TPR à 1 % de FPR sur la fraction non abandonnée, au prix d'une abstention partielle. Réponse élégante au problème de calibration, peu reprise dans la littérature.

Figure 3c, 200 tokens : à $\log(\text{perplexité})$ égal, le distortionnaire détecte mieux que Soft Red List, argument central contre les listes vertes et rouges.

Latence : Gemma 7B-IT sur 4 TPU v5e génère à 15,527 ms par token, et 15,615 ms avec 30 couches, soit +0,57 %. Gumbel ajoute 0,26 % et Soft Red List 0,28 %. Le tournoi coûte donc plus cher en relatif, mais l'écart absolu reste sous la milliseconde, et la complexité relative diminue quand le modèle grossit.

Qualité en production : 0,01 % et 0,02 % d'écart sur les pouces, non significatifs, et aucune différence significative sur la perplexité ni les benchmarks, détails en Supplementary C.5.

## 5. Ce que les papiers de Fernandez reprennent ou contredisent

SynthID-Text est la cible que TextSeal et TextSeal2 attaquent frontalement : c'est le système à battre, pas un allié.

Première contradiction, le coût. `textseal.md` mesure 0,43 ms par token pour TextSeal contre 0,37 ms sans watermark sur Qwen 3.5-0.8B, et 0,46 contre 0,39 sur 27B, quand SynthID coûte 0,60 à 0,63 ms par token. Le surcoût de SynthID est donc deux à trois fois celui de TextSeal sur ce matériel, même si les protocoles ne sont pas identiques, et un jury peut opposer au papier Nature que son « minimal » est relatif à son propre modèle.

Deuxième contradiction, la détectabilité et la diversité. `textseal.md` section 4.2 montre que TextSeal domine la frontière diversité-détectabilité face à SynthID, avec un gain de 1 à 2 ordres de grandeur en médiane de $-\log_{10} p$ quand l'entropie est calculée par le modèle 27B. `textseal2.md`, tableau 1, à 200 tokens et FPR $10^{-3}$, donne 89 % de TPR pour SynthID sans décodage spéculatif, puis 50 % avec, contre 91 % puis 89 % pour TextSeal2. C'est le chiffre le plus destructeur pour SynthID : la méthode perd près de la moitié de sa détectabilité quand on active l'optimisation de serving que le papier Nature présente comme intégrée.

Troisième point, la radioactivité, capacité à retrouver des traces dans les sorties d'un modèle distillé. `textseal.md` tableau 5 : TextSeal retient 2 352 traces à $-\log_{10} p = 33,15$, Gumbel-max 1 991 à 14,89, SynthID 2 408 à 14,39, le contrôle non filigrané 2 400 à 0,39. SynthID garde donc le plus de traces avec la preuve la plus faible, et la précision GSM8K de l'élève distillé est de 75,2 % avec SynthID contre 79,9 % avec TextSeal, pour 75,5 % avec le contrôle.

Ce que Fernandez reprend : les trois composants, le score comme moyenne de $g$ sur les fenêtres, et l'exigence d'un échantillonnage non distortionnaire compatible avec le serving. `public-detection.md` utilise SynthID-Text comme baseline avec profondeur 30 et $\gamma = 0,5$. Sa critique de fond : le FPR n'est contrôlé qu'empiriquement, et la fonction bayésienne est un classifieur appris, donc dépendant du modèle et des prompts.

## 6. Réutilisable en 24 h

Le dépôt `google-deepmind/synthid-text` est public et fournit la génération et la détection : la seule implémentation de watermark de texte de niveau production librement disponible, donc la brique de comparaison naturelle.

Trois usages. Le détecteur de référence : brancher SynthID sur un modèle HuggingFace et mesurer le TPR@1 % sur des longueurs variables coûte une heure et donne une baseline crédible. L'attaque de longueur : la détectabilité dépend du nombre de tokens, donc tronquer à 50 tokens suffit à faire tomber le TPR, démonstration de fragilité en dix minutes. Le mécanisme d'abstention : quelques lignes au-dessus de n'importe quel score, et une courbe TPR/FPR propre sans seuil arbitraire.

Deux pièges. Citer un TPR sans longueur ni FPR, alors que le papier ne publie que des courbes. Croire que le code donne le modèle : il donne l'algorithme, et il faut un LLM pour générer, donc prévoir un petit modèle local si l'on veut une démo en 24 h.
