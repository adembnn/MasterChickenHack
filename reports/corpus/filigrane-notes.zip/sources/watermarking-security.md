# Watermarking Security: Theory and Practice (2005)

Article publié dans IEEE Transactions on Signal Processing, volume 53, numéro 10, pages 3976 à 3987, 2005, dans le supplément « secure media III ». Auteurs : François Cayre, Caroline Fontaine et Teddy Furon, tous au laboratoire LIS de Grenoble à l'époque. Version accessible : HAL, identifiant inria-00088006, PDF téléchargeable sur https://inria.hal.science/inria-00088006.

Une précision bibliographique, la consigne annonçait « Cayre, Bas, Macq ». La notice HAL et l'en-tête donnent Cayre, Fontaine et Furon. Patrick Bas et Benoît Macq sont deux autres chercheurs en tatouage, qui publient sur la sécurité mais ne signent pas ce texte, et toute citation qui les mentionnerait serait fausse.

## 1. L'apport en trois phrases

Cet article fonde la sécurité du watermarking, en distinguant la robustesse, qui mesure si le message survit à une distorsion, de la sécurité, qui mesure si la clé fuit à travers les contenus marqués. Il formalise trois scénarios selon ce que possède l'attaquant, contenus seuls, contenus et messages, contenus et originaux, et donne pour chacun le nombre d'observations nécessaires pour estimer les porteuses, avec une borne de Cramér-Rao pour le spread spectrum. La pratique montre que ce n'est pas décoratif : sur 50 images en 512 par 512, un attaquant ayant estimé les porteuses sur environ 1 000 images détruit le message avec une distorsion inférieure de 15 dB à celle d'un attaquant aveugle.

## 2. Méthode, équations et hyperparamètres réellement donnés

Cadre de Kerckhoffs : l'algorithme est public, seule la clé est secrète. Précision importante, la clé n'est pas la graine du générateur pseudo-aléatoire mais les porteuses $u_\ell$, car les connaître suffit à attaquer.

Le modèle de spread spectrum est

$$y_j = x_j + \frac{\gamma}{\sqrt{N_c}} U a_j,$$

où $x_j \in \mathbb{R}^{N_v}$ est le contenu, $U$ la matrice $N_v \times N_c$ des porteuses orthonormées, $a_j$ le vecteur de symboles, et le rapport signal à bruit de tatouage vaut $\gamma^2\sigma_a^2/\sigma_x^2$, noté WCR et exprimé en dB. Pour le DSSS, $a^{(\ell)} = (-1)^{m^{(\ell)}}$ et $\sigma_a^2 = 1$.

Trois scénarios : WOA, watermarked only attack, avec $N_o$ contenus marqués seuls ; KMA, known message attack, avec les messages ; KOA, known original attack, avec les originaux. Le papier traite aussi la méthode substitutive, qui remplace des échantillons au lieu d'ajouter un signal, et démontre qu'elle réalise un « perfect covering » au sens de Shannon, $p_W(w) = p_W(w \mid y)$, donc une fuite nulle sur le message, sous la condition $H(W) \le H(X)$.

La mesure de fuite est l'équivoque de Shannon, $H(K \mid O^{N_o}) = H(K) - I(K; O^{N_o})$, insuffisante quand la clé est continue, d'où la matrice de Fisher et la borne de Cramér-Rao. Pour le DSSS en KMA,

$$\mathrm{FIM} = \frac{\gamma^2}{N_c\sigma_x^2} F_{uu} \xrightarrow{N_o \to \infty} \frac{\gamma^2\sigma_a^2}{N_c\sigma_x^2} N_o I_{N_c},$$

d'où le niveau de sécurité $N_o^* = N_c\sigma_x^2/\gamma^2$ paires contenu-message : le nombre d'observations nécessaires est proportionnel au nombre de porteuses et inversement proportionnel à la puissance du watermark, la relation la plus utile pour un praticien.

En KOA, la différence $d_j = y_j - x_j$ donne le sous-espace engendré par $U$, et le problème devient une séparation aveugle de sources. Le résultat de Comon s'applique : $U$ est identifiable à une permutation et un signe près, donc estimé à $\Pi\Sigma U$ près. Nuance essentielle, car permuter les symboles suffit à perdre le décodage.

L'efficacité de l'estimation est mesurée par la corrélation normalisée moyenne

$$\eta = \frac{1}{N_c}\sum_{\ell=1}^{N_c}\frac{\hat{u}_\ell^T u_\ell}{\|\hat{u}_\ell\|},$$

avec $\eta \lesssim 1$ quand l'estimation est bonne. Les algorithmes pratiques sont PCA puis ICA pour le DSSS, et des variantes pour les schémas substitutifs, MRE, ISS et SCS.

## 3. Protocole et métriques

Deux niveaux. Des vecteurs gaussiens synthétiques, $N_v = 512$, $N_c$ de quelques unités à quelques dizaines, symboles BPSK, WCR de $-15$ dB, et $N_o$ de 1 à plusieurs milliers. Puis des images réelles, Lena et 50 images en 512 par 512, avec une technique robuste de la littérature, $N_c = 8$ bits et 38 dB d'insertion.

Les métriques sont l'équivoque en bits, le niveau de sécurité $N_o^*$, l'efficacité $\eta$, et pour la partie pratique, le PSNR de l'attaque au moment où le message décodé devient faux, vérifié par un oracle. C'est un protocole de type challenge, avec deux adversaires comparés sur la même cible.

## 4. Résultats chiffrés

Figure 4, substitutif, $N_c = 64$ et $N_v = 512$ : l'équivoque reste maximale en WOA quel que soit $N_o$, ce qui confirme le perfect covering, s'effondre en KMA dès quelques dizaines d'observations, et plus vite encore en KOA.

Figure 5, KMA pour le DSSS, $N_c = 4$ : $\eta$ contre $\log_{10} N_o$ et le WCR en dB, avec la courbe théorique $N_o = N_c\sigma_x^2/\gamma^2$ superposée. L'accord théorie-expérience est le point fort du papier.

Figure 7, WOA pour le DSSS : les points de fonctionnement qui atteignent $\eta = 0,8$ sont tracés pour différents $N_c$ et $N_v$, et suivent la prédiction théorique. C'est la figure à citer si l'on veut savoir combien d'images il faut pour voler un watermark donné.

Figure 10, la pratique. Pirate A, aveugle, met l'image au quart, compresse en JPEG, remet à l'échelle, et obtient 21,8 dB de PSNR. Pirate B estime les porteuses par une WOA sur environ 1 000 images avec $\eta = 0,55$, retire l'information sur une porteuse, et obtient 35,8 dB. Sur les 50 images, l'écart moyen est de 15 dB en faveur de l'attaquant informé : 35,8 dB est presque intact, 21,8 dB est visiblement dégradé.

## 5. Ce que les papiers de Fernandez reprennent ou contredisent

Cet article n'apparaît dans aucune des notes de lecture des 24 papiers de Fernandez, et c'est notable quand Teddy Furon, co-auteur de l'article de 2005, est aussi co-auteur de plusieurs de ses papiers, dont Three Bricks, Functional Invariants, Radioactive et Voice Cloning. La théorie de la sécurité est donc dans sa famille intellectuelle, mais absente de ses références, qui ne convoquent que l'ouvrage de Cox pour la théorie classique.

Ce que cela change pour un jury. Fernandez évalue la robustesse et la calibration du FPR, pas la fuite de clé, et le cadre de 2005 dit que ces mesures sont orthogonales : un schéma peut être robuste et peu sûr si chaque image révèle un peu des porteuses. Les papiers qui touchent à la sécurité, `copy-removal.md` et `forging.md`, mesurent des attaques empiriques, jamais le nombre d'images nécessaires pour estimer un décodeur.

Il y a pourtant des points de contact chiffrés. La transplantation de résidu d'InvisMark, 97,6 % de bits récupérés sur une image jamais marquée, est un KOA pratique réalisé avec une seule paire contenu-original, alors que Cayre situe le KOA à $N_o \ge N_c$ observations, ce qui est cohérent : avec $N_c$ petit, une paire suffit. La conclusion est que les watermarks appris, qui encodent un message fixe, sont structurellement plus exposés que le spread spectrum de 2005, parce que leur « clé » est le message lui-même et qu'elle se lit sur une image.

Deuxième point de contact, la mesure. Cayre définit $\eta$ comme la corrélation entre porteuses estimées et vraies. Fernandez n'a pas d'équivalent : il mesure l'exactitude de bits et le TPR, jamais la qualité de l'estimation d'un décodeur par un attaquant. Un participant qui veut se démarquer peut donc introduire $\eta$ dans une évaluation de watermark d'image, et c'est une contribution originale en 24 h.

Ce que Fernandez reprend sans le nommer : la sécurité comme nombre d'observations nécessaires, et la séparation entre attaque aveugle et informée. `copy-removal.md` distingue ces deux régimes sans les nommer WOA et KOA.

## 6. Réutilisable en 24 h

Pas de code public, l'article date de 2005 et donne du pseudo-code. Tout est réimplémentable en numpy en une heure : la WOA sur un lot d'images marquées se ramène à une PCA sur les images empilées, puis une ICA, et $\eta$ tient en trois lignes.

Trois usages. Mesurer la fuite d'un watermark : prendre 1 000 images marquées par la même clé, faire une PCA, garder les $N_c$ composantes dominantes, calculer $\eta$ contre les porteuses connues et tracer $\eta$ contre le nombre d'images, ce qui reproduit la figure 5 sur n'importe quel schéma. L'attaque KOA par différence : avec des paires original et marqué, la moyenne des différences donne la direction du watermark, et la transplantation d'InvisMark en est une variante. Le calcul du niveau de sécurité : $N_o^* = N_c\sigma_x^2/\gamma^2$ se déduit du PSNR d'insertion et de la capacité, sans expérience, donc comparable entre méthodes en dix minutes.

Piège principal : croire que la WOA s'applique telle quelle aux watermarks appris. Le modèle de 2005 suppose un ajout linéaire avec des porteuses orthogonales, alors qu'un décodeur convolutif n'a pas cette structure, et la PCA sur les pixels ne retrouve pas ses filtres : la théorie donne un ordre de grandeur, pas une attaque prête à l'emploi. Second piège, l'équivoque et la borne de Cramér-Rao sont asymptotiques, et il faut quelques centaines d'échantillons pour que la courbe ressemble à celle du papier.
