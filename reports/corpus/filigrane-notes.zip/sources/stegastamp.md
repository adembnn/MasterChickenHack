# StegaStamp, Learning to Hide Hyperlinks in Physical Photos (2019)

Identifiant arXiv 1904.05343. Matthew Tancik, Ben Mildenhall, Ren Ng, UC Berkeley. Soumis le 11 avril 2019, publié à CVPR 2020. Code et poids publics : https://github.com/tancik/StegaStamp.

## 1. Ce que le papier apporte historiquement

StegaStamp déplace le watermarking du fichier numérique vers le monde physique : une image imprimée ou affichée, photographiée par un téléphone, doit rendre un lien de 56 bits. C'est le premier travail qui traite explicitement la chaîne impression, capture, détection, recadrage, décodage comme un tout, avec un réseau de détection appris et des augmentations qui simulent la photographie. Il introduit deux idées durables : la déformation de perspective aléatoire pendant l'entraînement, qui force le modèle à survivre à un mauvais alignement, et la transformation spatiale dans le décodeur, qui recale automatiquement le watermark avant lecture. Il établit aussi le protocole d'évaluation physique, avec six supports et trois caméras, qui reste la référence pour toute affirmation de robustesse dans le monde réel.

## 2. Méthode, équations et hyperparamètres

Trois réseaux : encodeur, décodeur, détecteur.

Encodeur. C'est un U-Net qui prend en entrée l'image $400\times400$ et un message de 100 bits. Le message passe par une couche entièrement connectée qui produit un tenseur $50\times50\times3$, répliqué spatialement et concaténé aux features de l'image au goulot du U-Net. La sortie est l'image marquée, obtenue par une connexion résiduelle. Le choix de 100 bits (tableau 2) laisse au moins 56 bits utiles après correction BCH.

Décodeur. Des convolutions à pas 2 réduisent la résolution, puis un réseau de transformation spatiale (spatial transformer) prédit une transformation affine et recale l'image avant la lecture. La sortie passe par une couche dense et une sigmoïde, une entropie croisée binaire par bit. L'ajout du spatial transformer est la réponse au problème central : le décodeur ne peut pas supposer un alignement parfait, puisque la photographie introduit forcément un décalage, une rotation, un changement d'échelle.

Détecteur. Un BiSeNet de segmentation sémantique est réajusté sur des StegaStamp insérés dans des images DIV2K ; un quadrilatère est ajusté à l'enveloppe convexe, puis une homographie ramène à $400\times400$. Il localise, sans lire.

Augmentations. Deux familles, pixel et spatial. Pixel : flou gaussien $\sigma\in[1,3]$, flou de mouvement de noyau 3 à 7 pixels, bruit gaussien $\sigma\sim\mathcal{U}[0,0,2]$, variation de luminosité et de contraste $m\sim\mathcal{U}[0,5,1,5]$ et $b\sim\mathcal{U}[-0,3,0,3]$, teinte $\pm0,1$, désaturation, JPEG de qualité $\mathcal{U}[50,100]$, et une courbe de réponse non linéaire inspirée de Shin et Song, $q(x)=x^3$ si $|x|<0,5$ et $q(x)=1-(1-x)^3$ sinon, qui modélise la réponse des imprimantes. Spatial : déformation de perspective avec un déplacement de coin jusqu'à 40 pixels, soit environ 10 % de la taille, et redimensionnement.

Pertes. La perte totale combine quatre termes, $L=\lambda_R L_R+\lambda_P L_P+\lambda_C L_C+\lambda_M L_M$, où $L_R$ est une erreur quadratique pondérée par les contours pour ne pas pénaliser les zones de fort gradient où l'œil ne voit pas le résidu, $L_P$ est LPIPS, $L_C$ est une perte de critique, et $L_M$ l'entropie croisée sur les bits. Le papier précise que les poids sont ajustés pour que l'exactitude converge au-dessus de 95 %, mais il ne donne ni taux d'apprentissage, ni taille de lot, ni nombre d'itérations, ce qui est une lacune de reproductibilité à signaler.

Entraînement progressif. Les auteurs commencent sans perturbation et augmentent l'intensité progressivement, sinon l'encodeur converge vers une solution triviale. Cette idée de curriculum revient dans presque tous les travaux suivants, y compris chez Fernandez.

## 3. Protocole et métriques

La première évaluation est synthétique : 100 images, intensité de chaque perturbation balayée de 0 à 2, où 1 est le maximum vu à l'entraînement (figure 7). La seconde est physique et c'est la contribution méthodologique : 105 images ImageNet, chacune avec cinq messages supplémentaires, imprimées sur trois imprimantes (HP LaserJet Pro M281fdw, HP LaserJet Enterprise CP4025, Xerox 700i) ou affichées sur trois écrans (Dell ST2410 mat, MacBook Pro 15 pouces brillant, iPhone X OLED), puis photographiées avec trois caméras (webcam Logitech C920, Pixel 3, Canon 5D Mark II), soit 18 combinaisons et 1 890 captures. Les images sont recadrées à la main et redressées avant décodage, ce qui isole la performance du décodeur de celle du détecteur. Métrique : exactitude binaire, avec les 5e, 25e et 50e percentiles et la moyenne.

## 4. Résultats chiffrés

Physique (tableau 1). Moyenne de 98,7 % sur les 1 890 captures. Deux tiers des scénarios atteignent une médiane de 100 % avec un 5e percentile d'au moins 95 %. Les cas difficiles restent au-dessus de 90 % en moyenne, et le pire scénario de la table est à 88 % au 5e percentile. C'est la distribution qui compte : le 5e percentile décide si un utilisateur peut scanner.

Qualité (tableau 2, 500 images). À 50 bits, PSNR 29,88 dB, SSIM 0,930, LPIPS 0,100. À 100 bits, 28,50 dB, 0,905, 0,101. À 150 bits, 26,47 dB, 0,876, 0,128. À 200 bits, 21,79 dB, 0,793, 0,184. Le décrochage entre 150 et 200 bits est net, et il justifie le choix de 100.

Comparaison physique (figure 6, couple imprimante grand public et Pixel 3). Baluja, entraîné sans augmentation, et la variante sans perturbation sont au hasard. HiDDeN se situe entre les variantes Pixelwise et Spatial de StegaStamp : il pâtit de l'absence d'augmentations spatiales. LFM fonctionne bien sur écran mais échoue sur impression. La variante All, seule, atteint une exactitude utilisable de façon fiable.

Ablation synthétique (figure 7). Sans perturbation spatiale, le modèle s'effondre dès que la déformation de perspective ou le flou dépasse l'intensité 1. Sans perturbation pixel, il est sensible aux changements de couleur. Les deux familles sont nécessaires, et c'est la démonstration expérimentale qui a convaincu la communauté que l'augmentation géométrique n'est pas un détail.

## 5. Ce que Fernandez reprend, ce qu'il change

StegaStamp est cité dans tout le corpus comme la référence de la robustesse physique et comme baseline de qualité. Le tableau 1 de TrustMark le mesure à 37,48 dB de PSNR et SSIM 0,99 sur CLIC, avec une exactitude de 0,88 en propre et 0,72 en bruité, ce qui est nettement en dessous des méthodes récentes mais reste le témoin de ce qu'une méthode de 2019 savait faire. Pixel Seal ne l'inclut pas dans son banc, et le papier de Fernandez qui en parle le plus est celui sur la robustesse vidéo, où il sert de repère historique.

Ce qui est repris. La connexion résiduelle et le U-Net comme encodeur sont devenus la base de l'architecture de TrustMark, qui utilise un encodeur U-Net avec fusion précoce du message. La transformation spatiale du décodeur est reprise dans SyncSeal, où le recalage est explicite et constitue la contribution principale. Les augmentations physiques, perspective, flou de mouvement, réponse non linéaire des imprimantes, sont la matrice de tous les pools d'augmentation de Fernandez, même quand celui-ci travaille sur des images générées et non imprimées. Enfin le curriculum, commencer facile et durcir, est explicitement utilisé dans Stable Signature et dans WAM.

Ce qui est changé. Premièrement, la sortie n'est plus une image marquée mais un résidu dans un latent ou dans les poids d'un décodeur, ce qui supprime le problème de la perceptibilité en zones plates, faiblesse que StegaStamp reconnaît lui-même. Deuxièmement, le détecteur disparaît : les méthodes de Fernandez supposent un recadrage raisonnable et mesurent la robustesse au recadrage, plutôt que d'entraîner un localisateur. Troisièmement, la capacité et la métrique changent : 100 bits avec BCH et exactitude binaire chez StegaStamp, 32 à 256 bits avec p-value calibrée chez Fernandez, ce qui rend les tableaux non comparables directement. Quatrièmement, StegaStamp est un modèle de stéganographie, il cache un lien, alors que Fernandez traite de provenance : la question n'est pas de retrouver un message choisi mais de décider si une image vient d'une source, ce qui déplace l'effort vers les faux positifs.

## 6. Réutilisable en 24 h

Le dépôt tancik/StegaStamp est public, avec code, poids et décodeur temps réel. C'est la seule source de cette liste qui permette une démonstration physique en une journée : imprimer une image, la photographier, lire le message.

Trois usages concrets. Premier, la démo physique : encoder 100 bits, imprimer, scanner avec un téléphone, afficher le lien. Deuxième, le spatial transformer comme brique : si un participant attaque une méthode par recadrage ou rotation, il peut ajouter ce module au décodeur et mesurer le gain, ce qui est une expérience de deux heures. Troisième, les augmentations pixel exactes, notamment la courbe $q(x)$, qui sont réutilisables telles quelles dans n'importe quel pipeline de watermarking robuste à l'impression.

Les pièges. Le détecteur BiSeNet est le point faible réel, et un participant qui évalue bout en bout mesurera surtout son échec de localisation, pas celui du watermark. Il faut évaluer à quadrilatère fourni, comme le papier. Le deuxième piège est la résolution : le modèle est entraîné à $400\times400$, et l'appliquer à une photo de téléphone demande un redimensionnement qui change la distribution. Le troisième est l'absence d'hyperparamètres d'entraînement dans le papier : reproduire le modèle depuis zéro n'est pas réaliste en 24 h, il faut les poids publiés.
