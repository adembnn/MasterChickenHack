# TrustMark, Robust Watermarking for Creative Workflows (2023)

Identifiant arXiv 2311.18297. Tu Bui (University of Surrey), Shruti Agarwal (Adobe Research), John Collomosse (Surrey et Adobe). Soumis le 27 novembre 2023. Code et modèles publiés par Adobe : https://github.com/adobe/trustmark.

## 1. Ce que le papier apporte historiquement

TrustMark est le travail qui industrialise le watermarking profond pour les flux de création : il vise les images de travail, pas les sorties de générateur, et il traite trois problèmes que la littérature avait laissés de côté, la résolution arbitraire, la qualité perçue en haute fréquence, et la suppression puis le remplacement du watermark lors d'un réencodage. Il introduit une méthode de mise à l'échelle du résidu qui permet d'appliquer un modèle entraîné à $256\times256$ sur des images de plusieurs milliers de pixels sans réentraîner. Il publie aussi un réseau de retrait, TrustMark-RM, qui restaure l'image presque parfaitement et sert à la fois de démonstration de fragilité et d'outil pour le réencodage. C'est enfin le premier papier de cette lignée à mesurer explicitement la résistance à l'inpainting et au splicing avec des TPR par scénario, métrique que Fernandez reprendra partout.

## 2. Méthode, équations et hyperparamètres

Architecture en trois blocs. L'embedder fait une fusion précoce : le message, un vecteur de 32 à 200 bits, est projeté et concaténé aux features d'entrée avant le générateur. Le générateur est dérivé de MUNIT, donc à base de convolutions et de normalisations, et produit une image marquée qui n'est pas un simple résidu. Les couches de post-traitement sont des convolutions $1\times1$ avec SiLU et tangente hyperbolique, ce qui borne la sortie et évite les dépassements. L'extracteur est un ResNet50 suivi d'une couche dense et d'une sigmoïde, une entropie croisée binaire par bit.

Modèle de bruit. Dix-huit transformations, toutes différentiables : trois géométriques (flip aléatoire, recadrage, redimensionnement) et quinze perturbations (JPEG, luminosité, teinte, contraste, netteté, color jitter, décalage RGB, saturation, niveaux de gris, flou gaussien, flou médian, flou box, flou de mouvement, bruit gaussien, postérisation). Chaque image encodée subit les trois transformations de base et deux perturbations tirées au sort, ce qui donne une combinatoire bien plus large que les pools de HiDDeN ou de MBRS.

Pertes. La perte totale est

$$\mathcal{L}_{total}=\alpha\mathcal{L}_{quality}(x,y)+\mathcal{L}_{recovery}(w,\bar{w}),$$

avec $\mathcal{L}_{recovery}$ l'entropie croisée binaire. La qualité combine quatre termes :

$$\mathcal{L}_{quality}=\beta_{YUV}\mathcal{L}_{YUV}+\beta_{LPIPS}\mathcal{L}_{LPIPS}+\beta_{FFL}\mathcal{L}_{FFL}+\beta_{GAN+GP}\mathcal{L}_{GAN+GP},$$

avec $\beta_{LPIPS}=1$, $\beta_{YUV}=1,5$, $\beta_{FFL}=1,5$, $\beta_{GAN}=1$. Le terme original est la focal frequency loss,

$$\mathcal{L}_{FFL}(x,y)=\rho_{f(x),f(y)}\left\|f(y)-f(x)\right\|_2,$$

où $f$ est la transformée de Fourier 2D et $\rho$ une matrice de poids dynamique de taille $256\times256\times3$ qui équilibre l'erreur sur le spectre. L'idée vient des travaux sur les artefacts fréquentiels des images générées, et TrustMark la détourne pour forcer le watermark à préserver les hautes fréquences, donc les textures.

Contrôle de qualité. $\alpha$ démarre bas, pour prioriser la récupération du message, et monte linéairement jusqu'à un seuil $\alpha_{max}$ fixé avant entraînement : 27,5 pour TrustMark-Q, 20 pour TrustMark-B, 15 dans une variante testée. C'est un paramètre de déploiement, pas un hyperparamètre caché : il règle le compromis imperceptibilité robustesse sans réentraîner.

Mise à l'échelle. L'algorithme redimensionne l'image à $256\times256$, encode, calcule le résidu, redimensionne le résidu à la résolution d'origine, l'ajoute et borne. C'est ce qui permet d'appliquer un modèle à une image 4K, et le papier vérifie que le coût en qualité reste contenu.

Entraînement. 101 000 images MIRFlickr 1M, 1 000 pour validation, 150 époques, AdamW à $4\times10^{-6}$, lot de 32, cosinus. 48 heures sur RTX 3090 et un i7. Inférence : 125 ms pour l'encodage, 25 ms pour le décodage. TrustMark-RM est entraîné à part, $n=3$, environ deux semaines sur A100, 100 époques, lot de 8.

## 3. Protocole et métriques

Trois jeux : CLIC, DIV2K (900 images 2K, entraînement et validation, le test n'étant pas public) et MetFace, un jeu de visages. Métriques : PSNR, SSIM, LPIPS pour la qualité, exactitude binaire propre et bruitée pour la robustesse. Baselines : StegaStamp, Stable Signature, et RoSteALS, dont les chiffres sont repris tels quels. Deux variantes, Q et B, avec des $\alpha_{max}$ différents, tracent une frontière et pas un point.

Tests supplémentaires : retrait par TrustMark-RM et I-FGSM, inpainting et splicing en TPR, ablation des pertes, longueur de message, attaques adversariales.

## 4. Résultats chiffrés

Qualité (tableau 1). TrustMark-Q : 43,26 dB de PSNR sur CLIC, 42,39 sur DIV2K, 45,34 sur MetFace, SSIM 0,99 partout. TrustMark-B : 41,53, 40,20, 43,87. StegaStamp : 37,48 sur CLIC. Stable Signature est à 42,74 dB sur CLIC, donc comparable en qualité, mais avec une exactitude bruitée de 0,60 contre 0,95 pour TrustMark-Q et 0,97 pour TrustMark-B. À qualité égale, TrustMark tient deux fois mieux le bruit.

Longueur de message (section 4.4 et figure). De 32 à 200 bits, le PSNR perd environ 7,5 dB et l'exactitude 11 %, ce qui est le prix de la capacité. Le modèle est réglable, pas gratuitement.

Retrait et réencodage (tableau 3 et figure 3). TrustMark-RM restaure l'image à 48,48 dB de PSNR tout en laissant 0,553 d'exactitude binaire, donc le watermark est à moitié détruit. I-FGSM, attaque adverse, descend à 23,48 dB de PSNR pour 0,629 d'exactitude : l'attaque qui casse le watermark détruit l'image. C'est l'argument de sécurité : le retrait propre et la préservation de la qualité sont incompatibles.

Inpainting et splicing. TrustMark atteint 100 % de TPR en identité, 39,4 % en inpainting et 83,2 % en splicing dans le tableau de WAM, ce qui est la référence de l'époque et reste faible sur l'inpainting.

Ablation (section 4.5). Sans GAN, sans FFL, sans post-traitement $1\times1$, le PSNR tombe à 36,300 dB ; avec les trois, 40,203 dB. Les gains sont de 0,7, 1,6 et 1,7 dB respectivement. C'est la justification expérimentale de la focal frequency loss.

Adversarial (section 4.6). Sans entraînement au bruit, le watermark casse en moins de 50 itérations. Avec un bruit d'intensité élevée, il en faut plus de 3 000 pour 32 % de bits faux, ce qui montre que l'augmentation lourde est aussi une défense adverse.

## 5. Ce que Fernandez reprend, ce qu'il change

TrustMark est la baseline la plus présente du corpus Fernandez, avec MBRS. WAM la mesure à 40,3 dB de PSNR, 0,01 de LPIPS, 100 % de TPR en identité, 39,4 % en inpainting, 83,2 % en splicing, et note qu'elle plafonne à 0,62 en score combiné. Video Seal la mesure à 0,53 en combiné et 0,65 en géométrique. Pixel Seal la mesure en deux variantes : TrustMark-P à 49,0 dB, SSIM 0,9908, JND 0,19, le meilleur JND du banc, mais 0,52 en combiné ; TrustMark-Q à 43,3 dB, JND 1,66, 0,54 en combiné. SyncSeal la remonte de 0,71 à 0,97 en exactitude sous transformations géométriques. Forging la trouve la plus résistante à la volée de watermark, avec un plafond de 0,61.

Ce qui est repris. Le modèle de bruit à 18 transformations est la matrice des pools de Fernandez, et la distinction entre transformations géométriques de base et perturbations optionnelles se retrouve dans SyncSeal et Video Seal. La focal frequency loss et la combinaison YUV, LPIPS, GAN sont devenues des composants standard de qualité. La mise à l'échelle du résidu est reprise telle quelle dans Pixel Seal et Video Seal pour traiter la haute résolution, Enfin la mesure de TPR par scénario, inpainting et splicing, est le format d'évaluation que Fernandez impose.

Ce qui est changé. Premièrement, le watermark quitte le pixel : Pixel Seal et Video Seal insèrent dans un latent ou dans les poids d'un décodeur, ce qui supprime le résidu visible et rend la mise à l'échelle moins nécessaire. Deuxièmement, la détection devient un test statistique : TrustMark publie une exactitude binaire, Fernandez publie des p-values et des TPR à FPR fixé, ce qui permet de comparer des capacités différentes. Troisièmement, la localisation : TrustMark marque l'image entière, WAM marque des zones de 10 % et permet de dire quelle partie a été modifiée. Quatrièmement, la robustesse géométrique devient l'axe principal, et les chiffres de Pixel Seal montrent que TrustMark, malgré sa qualité, tombe à 0,52 en combiné, ce que Fernandez présente comme la limite des méthodes par résidu pixel.

## 6. Réutilisable en 24 h

Le dépôt adobe/trustmark est public, avec les poids Q et B, une API Python simple, et les modèles de retrait. Baseline facile à faire tourner, avec Video Seal.

Trois usages. Premier, la démo de réencodage : encoder, passer TrustMark-RM, réencoder, mesurer ce qui reste. Le papier donne 0,553 après retrait ; reproduire prend une heure. C'est une démonstration de la fragilité du watermark face au retrait. Deuxième, la mise à l'échelle : appliquer le modèle $256\times256$ à une image 4K avec l'algorithme du résidu et mesurer la perte de qualité, ce qui est utile pour toute piste haute résolution.

Deux pièges. Le premier est la confusion entre les variantes : TrustMark-Q et TrustMark-B n'ont pas le même $\alpha_{max}$ et ne se comparent pas à la même ligne du tableau. Le second est la résolution : le modèle est entraîné à $256\times256$, et l'appliquer sans l'algorithme de mise à l'échelle donne des artefacts et une chute d'exactitude.
