# AudioSeal, detection proactive du clonage de voix (arXiv 2401.17264)

San Roman, Fernandez, Elsahar, Defossez, Furon, Tran, « Proactive Detection of Voice Cloning with Localized Watermarking », v2 du 6 juin 2024 (ICML 2024). Texte integral lu, version HTML arXiv (79 732 caracteres, 2083 lignes).

## 1. Probleme et revendications

La detection passive des voix synthetiques (classifieur binaire entraine a separer vrai et faux) est structurellement fragile : elle apprend des artefacts de vocodeur, donc elle se degrade quand le generateur s'ameliore, et elle ne dit rien sur l'origine. Les auteurs proposent l'inverse : marquer la voix au moment de la generation, avec un filigrane localise, de facon a repondre a trois questions distinctes. L'audio est-il genere ? Ou exactement, dans un montage de dix secondes, se trouve le passage genere ? Quelle version du modele l'a produit ?

Trois revendications : (i) premiere technique de watermarking audio concue pour la detection localisee, avec un detecteur qui sort un logit par echantillon ; (ii) une perte perceptuelle nouvelle inspiree du masquage auditif, qui ameliore l'imperceptibilite a puissance egale ; (iii) un etat de l'art en detection, localisation et attribution, avec une vitesse de detection deux ordres de grandeur superieure a WavMark.

Le point important pour un hackathon : le systeme est proactif, il ne devine pas, il verifie une marque. Toute la problematique se deplace donc vers l'attaquant qui veut effacer la marque.

## 2. Methode, equations, hyperparametres

Architecture generateur/detecteur entrainee conjointement. Le generateur G recoit le signal s et produit un residu delta_w ajoute a s ; l'imperceptibilite vient d'une somme de pertes perceptuelles, ponderees par mise a l'echelle des gradients comme dans EnCodec : norme l1 sur le residu, perte multi-echelle sur spectrogramme Mel, pertes adversariales sur des spectrogrammes STFT multi-echelles. S'y ajoute une perte de sonie temps-frequence (TF-Loudness) propre a l'article : le signal est decoupe en B bandes de frequence non recouvrantes, chaque bande est fenetree (taille W, recouvrement r), et on calcule

l_b^w = Loudness(delta_b^w) - Loudness(s_b^w)

ou la sonie suit la recommandation ITU-R BS.1770-4. L'idee est psychoacoustique : on tolere un residu plus fort la ou l'oreille ne peut pas le percevoir (masquage simultane, meme temps et meme bande). Le detecteur D sort un logit par echantillon temporel et est entraine avec une perte de localisation L_loc (BCE par echantillon contre un masque binaire y').

Version multi-bit : une couche de traitement de message est inseree au milieu du generateur, elle prend une carte d'activation dans R^{h x t'} et un message m dans {0,1}^b, et produit e = somme_{i=0..b-1} E_{2i+m_i} dans R^h, avec E dans R^{2b x h} une couche d'embedding apprenable ; e est repete t fois sur l'axe temporel. En detection, b couches lineaires sont ajoutees a la sortie du detecteur, qui rend un tenseur de forme R^{t x (1+b)} : une colonne de detection, b colonnes de bits. La perte d'decodage L_dec moyenne la BCE entre message original et sorties du detecteur sur les zones ou le filigrane est present.

Hyperparametres donnes : 4,5k heures de VoxPopuli, 16 kHz, extraits d'une seconde donc T = 16 000 ; 600k pas, Adam, learning rate 1e-4, batch 32 ; augmentation « drop » avec k = 5 fenetres de 0,1 s ; h = 32 canaux, b = 16 bits de message. Inference : detection par moyenne du score sur l'audio, seuil par defaut 0,5 ; localisation par seuil par echantillon ; attribution par moyenne du message sur les zones detectees puis distance de Hamming minimale parmi les messages connus.

## 3. Protocole et metriques

Detection et localisation : 10k audios filigranes et 10k non filigranes de 10 s (VoxPopuli validation), plus des jeux edites. Metriques : accuracy au meilleur seuil avec TPR et FPR associes, et AUC de la courbe ROC. Localisation : accuracy par echantillon et IoU entre masque predit et masque vrai ; WavMark est compare en detection par fenetre glissante de 1 s avec pas de 0,05 s.

Qualite : SI-SNR, PESQ, ViSQOL, STOI objectifs, plus test subjectif MUSHRA (protocole detaille en annexe D.4), avec une note moyenne de 80,49 pour les echantillons de reference.

Attribution : 100 messages aleatoires de 16 bits, 1k clips de 5 s par message, soit 100k audios ; detection a FPR 10^-3 puis plus proche voisin en distance de Hamming parmi N messages, N allant de 1 a 10^4. Metriques : accuracy d'attribution et taux de fausse attribution (FAR).

Attaques : trois niveaux de connaissance. White-box (acces au detecteur, attaque par gradient, bruit adversarial optimise en 100 pas d'Adam avec contrainte de norme), semi black-box (reentrainement d'une paire generateur/detecteur de meme architecture sur les memes donnees, utilisee comme proxy), black-box (acces a une API filigranee et a des negatifs publics, entrainement d'un classifieur a 80k/80k echantillons de 8 s, verification a 100 % d'accuracy en validation, puis attaque du classifieur). Qualite mesuree par PESQ entre audio attaque et audio genuin.

## 4. Resultats chiffres

Qualite : AudioSeal n'optimise pas le SI-SNR mais les metriques perceptuelles, et gagne sur PESQ, STOI et ViSQOL face a WavMark (Table 1), avec une note MUSHRA proche de la reference (80,49).

Detection sous editions (Table 3, moyenne sur 14 edits) : accuracy 0,96, TPR 0,98 a FPR 0,04, AUC 0,97, contre 0,85 / 0,85 / 0,14 / 0,84 pour WavMark. Le detail est instructif : highpass est le point faible (0,61 d'accuracy, AUC 0,61 ; WavMark fait 1,00 la ou AudioSeal s'effondre), alors qu'AudioSeal gagne massivement sur lowpass (0,99 contre 0,50), bruit blanc (0,91 contre 0,50), acceleration 1,25x (0,99 contre 0,50) et surtout EnCodec (0,98 contre 0,51). AAC et MP3 sont a 1,00.

Localisation : IoU de 0,99 quand une seule seconde de parole est generee dans un clip, contre 0,35 pour WavMark, et detection de segments tres courts (la figure 5 fait varier la proportion de parole filigranee).

Comparaison au classifieur passif de Voicebox (Table 2) : sur « original contre genere », les deux sont parfaits. Sur « re-synthetise contre genere », le classifieur tombe a 0,704 d'accuracy a 30 % de masquage, 0,809 a 50 %, 0,907 a 90 %, avec des FPR de 0,194, 0,170, 0,112 ; AudioSeal reste a 1,0 partout. C'est l'argument central : le passif detecte des artefacts de vocodeur, pas la generation.

Attribution (Table 4) : a N = 1, accuracy 68,2 % (AudioSeal) contre 58,4 % (WavMark), FAR nulle pour les deux. A N = 10^4, 56,4 % contre 54,4 %, avec FAR 11,84 % contre 4,02 %. AudioSeal accepte donc plus de fausses attributions pour mieux detecter, ce que les auteurs assument explicitement : « decoupling detection and attribution achieves better detection rate and makes the global accuracy better, at the cost of occasional false attributions ».

Efficacite (Table 5, figure 6) : generation 14x plus rapide que WavMark, detection 485x plus rapide en moyenne quand il n'y a pas de filigrane, deux ordres de grandeur en moyenne, grace a l'absence de synchronisation (WavMark fait 20 passes pour une fenetre d'une seconde).

Attaques (figure 7) : le white-box est de loin le plus efficace, environ +80 % d'erreur de detection en gardant PESQ > 4. Les autres demandent une degradation audible pour atteindre +50 %. Conclusion des auteurs : publier le code d'entrainement et le fait que les audios sont filigranes est acceptable, garder les poids du detecteur secrets ne l'est pas moins.

## 5. Ce qui manque

La localisation est presentee comme l'apport principal mais n'est evaluee que sur des remplacements de segments par de l'audio non filigrane ; pas de test sur des coupes, des fondus, du montage realiste, ni sur de la musique en fond.

L'attribution est faible en absolu : 56 % a N = 10^4 signifie que sur dix mille versions, presque une attribution sur deux est fausse. Un deployeur ne peut pas s'en contenter : il manque une etude du compromis detection et attribution avec codes correcteurs d'erreurs.

Le white-box gagne avec environ +80 % d'erreur a PESQ > 4 : garder le detecteur secret est une hypothese de securite par obscurite, non testee contre une extraction de detecteur par distillation.

Rien sur les codecs neuronaux recents autres qu'EnCodec, ni sur les attaques par regeneration (speech-to-speech, changement de locuteur), qui sont le vrai mode d'attaque contre un filigrane de voix. Enfin, le papier ne donne pas de garantie statistique sur le seuil et choisit le seuil qui maximise l'accuracy, ce qui est optimiste par construction.

## 6. Usage concret en hackathon 24 h

C'est le papier le plus directement exploitable du lot : le modele est publie, la tache est bien posee, et le protocole d'attaque est decrit assez precisement pour etre reproduit. En 24 h, on peut monter un banc « filigrane contre editeur audio » : appliquer les 14 edits du tableau 3 a un jeu de 500 clips filigranes et 500 non filigranes, tracer TPR a FPR fixe, et identifier le point de rupture (highpass, comme dans le papier).

Deuxieme projet, plus original : reprendre l'attaque white-box de la section 6 et mesurer le cout en PESQ pour casser le detecteur. Le resultat publie (+80 % d'erreur a PESQ > 4) est un point de depart ; le refaire sur un modele de voix moderne et montrer que le seuil de rentabilite de l'attaquant est bas serait un resultat de hackathon credible.

Troisieme usage, en detection defensive : combiner AudioSeal et un classifieur passif, et montrer que les deux se trompent sur des ensembles disjoints (le paper suggere que le passif detecte le vocodeur). Une matrice de confusion croisee sur 1k clips suffit a faire un slide memorable.
