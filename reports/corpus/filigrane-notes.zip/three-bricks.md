# Trois briques pour consolider les watermarks de LLM

Note de lecture de arXiv:2308.00113v2, « Three Bricks to Consolidate Watermarks for Large Language Models », Pierre Fernandez, Antoine Chaffin, Karim Tit, Vivien Chappelier, Teddy Furon (Inria Rennes, Imatag, Meta FAIR), 8 novembre 2023, WIFS 2023.

## 1. Problème et revendications

Le papier part d'un constat désagréable : la littérature du watermarking de texte mesure surtout la sensibilité, c'est-à-dire la proportion de textes watermarkés détectés, et très peu la spécificité, c'est-à-dire le taux de faux positifs. Ce taux n'a jamais été vérifié à une échelle sérieuse. Or un faux positif, c'est accuser à tort un utilisateur de diffuser de la désinformation, ou un étudiant de tricher.

La revendication est que les tests statistiques utilisés jusqu'ici sont mal fondés. Les schémas reposent sur un test Z, qui suppose une normalité asymptotique du score. Cette hypothèse casse sur les textes courts ou répétitifs, et les seuils publiés sous-estiment largement les faux positifs dans la zone qui compte, celle des très faibles taux. Le papier remplace ce test par des tests exacts, ajoute une règle de scoring qui rétablit l'indépendance des observations, et valide empiriquement le taux de faux positifs jusqu'à 10⁻⁶.

Les deux autres briques sont pratiques : évaluer l'impact du watermark sur des benchmarks aval de génération libre plutôt que sur la perplexité, et étendre la détection aux régimes avancés, test optimal quand on accède au modèle et watermarking multi-bit pour identifier une version ou un utilisateur.

## 2. Méthode

Deux familles de schémas sont considérées. Kirchenbauer et al. partitionnent le vocabulaire en liste verte de taille γ|V|, ajoutent δ aux logits des tokens verts, puis échantillonnent normalement. Aaronson et Kirchner tirent un vecteur secret r uniforme sur [0,1]^|V| et choisissent le token qui maximise r_v^{1/p_v}. Ce second schéma a la propriété, démontrée en annexe A, que la loi marginale du token généré reste p_v lorsqu'on moyenne sur la clé.

La clé n'est pas fixe : elle est dérivée par hachage de la fenêtre des h tokens précédents et d'une clé maître, k^(t) = H(x^(t−1), ..., x^(t−h), k). Ce mécanisme assure l'auto-synchronisation, ce qui compte quand un passage du texte est supprimé. La largeur h arbitre entre diversité de clé et robustesse : h = 0 donne une clé unique pour tous les tokens, donc un watermark très robuste à l'édition mais peu diversifié.

La contribution statistique centrale : sous H0, pour Kirchenbauer, l'événement « le token est dans sa liste verte » est supposé de probabilité γ et indépendant d'un token à l'autre. Le score S_T, nombre de tokens verts, suit donc une binomiale B(T, γ), et la p-value s'écrit par la fonction bêta incomplète régularisée, p-value(s) = I_γ(s, T − s + 1). Pour Aaronson, sous H0, r suit une uniforme et S_T = −Σ ln(1 − r_{x^(t)}) suit une loi Gamma Γ(T, 1), d'où p-value(s) = Γ(T, s)/Γ(T) avec Γ la fonction gamma incomplète supérieure. Ces formules suppriment l'hypothèse gaussienne.

Reste un problème que le papier isole bien : même avec un test exact, les faux positifs empiriques restent trop élevés, parce que les variables ne sont pas vraiment aléatoires. Les fenêtres se répètent, notamment dans les textes formatés. L'exemple donné est une liste à puces où la séquence de début de ligne revient en boucle : sur un texte naturel de ce type, avec γ = 1/4 et T = 256, le watermark Green-Red produit une p-value de 10⁻²¹ alors que le texte n'est pas watermarké. Deux heuristiques sont comparées : dédupliquer la fenêtre seule, ou le couple fenêtre-token. La seconde est retenue, parce qu'elle compte plus de n-grammes et améliore la TPR, et parce qu'elle fonctionne encore quand h = 0.

La détection avancée ajoute deux choses. Quand on accède au modèle, le score optimal au sens de Neyman-Pearson pour le schéma d'Aaronson s'écrit comme une somme de log-rapports de vraisemblance, avec r_v distribué selon Beta(1/p_v, 1) sous H1. Il est optimal mais exige de calculer p_{x^(t)} à la détection et n'a pas de formule fermée pour la p-value ; l'approximation par borne de Chernoff est fragile, et toute attaque le ramène au niveau du détecteur d'origine. Une variante sans pondération, S_T = Σ ln(r_{x^(t)}), est proposée avec une p-value explicite.

Le multi-bit est construit par décalage circulaire. On tire un vecteur r de dimension d, avec d au moins égal à |V|, et l'on définit le vecteur secret du message m comme r^(m) = CyclicShift(r, m). On garde les |V| premières coordonnées de chaque version décalée, ce qui encode M messages avec M ≤ d, donc potentiellement plus de messages que la taille du vocabulaire. Le décodage teste les M clés et retient celle qui donne la plus petite p-value, avec une correction globale p = 1 − (1 − p_m)^M.

## 3. Protocole expérimental

La validation du taux de faux positifs est la partie la plus soignée. Les auteurs tirent 100 000 textes de Wikipedia multilingue, les tokenisent avec le tokenizer de LLaMA et les tronquent à 256 tokens. Ils répètent avec 10 clés maîtres, soit un million de tests sous H0 par méthode et par valeur de h. Pour Green-Red, γ = 0,25. Les taux empiriques sont comparés aux taux théoriques jusqu'à 10⁻⁶.

L'évaluation aval utilise des LLaMA de 7B, 13B et 30B, avec le protocole de LLaMA : exact match 5-shot sur Natural Questions et TriviaQA, exact match sans vote majoritaire sur MathQA et GSM8K, pass@1 sur HumanEval et MBPP. Pour Kirchenbauer, δ = 1,0 avant décodage glouton. Pour Aaronson, top-p 0,95 puis échantillonnage watermarké. Les fenêtres h testées sont 0, 1, 2, 3, 4, 6 et 8.

La robustesse est mesurée en TPR à FPR = 10⁻⁵, sur 10 fois 1 000 complétions. Le modèle est Guanaco-7b, version instruction de LLaMA, amorcé avec les 1 000 premiers prompts d'Alpaca, top-p 0,95, température 0,8 et γ = 1/4 pour Kirchenbauer. L'attaque remplace aléatoirement des tokens avec une probabilité de 0,3. La similarité est mesurée par S-BERT entre texte watermarké et non watermarké.

L'identification multi-bit simule 1 000 utilisateurs générant chacun 100 textes avec Guanaco-7b, top-p 0,95, δ = 3,0 et γ = 1/4 à température 0,8 pour Kirchenbauer, θ = 1,0 pour Aaronson, h = 4 dans les deux cas. Les textes font entre 4 et 252 tokens, 149 en moyenne. Trois erreurs sont distinguées : faux positif sur texte naturel, faux négatif sur texte watermarké, et fausse accusation quand le texte est bien détecté mais attribué au mauvais utilisateur.

## 4. Résultats chiffrés

La figure 2 est le résultat central. Avec le test Z, les taux de faux positifs empiriques dépassent largement les taux théoriques, et les distributions de p-values ne sont pas uniformes sous H0. L'écart se réduit quand h augmente, mais il faudrait h bien supérieur à 8 pour obtenir des p-values fiables, ce qui dégraderait la robustesse à la synchronisation. Avec les tests exacts et le scoring corrigé, les courbes empiriques et théoriques coïncident presque parfaitement, sauf pour h = 0 où le taux reste légèrement sous-estimé.

Le tableau I donne l'impact sur les benchmarks. Pour le 7B sans watermark, la moyenne sur six tâches est 20,5. Avec Aaronson, elle reste à 20,5 pour h = 1 et 20,4 pour h = 4. Avec Kirchenbauer, elle tombe à 19,1 pour h = 1 et h = 4. Pour le 13B, la référence est 25,3, Aaronson donne 25,2 et Kirchenbauer 24,0 à 24,1. Pour le 30B, la référence est 32,6, Aaronson 32,7 et 32,6, Kirchenbauer 32,2 et 32,1. L'écart entre méthodes se resserre quand le modèle grandit, ce que les auteurs attribuent à une distribution plus robuste aux petites perturbations.

Le tableau II donne la robustesse. Pour Aaronson avec h = 0, la TPR passe de 0,20 à 0,51 quand θ va de 0,8 à 1,1, et la TPR après attaque de 0,04 à 0,10. Pour h = 4, elle passe de 0,43 à 0,80, et de 0,01 à 0,18 après attaque. Pour Kirchenbauer avec h = 0, la TPR passe de 0,00 à 0,70 quand δ va de 1,0 à 4,0, avec une TPR attaquée de 0,00 à 0,39. Pour h = 4, elle va de 0,02 à 0,88, mais la TPR attaquée s'effondre à 0,14 à δ = 4,0. Kirchenbauer offre donc un contrôle plus fin du compromis force-qualité, tandis qu'Aaronson plafonne sous 0,8 même quand la similarité S-BERT est très dégradée.

Le tableau III donne l'identification. À FPR = 10⁻³, la précision est de 0,80, 0,72, 0,67 et 0,62 pour Aaronson quand le nombre d'utilisateurs passe de 10 à 10 000, et de 0,84, 0,77, 0,73 et 0,68 pour Kirchenbauer. À FPR = 10⁻⁶, elle tombe à 0,61, 0,56, 0,51 et 0,46 pour Aaronson, et 0,69, 0,64, 0,59 et 0,55 pour Kirchenbauer. Avec 10⁵ utilisateurs, on identifie la source d'un texte watermarké dans 50 % des cas à FPR = 10⁻⁶, sans aucune fausse accusation, parce que le seuil élevé exigé pour éviter les faux positifs rend l'erreur d'attribution très improbable.

## 5. Ce que le papier ne donne pas

Pas de test du multi-bit en conditions réelles : l'identification est évaluée sur des textes de 149 tokens en moyenne, non attaqués, avec un seul modèle. On ne sait pas ce que devient la précision à 10⁴ utilisateurs après un paraphrasage ou une troncature.

Pas de p-value exploitable pour le détecteur Neyman-Pearson, qui n'est donc pas déployable en l'état. Pas d'analyse multi-tokenizers, pas de langues autres que l'anglais pour l'évaluation aval, pas de familles de modèles autres que LLaMA et Guanaco. Pas de théorie sur le taux de faux positifs du multi-bit quand M grandit, alors que la correction 1 − (1 − p)^M est le point sensible.

Les attaques testées se limitent au remplacement aléatoire de tokens à 30 %. Le paraphrasage, la traduction et la réécriture adversariales ne sont pas traités, alors que ce sont celles qui comptent pour un déployeur.

## 6. Usage concret en hackathon 24 h

La brique la plus immédiatement réutilisable est le couple test binomial exact plus règle « ne scorer qu'une fois chaque couple fenêtre-token ». C'est une trentaine de lignes, et cela change la crédibilité d'un détecteur : sans cela, on obtient des p-values de 10⁻²¹ sur du texte naturel répétitif.

La deuxième brique est le protocole de validation du taux de faux positifs à grande échelle, 10 clés sur 100 000 textes. Il fournit un harnais d'évaluation montable en une heure, qui distingue immédiatement un détecteur correct d'un détecteur qui se contente de mesurer sa sensibilité.
