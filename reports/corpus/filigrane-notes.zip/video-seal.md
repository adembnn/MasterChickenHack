# Video Seal : watermarking vidéo ouvert et efficace

Pierre Fernandez, Hady Elsahar, I. Zeki Yalniz, Alexandre Mourachko, arXiv 2412.09492v1, Meta FAIR. Code dans le dépôt `facebookresearch/videoseal`.

## 1. Problème et revendications

Le papier part d'un constat simple. Le watermarking d'images est mature, mais la vidéo reste mal couverte : peu de méthodes publiées, encore moins de modèles ouverts, et des contraintes de coût qui changent la donne. Une vidéo, c'est vingt-quatre à soixante images par seconde, en 1080p ou 4K, et un watermarking image par image coûte cher. Les auteurs revendiquent trois choses : un modèle ouvert et reproductible pour la vidéo, une qualité visuelle supérieure aux bases image appliquées telles quelles, et une robustesse qui tienne face aux codecs vidéo réels (H.264, H.265) combinés à des transformations géométriques et photométriques.

La thèse défendue est que la vidéo n'est pas juste « de l'image en série ». Les codecs introduisent des artefacts temporels et spatiaux que les modèles image n'ont jamais vus à l'entraînement ; à l'inverse, la redondance temporelle permet d'amortir le coût d'insertion et d'agréger plusieurs observations à l'extraction. Video Seal exploite ces deux propriétés au lieu de les subir.

Le message est multi-bit : 96 bits, ce qui autorise un identifiant par vidéo, par utilisateur ou par génération, plutôt qu'un simple bit de présence. C'est un choix important pour le hackathon, car il transforme un détecteur binaire en système d'attribution.

## 2. Méthode, équations, hyperparamètres

L'embedder est un U-Net avec blocs ResNet, entraîné en 256×256. Il prend l'image redimensionnée et le message, et sort une distorsion `w`, pas une image. L'image marquée s'écrit (éq. 1) :

`x_w = x + α_w · resize(w)`, avec `w = Embedder(resize(x), m)`.

Le facteur `α_w` règle le compromis invisibilité / robustesse au moment de l'inférence, sans réentraîner. La valeur nominale vaut 2.0.

L'extracteur est un ViT-Small de 22 M de paramètres, patch 16, dimension 384, suivi d'un bloc résiduel, d'un pooling moyen et d'une couche linéaire vers 96 bits, avec sigmoïde à l'inférence. Il travaille aussi en 256×256.

Le point technique central est la propagation temporelle (éq. 2) : la vidéo est découpée en segments de `k` images, seule la première est passée dans l'embedder, et sa distorsion est recopiée sur les `k-1` suivantes. Avec `k=4`, on divise le coût d'insertion par quatre environ. L'opération reste différentiable, donc l'entraînement voit cette approximation. Les auteurs justifient `k=4` par deux risques : le bruit d'extraction sur les images non marquées, et les artefacts d'ombre quand le contenu bouge et que la distorsion colle aux objets.

À l'extraction (éq. 3), chaque image produit un message souple, et la moyenne des messages souples sur `T` images est seuillée bit par bit. C'est volontairement simple : les auteurs notent que des agrégations plus fines sont étudiées en 5.3, mais la moyenne suffit et coûte peu.

L'objectif d'entraînement (éq. 4) combine trois termes : `λ_disc·L_disc + λ_i·L_i + λ_w·L_w`. `L_w` est une entropie croisée binaire moyenne sur les bits (éq. 5), `L_i` une MSE pixel (éq. 6), `L_disc` la sortie brute d'un discriminateur de qualité en patchs. Le discriminateur est mis à jour séparément avec une perte hinge duale. Les poids sont rééquilibrés dynamiquement par un « balancer » (éq. 7) qui normalise chaque perte par la norme de son gradient sur la dernière couche de l'embedder, avec `R=1` comme dans EnCodec. Les valeurs annoncées sont `λ_w=1.0`, `λ_i=0.5`, `λ_disc=0.1`.

Les transformations non différentiables (JPEG, H.264) passent par un estimateur straight-through (éq. 8) : `x_aug = x_w + nograd(T(x_w) − x_w)`. C'est un choix assumé, plus simple qu'un JPEG différentiable ou un réseau qui imite le codec.

L'entraînement est multi-étapes : 800 époques sur images seulement (SA-1B, 500 k images tirées au hasard, 1500 pas par époque, batch 16 par GPU, 16 GPU, AdamW, montée linéaire de 1e-6 à 1e-5 puis cosinus vers 1e-7), puis 300 époques en mélange images et vidéos (SA-V, 51 k vidéos, clips de 32 images, 200 pas par époque, un clip par GPU, learning rate de 1e-7 à 1e-6 puis cosinus vers 1e-8). À l'époque 250 de cette seconde phase, l'embedder est gelé et seul l'extracteur continue. Ce gel est présenté comme le moyen de sortir du compromis invisibilité / robustesse : on améliore le décodage sans dégrader l'image.

Les plages d'augmentation sont données dans le tableau 3 et sont larges : luminosité, contraste, saturation, teinte entre 0.5 et 2.0 (teinte entre -0.5 et 0.5), flou gaussien de noyau impair entre 3 et 17, filtre médian entre 3 et 7, JPEG qualité 40 à 80, H.264 CRF 9 à 27, flip horizontal, crop de ratio 0.7 à 1.0, resize 0.7 à 1.5, rotation de -10 à 10 degrés, perspective d'échelle 0.1 à 0.5. Le papier insiste : beaucoup de méthodes image et vidéo récentes n'incluent aucune transformation géométrique, ce qui explique leur effondrement en conditions réelles.

## 3. Protocole et métriques

Qualité : PSNR, SSIM, LPIPS, et VMAF pour la vidéo, ce dernier étant le seul à modéliser la perception temporelle. Robustesse : exactitude binaire (éq. 9), mais surtout la log p-value (éq. 10), qui donne la probabilité d'obtenir par hasard une exactitude au moins aussi bonne sous des bits Bernoulli(0.5). Ce second indicateur est indispensable pour comparer des méthodes qui n'embarquent pas le même nombre de bits : 100 % sur 32 bits et 99 % sur 96 bits ne disent pas la même chose. La p-value se lit directement comme un taux de faux positifs : log10(p) < -6 correspond à un FPR inférieur à 10^-6.

Données : SA-1B pour les images (1 k images à résolution native, environ 1500×2250, plus 1 k images COCO), SA-V pour la vidéo (1.3 s, 32 images, à l'entraînement ; 5 s à l'évaluation, résolution d'origine). Les transformations sont regroupées en cinq familles : aucune, géométrique, valuémétrique, compression, combinée. Les baselines sont HiDDeN (48 bits, réentraîné), MBRS (256 bits), CIN (30 bits, 128×128), TrustMark (100 bits), WAM (32 bits plus un bit de détection non utilisé). Toutes sont étendues à la vidéo avec la même stratégie de propagation `k=4`, ce qui rend la comparaison honnête sur le coût.

Latence : GFlops et secondes par seconde de vidéo, sur CPU (2 Xeon 6230, 480 Go) et GPU V100, après compilation TorchScript, sur 20 vidéos SA-V.

## 4. Résultats chiffrés

Robustesse, tableau 4. Sur SA-1B, Video Seal obtient 0.91 d'exactitude en transformation combinée avec log10(p) = -18.4, contre 0.86 / -5.9 pour WAM, 0.53 / -0.8 pour TrustMark, 0.50 / -0.4 pour MBRS et CIN. En géométrique, 0.83 / -16.4 contre 0.81 / -5.5 pour WAM et 0.65 / -8.5 pour TrustMark. En valuémétrique, 0.93 / -23.4, derrière TrustMark (0.98 / -27.4) et MBRS (0.95 / -59.8, mais 256 bits). En compression, 0.99 / -27.1.

Sur SA-V, la vidéo est plus dure : combiné 0.73 / -8.1, géométrique 0.85 / -17.0, valuémétrique 0.90 / -19.9, compression 0.85 / -15.7, identité 0.99 / -26.8. Le passage de l'image à la vidéo coûte donc environ 18 points d'exactitude en combiné, ce que le papier attribue aux codecs et au mouvement. La phrase clé de la section 4.1 : sous H.264 CRF 30 + luminosité 0.5 + crop 50 % de l'aire, Video Seal garde log10(p) = -6.1 en moyenne, donc la majorité des vidéos resterait détectée à FPR < 10^-6.

Invisibilité, tableau 5. Image : PSNR 47.39 dB, SSIM 0.999, LPIPS 0.009, meilleurs PSNR et SSIM du tableau. Vidéo : PSNR 48.02 dB, SSIM 0.998, LPIPS 0.013 (TrustMark fait 0.003), VMAF 93.77 (MBRS 94.10). Les auteurs tempèrent eux-mêmes : à PSNR très élevé, les blobs de Video Seal peuvent rester gênants à l'œil selon la vidéo support, et aucune métrique ne capte vraiment la gêne temporelle.

Latence, tableau 6. Extraction : 3.1 GFlops, 0.11 s par seconde de vidéo sur GPU, 0.69 s sur CPU, soit le plus rapide du panel (WAM 68.7 GFlops, 0.47 s GPU). Insertion : 42.0 GFlops, 0.42 s GPU, 1.14 s CPU. Le coût d'insertion est donc du même ordre que les baselines, mais l'extraction est environ quatre fois moins chère que WAM en GFlops.

Le compromis est étudié en 4.4 (figure 6) : en traçant log10(p) contre VMAF, MBRS et TrustMark dominent à faible VMAF grâce à leur nombre de bits, mais Video Seal reprend l'avantage dès que les transformations combinent géométrie et codec, en particulier au-delà de 50 dB de PSNR ou 94 de VMAF.

## 5. Ce qui manque

Le papier ne donne pas de courbe FPR/TPR complète par transformation et par force, seulement des moyennes par famille (les détails sont renvoyés en annexe B.2). Impossible, à la lecture du corps, de savoir à partir de quel angle de rotation ou quel CRF la détection casse.

Le coût d'entraînement n'est pas chiffré en GPU-heures totales, seulement en époques et en nombre de GPU. La taille du modèle n'est donnée que pour l'extracteur (22 M) ; celle de l'embedder est absente.

La sécurité n'est pas traitée : aucune expérience de forgery, de copy attack ni de retrait adversarial. Un modèle ouvert de 96 bits invite pourtant exactement ce type d'attaque, et le papier suivant sur le forging l'utilise d'ailleurs comme cible.

Le cas audio n'existe pas, et le cas « vidéo générée » (Sora, Veo) n'est pas séparé du cas « vidéo caméra ». Or les artefacts de génération et les artefacts de codec ne se ressemblent pas.

Enfin, la propagation temporelle est évaluée à `k=4` seulement. Aucun balayage de `k` n'est présenté dans le corps, alors que c'est le paramètre qui décide du coût réel en production.

## 6. Usage concret en hackathon 24 h

Utiliser les poids ouverts et l'extracteur à 3.1 GFlops comme détecteur de référence : sur un lot de vidéos transformées, produire une table (exactitude, log10 p) par famille de transformation, c'est une baseline en deux heures et un point de comparaison solide pour toute attaque.

Pour l'épreuve « forcer un détecteur par perturbation minimale », attaquer l'agrégation temporelle plutôt que les pixels : si l'extraction moyenne les messages sur les images, perturber un sous-ensemble d'images avec un bruit ciblé et mesurer la chute de log10(p) coûte moins cher qu'une attaque dense.

Pour l'épreuve d'attribution, exploiter les 96 bits : encoder un identifiant par source, puis vérifier combien de bits survivent après H.264 et crop. Le seuil praticable se lit directement dans la p-value, pas dans l'exactitude brute.
