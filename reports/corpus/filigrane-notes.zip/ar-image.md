# Watermarking de la génération d'images autorégressive

Nikola Jovanović, Ismail Labiad, Tomáš Souček, Martin Vechev, Pierre Fernandez, arXiv 2506.16349, « Watermarking Autoregressive Image Generation ». Le papier traite de WMAR et de la couche de synchronisation.

## 1. Problème et revendications

Watermarker un modèle autorégressif d'images semble facile : il produit des tokens discrets, donc on peut réutiliser les schémas de watermarking de LLM, où l'on colorie le vocabulaire en vert et rouge et où l'on biaise l'échantillonnage vers le vert. Le papier montre que ça ne marche pas directement, et identifie la cause précise : le manque de consistance inverse du cycle, ou RCC.

L'argument est le suivant. Le watermarking LLM est détecté en retokenisant le texte produit et en vérifiant la proportion de tokens verts, ce qui suppose que retokeniser donne les mêmes tokens que la génération. Pour un texte, c'est vrai en grande partie. Pour une image, non : on génère des tokens, on les décode en pixels, et si on veut vérifier le watermark sur le fichier reçu, il faut réencoder l'image. Or le tokenizer image n'est pas cycliquement consistant. Le papier mesure un token match de 0.66 sans aucune transformation sur Taming, et bien moins après transformations.

Conséquence : le watermark est là, dans les tokens, mais il n'est plus dans l'image qu'on peut retokeniser. Le détecteur voit du bruit. La revendication centrale est donc double : (a) diagnostiquer et quantifier ce problème sur trois familles de modèles autorégressifs, (b) le corriger par un fine-tuning du tokenizer qui restaure la RCC, puis par une couche de synchronisation géométrique pour les transformations que la RCC ne peut pas couvrir.

## 2. Méthode, équations, hyperparamètres

Le schéma de base est celui de Kirchenbauer et al. : à chaque pas, le contexte (les `h` tokens précédents) sert de graine à un générateur qui partitionne le vocabulaire en vert (proportion `γ`) et rouge. Le logit des tokens verts est augmenté de `δ` avant échantillonnage.

Le papier donne une version unifiée (éq. 2) : on tokenise chaque échantillon, on calcule son score `S`, on somme scores, longueurs `T` et `h`, et on déduplique les couples (contexte, token) pour préserver la validité statistique. La séquence est déclarée marquée si la p-value passe sous le FPR visé.

Trois régimes de contexte existent : `h=1`, `h>1` (ou une variante spatiale), et `h=0` (partition fixe). Le compromis est explicite : grand `h` facilite le retrait, petit `h` facilite le forgery. Pour l'image, `h=0` reste viable car le tokenizer est caché et complexe, ce qui rend l'ingénierie inverse bien plus dure que sur du texte.

La correction RCC (section 3.1) consiste à fine-tuner le tokenizer, c'est-à-dire le décodeur puis le réencodeur, pour que `f(f(x)) ≈ f(x)` au sens de la retokenisation d'image. L'objectif combine la perte de watermark et une perte de reconstruction, avec un poids `λ=1` partout, et des augmentations progressives. Les détails sont dans l'annexe E.1 et sont réellement donnés : 10 époques, 50 000 images ImageNet tokenisées, Adam, learning rate 1e-4 multiplié par 0.9 à chaque époque (StepLR), batch total 64 (4 par GPU pour Taming, 8 pour Chameleon et RAR-XL), 16 V100 pour Taming (2 h), 8 H200 pour Chameleon (2.5 h) et RAR-XL (0.5 h). Le JPEG n'étant pas différentiable, il passe par un straight-through : `x' = x_aug + nograd(x_aug,JPEG − x_aug)`.

Les trois jeux d'augmentation sont donnés en clair. A1 : JPEG 90/80/70, flou de noyau 1 et 3, bruit gaussien de 0.005 à 0.02, luminosité 1.0 à 1.2, rotation ±1 degré, crop 80 et 90 %. A2 : JPEG 80/60/40, flou 3 et 5, bruit 0.02 à 0.06, luminosité 1.2 à 1.4, rotation ±1 à ±3, crop 50 à 90 %. A3 : JPEG 40/30/20, flou 5 à 9, bruit 0.06 à 0.1, luminosité 1.4 à 2.0, mêmes géométries que A2. Le schedule est de 1 époque sans augmentation, 1 avec A1, 4 avec A2, 4 avec A3.

La synchronisation (section 3.2) est la partie la plus réutilisable. On suppose un watermark localisé `L` capable d'insérer un message différent par pixel et de renvoyer, pour chaque pixel, la probabilité d'être marqué et le message le plus probable. On insère quatre messages fixes de 32 bits : `0^32`, `0^16 1^16`, `1^16 0^16`, `1^32`, un par quadrant, en laissant une bande horizontale et verticale de largeur `μ` au milieu. Valeurs : `μ=18` pour Taming et RAR-XL, `μ=36` pour Chameleon (résolution double).

À la récupération : pour chaque pixel, on prend le message le plus proche en distance de Hamming, à condition que la distance soit inférieure à 6 bits et que la probabilité d'être marqué dépasse 0.5. On continue seulement si les quatre messages sont présents et si la zone marquée couvre au moins 70 % de l'image, sinon l'estimation est jugée trop peu fiable. On balaie ensuite les rotations de -20 à 20 degrés, on fait tourner la grille de messages en sens inverse, et on cherche la ligne `i` et la colonne `j` qui séparent le mieux les paires (m1,m3) et (m2,m4) d'une part, (m1,m2) et (m3,m4) d'autre part, en comptant les pixels mal placés. On teste aussi la grille retournée horizontalement, et on garde l'hypothèse de coût minimal, agrégée proportionnellement au nombre de pixels de chaque message.

## 3. Protocole et métriques

Trois modèles : Taming (VQGAN ImageNet f=16, 16384 codes, 256×256), Chameleon 7B (8192 codes, 512×512, texte et image entrelacés), RAR-XL (955 M, 1024 codes, 256×256). Mille générations par modèle et par condition : 100 images pour 10 classes ImageNet pour Taming et RAR-XL, 1 000 prompts COCO pour Chameleon.

Métriques : token match (éq. 3) entre tokens générés et tokens obtenus après retokenisation, TPR à FPR fixé (1 % pour la robustesse, courbes complètes pour la puissance), FID sur 50 000 générations, PSNR entre décodeur original et décodeur fine-tuné. Les transformations sont énumérées avec leurs paramètres en annexe E.2 : flou de 0 à 19, bruit de 0 à 0.2, JPEG de 100 à 5, luminosité de 1 à 3, rotation de -20 à 20, flip, crop de 1.0 à 0.5, plus DiffPure de 0.01 à 0.3 et des compressions neuronales. Quatre-vingt-dix variantes par image, 90 000 images par évaluation.

## 4. Résultats chiffrés

RCC, tableau 1 : le token match sans transformation est de 0.66 pour Taming, et il s'effondre sous transformations. Le fine-tuning le remonte au-dessus de 0.8 dans la figure 5, pour toutes les variantes, et la puissance de détection suit : la variante Base atteint déjà une TPR proche de 1 à FPR 10^-2, et les variantes fine-tunées gagnent nettement aux FPR plus bas.

Robustesse, tableau 2, TPR à FPR 1 %. Taming : Base 0.99 / 0.26 / 0.01 / 0.43 / 0.48 (aucune, valuémétrique, géométrique, purification, compression neuronale) ; FT 1.00 / 0.45 / 0.01 / 0.70 / 0.71 ; FT+Augs 1.00 / 0.92 / 0.01 / 0.70 / 0.79 ; FT+Augs+Sync 0.98 / 0.83 / 0.82 / 0.69 / 0.80. Chameleon : Base 0.98 / 0.50 / 0.02 / 0.80 / 0.82, FT+Augs 0.99 / 0.89 / 0.02 / 0.82 / 0.88, avec Sync 0.97 / 0.76 / 0.64 / 0.81 / 0.86. RAR-XL : Base 0.98 / 0.22 / 0.01 / 0.29 / 0.27, FT+Augs 1.00 / 0.98 / 0.03 / 0.79 / 0.95, avec Sync 1.00 / 0.89 / 0.82 / 0.78 / 0.94.

Le point à retenir est 0.01 à 0.03 en géométrique pour toutes les variantes sans synchronisation, et le passage à 0.82 (Taming), 0.64 (Chameleon), 0.82 (RAR-XL) avec. Inversement, la synchronisation coûte en valuémétrique : 0.92 vers 0.83 pour Taming, 0.89 vers 0.76 pour Chameleon. L'explication donnée est mécanique et crédible : une transformation valuémétrique modérée brouille le motif de synchronisation, on estime alors une transformation géométrique inexistante, on la défait, et on corrompt la majorité des tokens.

Comparaison aux méthodes post-hoc (tableau 2, bas) : CIN et MBRS s'effondrent à 0.00 et 0.02 en géométrique, tandis que WAM tient 0.98 et TrustMark 0.75. WAM tombe à 0.06 en purification adversariale et TrustMark à 0.40, le watermark de génération synchronisé tient 0.69 et 0.80.

Qualité : FID de référence 16.7 pour Taming non marqué ; Base, FT et FT+Augs restent sous 16.7, FT+Augs+Sync monte à 17.3. Chameleon (19.7) et RAR-XL (11.5) restent sous leur référence pour tous les variants. PSNR entre décodeur original et fine-tuné (annexe F.4) : 37.6 dB pour Taming, 39.5 pour Chameleon, 29.0 pour RAR-XL, synchronisation comprise, donc le décodage final ne dérive pas beaucoup.

Ablations, tableau 6, TPR à FPR 1 % sur Taming. FT+Augs sert de base : 1.00 / 0.92 / 0.01 / 0.70 / 0.79, FID 16.33. `h=2` : 0.82 en valuémétrique, 0.41 en purification, FID 15.70. `h=3` : 0.73 et 0.24, FID 15.87. `h=3` spatial : 0.69 et 0.22. `δ=1` : 0.69 et 0.29, FID 16.22. `δ=4` : 0.97 et 0.86, mais FID 18.76. `γ=0.5` : 0.86 et 0.51, FID 15.71. Conclusion : `δ=2` et `γ=0.25` sont le bon compromis, et `δ=4` améliore la robustesse en dégradant visiblement la qualité.

Audio, étude préliminaire sur Moshi : le token match moyen est de 0.25 pour Mimi et 0.35 pour Moshi en identité (tableau 4), et tombe à 0.01 sous speed 1.25× ou crop 90 % pour Mimi. La synchronisation audio par motif périodique échoue dès un speedup de 1.05× (figure 9c).

## 5. Ce qui manque

Aucune analyse de sécurité : pas de forgery, pas de copy attack, pas d'estimation de la difficulté à reverse-engineer la partition pour `h=0`. Le papier reconnaît que `h=0` est plus facile à forger, mais ne quantifie pas.

La synchronisation est bornée à ±20 degrés, au flip et aux crops qui gardent les quatre quadrants visibles. Une rotation de 45 degrés ou un crop qui coupe un quadrant la met en échec, sans que le taux d'échec soit donné.

Le surcoût en temps de la synchronisation n'est pas chiffré par image, et l'audio reste une étude préliminaire dont la synchronisation ne fonctionne pas.

Enfin, la comparaison aux méthodes post-hoc applique le watermark après génération, ce qui n'est pas le même modèle de menace : un tel watermark peut être retiré par régénération, et le tableau ne le mesure pas.

## 6. Usage concret en hackathon 24 h

Pour l'attribution, la RCC est le concept à réutiliser : sur un fichier image sans accès aux tokens, mesurer le token match avant de conclure à une absence de watermark, sinon on rate des détections.

La couche de synchronisation à quatre messages se réimplémente en quelques heures avec n'importe quel watermark localisé par pixel et donne un gain massif sur rotation et perspective sans réentraîner le détecteur : meilleur rapport gain / effort du papier.

Pour une attaque, viser le conflit valuémétrique / géométrique : une légère variation de luminosité combinée à une petite rotation trompe l'estimation de géométrie et détruit le watermark.
