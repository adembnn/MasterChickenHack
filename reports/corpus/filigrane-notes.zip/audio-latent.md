# Audio latent watermarking (arXiv 2409.02915)

San Roman, Fernandez, Deleforge, Adi, Serizel, « Latent Watermarking of Audio Generative Models », v1 du 4 septembre 2024, texte integral lu (version HTML arXiv, 31 707 caracteres).

## 1. Probleme et revendications

Les modeles generatifs audio s'ouvrent (poids publics, code public) et le watermarking applique apres coup devient contournable : il suffit de changer de vocodeur, de redecoder les tokens avec un autre modele, ou de commenter la ligne de code qui applique le filigrane. Les auteurs attaquent donc le probleme un cran plus tot, au niveau des representations latentes : si les tokens EnCodec sont eux-memes porteurs du signal, tout decodeur produira un audio detectable, et un modele derive par fine-tuning restera tracable.

Trois revendications : (i) une methode de watermarking des modeles audio au niveau latent, obtenue en filigranant les donnees d'entrainement de facon robuste a la tokenisation ; (ii) une detection a haute confiance sans degradation perceptible de la qualite musicale ; (iii) une robustesse aux changements au niveau du modele, a savoir le changement d'algorithme de decodage et le fine-tuning du LM audio.

Le cadrage est explicitement celui de la distribution ouverte : le watermarking post-hoc reste preferable quand il est possible (l'article le dit lui-meme dans la conclusion de la section IV-C), la methode latente vise les cas ou il ne l'est pas.

## 2. Methode, equations, hyperparametres

La brique de base est AudioSeal, mais modifiee. Un generateur G prend un signal s et produit un residu additif delta_w rendu imperceptible par une perte perceptuelle ; le detecteur D sort un logit par echantillon temporel et est entraine avec une perte de localisation L_loc sur une cible binaire y' indiquant les intervalles filigranes. Deux changements : l'encodeur de message est supprime (le systeme devient zero-bit, detection oui/non, sans identifiant), et l'augmentation EnCodec est sur-echantillonnee de sorte que 50 % des batchs passent par le codec avant detection. C'est le point cle : on entraine G et D a survivre a la compression neuronale utilisee plus tard pour tokeniser.

Le pipeline complet : (1) filigranage des audios de la base a la volee au chargement (environ 10 ms pour 10 s d'audio) ; (2) tokenisation EnCodec, RVQ a K = 4 codebooks de taille 2048, 32 kHz, frequence de trame 50 Hz, soit 2,2 kbit/s ; (3) entrainement du LM en prediction du token suivant, avec le schema de delai de MusicGen (le k-ieme residuel est decale de k, ce qui permet un echantillonnage grossier vers fin en parallele), cross-entropy calculee par codebook.

Hyperparametres donnes : modele de watermarking entraine sur un dataset musical interne de 1,5k morceaux a 32 kHz, extraits d'une seconde, 400k pas, batch 64, hyperparametres d'architecture et d'optimiseur identiques a AudioSeal. MusicGen : 20k heures de musique sous licence, tailles small (300M) et medium (1,5B), 200 epochs, batch 128, 64 GPU pour medium et 32 pour small. Inference : top-k a 250, temperature 1,0. Aucune formule nouvelle n'est introduite ; l'article est un assemblage de briques existantes, ce qui est justement son argument (pas de modification d'architecture ni de procedure d'entrainement).

## 3. Protocole et metriques

Detection : 10k positifs de 15 s generes par le modele filigrane, 10k negatifs du set de test compresses par le codec. Le detecteur donne un score par pas de temps, moyenne sur l'audio, seuil tau. Metriques : AUC, accuracy au meilleur seuil, TPR et FPR a ce seuil.

Localisation : on genere 15 s puis on remplace des portions par de l'audio non filigrane (50 % du signal en moyenne), seuil fixe a 0,5, metriques IoU et sample-level accuracy (SL-Acc).

Qualite : evaluation subjective dans le protocole de MusicGen, OVL (qualite du sample) et REL (pertinence au prompt), 40 prompts du test set MusicCaps, 15 s, 20 auditeurs, echelle 1 a 100, intervalle de confiance a 95 %.

Robustesse : huit editions appliquees avant detection (bruit blanc, passe-bas, passe-haut, reechantillonnage, AAC, bruit rose, echo), comparees au watermarking post-hoc AudioSeal.

Attaques au niveau modele : remplacement du decodeur par HiFi-GAN (version discrete entrainee sur paires tokens/onde) et par Multi-Band Diffusion ; fine-tuning du small sur un dataset interne non filigrane de taille similaire, 20 epochs (10 % des pas de pre-entrainement), grille de learning rates de 2e-6 a 1e-4 ; reference « scratch », modele entraine de zero sur ce dataset.

## 4. Resultats chiffres

Detection (Table II) : small, AUC 0,999, accuracy 0,993, TPR 0,986 a FPR 2.10^-4, IoU 0,81, SL-Acc 0,91. Medium, AUC 0,999, accuracy 0,994, TPR 0,988 a FPR 3.10^-4, IoU 0,91, SL-Acc 0,96. Le post-hoc AudioSeal sur les memes sorties atteint 1,0 partout, ce qui situe le cout de l'approche in-model : environ un point de TPR et une localisation nettement moins bonne.

Qualite (Table I) : small 84,13 OVL contre 83,67 pour l'original (le modele filigrane est legerement mieux note, dans l'intervalle de confiance) ; medium 84,91 contre 85,92, donc legerement moins bon mais dans l'IC. REL : 82,46 contre 82,42 (small), 82,64 contre 83,71 (medium). Conclusion des auteurs : difference negligeable.

Robustesse aux editions (Table III, small) : en in-model, AUC de 0,88 (AAC) a 0,999 (reechantillonnage), avec 0,941 sur bruit blanc et passe-bas ; le post-hoc va de 0,931 (passe-haut) a 0,999. Le point faible est donc la compression AAC, ou l'in-model perd environ 12 points d'accuracy par rapport au post-hoc (0,81 contre 0,98). Les auteurs assument : le post-hoc reste meilleur quand il est applicable.

Changement de decodeur (Table IV) : HiFi-GAN 0,999 AUC, accuracy 0,990, TPR 0,980 a FPR 4.10^-4 ; Multi-Band Diffusion 0,991, accuracy 0,954, TPR 0,951 a FPR 0,043. Le decodeur par diffusion coute environ 0,01 d'AUC, ce qui est le resultat le plus interessant du papier : le signal vit bien dans les tokens, pas dans l'onde.

Fine-tuning (Table V) : sans fine-tuning, accuracy 0,993, TPR 0,983 a FPR 10^-3, FAD 2,067. A LR 2e-6, accuracy 0,964, TPR 0,765, FAD 2,908. A 5e-6, 0,928 et 0,456, FAD 3,149. A 2e-5, 0,833 et 0,079, FAD 3,344. A 5e-5, 0,721 et 0,019, FAD 3,740. Modele entraine de zero sur le dataset de fine-tuning : FAD 3,839. Le message des auteurs : on peut effectivement laver le filigrane, mais a un cout de distribution tel qu'il n'y a plus d'interet a partir du modele protege.

## 5. Ce qui manque

Le systeme est zero-bit : aucune identification de version ou de client, alors que le cas d'usage annonce (tracer une redistribution non autorisee) demande un identifiant. AudioSeal originel porte 16 bits, cette variante les jette.

Un seul modele, un seul codec : MusicGen et EnCodec, a 32 kHz. Rien sur DAC, SoundStream, ou sur les modeles de diffusion latente audio, alors que l'introduction les cite. Rien non plus sur la parole ou les effets sonores, uniquement la musique.

Le cout d'entrainement est dissuasif : 200 epochs sur 20k heures, 32 a 64 GPU. Les auteurs le reconnaissent en conclusion (il faut entrainer de zero, pas de versioning possible d'un modele deja entraine).

L'evaluation d'attaque est etroite : fine-tuning supervise avec des LR extremes, pas d'attaque adversarial sur le detecteur, pas d'estimation bayesienne du detecteur, pas de distillation, pas de « model stealing ». Le pendant AudioSeal de ce type d'attaque (white-box, semi black-box, black-box) n'est pas repris.

Enfin, aucun test statistique du seuil : le papier raisonne en TPR a FPR fixe empiriquement sur 10k negatifs, sans borne de p-value, ce qui est insuffisant des qu'on veut accuser quelqu'un (le chapitre 8 de la these de Fernandez corrige precisement cela).

## 6. Usage concret en hackathon 24 h

La brique reutilisable immediatement est le detecteur AudioSeal, pas la partie entrainement de MusicGen. Idee de projet en 24 h : banc d'attaque « modele ouvert » avec trois axes mesures sur un petit modele musical ou l'on dispose deja de sorties, remplacement de vocodeur (HiFi-GAN contre Multi-Band Diffusion), round-trip EnCodec a debit variable, et fine-tuning court sur 500 clips non filigranes. On trace TPR a FPR 10^-3 avant et apres, plus le FAD. C'est exactement le protocole des tableaux III a V, realisable avec un seul GPU.

Deuxieme usage : plutot que d'entrainer, utiliser le resultat du tableau V comme argument quantitatif dans un pitch : laver le filigrane coute 1,25 point de FAD, soit un modele qui n'est plus vraiment le meme. Cela donne une reponse chiffree a la question « pourquoi le watermarking de modele et pas seulement du contenu ».

Troisieme usage, en detection : le score par pas de temps du detecteur permet de localiser les segments generes dans un montage (musique reelle plus generation). Un demo de 3 minutes la-dessus est plus convaincant qu'une courbe ROC, et le papier fournit deja les metriques (IoU, SL-Acc) pour le cadrer.
