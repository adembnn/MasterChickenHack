# TextSeal2 : mélange par copule et courses sans mémoire pour un watermarking sans distorsion

Papier arXiv 2610.40613, Meta Superintelligence Labs (Tom Sander, Pierre Fernandez, Itai Gat et al.). Code annoncé : github.com/facebookresearch/textseal.

## 1. Problème posé et revendications

TextSeal, le prédécesseur, restaure la diversité du Gumbel-max en routant chaque token vers l'une de deux clés par un tirage à pile ou face, puis en moyennant les scores des deux clés au détecteur. Le papier en fait le diagnostic central : seule la clé qui a produit le token porte du signal, donc la moyenne divise par deux l'excès de score attendu et par deux la variance, ce qui ne réduit l'écart-type que d'un facteur racine de 2. Le rapport signal sur bruit perd un facteur racine de 2 par rapport à un schéma à clé unique.

TextSeal2 revendique trois apports : un mélange par copule gaussienne qui fusionne plusieurs clés en une clé virtuelle unique sans perte de détection, une course résiduelle pour le décodage spéculatif qui préserve exactement la loi du modèle cible et le taux d'acceptation du block verification, et un paramètre de force rho calibré en termes d'entropie retirée. Les exigences affichées sont la préservation de la distribution, la diversité sous clé fixe, l'absence de latence mesurable et la préservation de l'acceptation spéculative.

## 2. Méthode

Gumbel-max comme course. Pour chaque candidat v, R_v = PRF(v, w, K) et E_v = -ln R_v est une exponentielle de taux 1. Le token émis est

x_t = argmax_v R_v^(1/p_v) = argmin_v E_v / p_v.

C'est une course exponentielle : le candidat v parcourt une piste de longueur E_v à vitesse p_v, et le premier arrivé est émis. Le détecteur note s_i = -ln(1 - R_{x_i}) ; sous H0 les scores sont Exp(1) et leur somme suit Gamma(n,1).

Mélange par copule. Pour chaque clé j, on pose G_v(j) = Phi^{-1}(R_v(j)), qui est normale centrée réduite. TextSeal2 ne tire pas une clé au hasard : il fusionne les valeurs en une clé virtuelle

G*_v = (G_v(1) + G_v(2)) / racine(2),

puis applique la copule d'AutoMark :

R~_v = Phi( rho G*_v + racine(1 - rho²) eta_v ), avec eta_v i.i.d. N(0,1).

Comme les deux clés sont indépendantes, G* est standard normale et indépendante entre candidats, donc R~ est uniforme et la course reste sans distorsion pour tout rho. rho = 0 redonne l'échantillonnage non filigrané, rho = 1 le Gumbel-max déterministe. La détection utilise le score de la clé virtuelle,

s*_i = -ln Phi(-G*_{x_i}),

qui est Exp(1) sous H0. Le schéma à deux clés a donc exactement la diversité et la puissance de la copule à clé unique d'AutoMark au même rho. L'extension à M clés est immédiate : G* = M^(-1/2) somme des G(k). Chaque clé garde néanmoins un rôle : k_pub = k(1) peut être publiée pour un test public plus faible, dont la corrélation avec l'entrée de course n'est que rho / racine(2), tandis que k(2) reste privée.

Course résiduelle. Un tour comporte N brouillons et une position bonus. Le drafter court à ses propres vitesses : d_i = argmin_v E_{i,v} / q_{i,v} et tau_i = E_{i,d_i} / q_{i,d_i}. Quand d_i gagne, la piste v a parcouru tau_i q_{i,v} et son reste est E_{i,v} - tau_i q_{i,v}. Par absence de mémoire des exponentielles (lemme 1), ces restes sont à nouveau i.i.d. Exp(1). TextSeal2 décide alors la position d'arrêt I et le token émis y par une course sur les restes :

(I, y) = argmin_{(i,v) : pi_{i,v} > 0} (E_{i,v} - tau_i q_{i,v}) / pi_{i,v},

où pi_{i,v} est la loi conjointe de la position d'arrêt et du token sous block verification. La proposition 1 garantit que, conditionnellement aux brouillons, (I, y) suit pi : le nombre de tokens par tour et le taux d'acceptation sont ceux du block verification, et le texte suit la loi de la cible. Les brouillons conservent le signal de leur course et le dernier token celui de la course relais ; le détecteur additionne les scores sans repérer les fins de tours. La proposition 2 montre que la course résiduelle atteint la borne d'acceptation pour N = 1.

Contrôle de l'entropie retirée. Pour un token d'entropie positive, l'entropie retirée est strictement croissante en rho (théorème 1). En pratique un rho constant suffit : environ 0.64, 0.81 et 0.93 retirent environ 30%, 50% et 70% de l'entropie sur une large gamme de distributions (annexe C). La proposition 3 borne l'information de détection par token, mesurée en divergence KL, par l'entropie retirée ; la copule atteint en moyenne 97% du rapport signal sur bruit optimal dans la limite de watermark faible, sur 5 169 distributions réelles de Qwen3.5-9B. Une optimisation par token comme textGrain ne peut donc gagner que quelques pourcents.

Détection et localisation. Le test privé somme les scores des n couples (fenêtre, token) distincts, chacun à sa première occurrence : S ~ Gamma(n,1). Le test public fait de même avec s(1). Deux raffinements optionnels viennent de TextSeal : la pondération par entropie w_i = 0.1 + 0.9 (H_i - H_min)/(H_max - H_min), testée contre une Gamma de moments appariés, et la localisation par fenêtres dyadiques avec correction de Bonferroni.

## 3. Protocole expérimental

Trois modèles : Llama-3.1-8B-Instruct, Qwen3.5-9B, Qwen3.5-27B. Génération sur ELI5, température 1, top-p 0.95, jusqu'à 200 nouveaux tokens, fenêtre k = 3. Décodage spéculatif : Qwen3.5-0.8B propose N = 8 tokens par tour pour Qwen3.5-9B, tous les schémas vérifient par block verification.

Métrique principale : fraction de réponses filigranées déclarées filigranées à un FPR nominal de 10^-3. Aucune loi nulle fermée n'étant exacte en pratique, chaque détecteur utilise le quantile empirique 10^-3 de ses p-values sur 10 000 réponses non filigranées notées sous 10 clés, soit 10^5 p-values nulles. Détection sur les 100 ou 200 premiers tokens, scores non pondérés sauf mention contraire, 3 000 réponses par configuration sur Qwen3.5-9B et 1 000 ailleurs. Diversité par Self-BLEU sous clé fixe (100 questions, 32 réponses, 16 en spéculatif) ; comparaison à diversité égale par interpolation au Self-BLEU de TextSeal, avec bootstrap apparié par question.

Schémas comparés : TextSeal avec alpha dans {0.5, 0.7, 0.9} (plus 0.8 et 0.95 sur 9B) ; copule AutoMark et TextSeal2 avec rho dans {0.7, 0.8, 0.9, 0.95} (plus 0.5, 0.6, 0.975, 0.99, 0.995 sur 9B) ; réimplémentation de textGrain avec B = m = 256 et beta dans {0.25, 0.5, 0.75} ; SynthID-Text avec 2 à 30 couches de tournoi sur 9B. PRF de 53 bits (splitmix64).

## 4. Résultats chiffrés

Sans décodage spéculatif (section 4.2, figure 1a). À diversité égale, TextSeal2 détecte 10, 22 et 8 points de pourcentage de plus de réponses de 100 tokens que TextSeal sur Llama-3.1-8B, Qwen3.5-9B et Qwen3.5-27B, avec des intervalles appariés à 95% de [+4, +15], [+15, +25] et [+3, +12]. Face à textGrain : +11 [+4, +17] sur Llama, +1 [-5, +8] sur 9B, -5 [-10, 0] sur 27B. La copule AutoMark, qui coïncide en distribution avec TextSeal2, reste à moins de 3 points : le gain vient de la suppression du pile ou face, pas d'un détail d'implémentation.

Tableau 1, 200 tokens à FPR = 10^-3, sans puis avec spéculatif : SynthID-Text 89% puis 50%, TextSeal 81% puis 71%, copule AutoMark 91% puis 60%, textGrain 89% puis 67%, recette spéculative propre à textGrain 84% sans colonne standard (elle perd 5% de tokens par tour), TextSeal2 91% puis 89%. Les demi-largeurs bootstrap sont de 1 à 3 points.

Code et générations longues. Sur les 500 problèmes de test MBPP, TextSeal2 détecte 55% des réponses à 256 tokens, contre 39% (TextSeal), 46% (textGrain) et 50% (SynthID-Text) ; la copule AutoMark fait 59%. Dans les traces de raisonnement longues (jusqu'à 2 048 tokens), 16% des positions sur ELI5 et 34% sur MBPP répètent une fenêtre antérieure. Continuer la course de chaque fenêtre depuis ses restes plutôt que de l'utiliser une seule fois détecte 3.8 points de plus [+2.1, +5.6] à 256 tokens sur ELI5 et 7.6 points de plus [+2.4, +12.8] à 512 tokens sur MBPP, sans distorsion mesurable.

Spéculatif (section 4.3). Sans watermark, le décodage par block verification avec 8 brouillons émet 2.74 tokens par tour. La course résiduelle diffère de +0.02 [-0.01, +0.05] token par tour, comme le prédit la proposition 1 ; les baselines restent à 0.04 au plus. À diversité égale, TextSeal2 détecte 59% et 89% des réponses de 100 et 200 tokens, contre 31% et 71% (TextSeal), 31% et 67% (textGrain), 25% et 60% (AutoMark) et 17% et 50% (SynthID-Text). La recette propre à textGrain arrive au plus près (52% et 84%) mais au prix de l'acceptation.

PRF. TextSeal utilisait un PRF à 13 bits, (h mod 8191)/8191. La plus grande valeur atteignable est 8190/8191, donc E_v est borné loin de zéro, et un token rare ne peut gagner que si E_v est extrêmement petit : la quantification biaise l'échantillonneur. La moyenne de -ln p_x - H(p) vaut -0.03 plus ou moins 0.12 millinat par token avec des valeurs continues, contre -1.00 plus ou moins 0.14 millinat avec le PRF 13 bits ; le biais atteint -42 millinats sur les positions à 101 à 1 000 candidats. TextSeal2 passe à 53 bits avec splitmix64 et retrouve l'accord avec la copule à clé unique à rho = 0.8 et 0.9 sur les trois modèles.

## 5. Ce que le papier ne donne pas

La section limitations est courte : trois domaines, trois modèles open-weight, températures 0.7 à 1. En spéculatif, l'implémentation est non batchée, aucun gain de temps mural n'est mesuré, et le décodage spéculatif coûte 2 à 4 points de détection. Le code de textGrain n'est pas public, donc la comparaison repose sur une réimplémentation dont les paramètres déployés peuvent différer. Aucune analyse des attaques qui exploitent la connaissance de la clé publique n'est fournie au-delà de la vérification privée. Il n'y a pas de loi nulle fermée exacte en pratique : les seuils sont empiriques, ce qui fragilise une reproduction à petite échelle. Pas de section dédiée aux attaques adaptatives : seulement des substitutions aléatoires et une paraphrase par LLM (tableau 7), et pas de résultats AIME hors décodage spéculatif.

## 6. Ce qu'un participant peut en tirer

Pour une épreuve de 24 h, deux éléments sont réutilisables. La copule d'abord : deux Phi^{-1}, une somme divisée par racine de 2 et une Phi remplacent le routage à deux clés et récupèrent un facteur racine de 2 de rapport signal sur bruit, avec un rho unique qui règle l'entropie retirée. Le piège du PRF 13 bits ensuite : un biais de -1 millinat par token suffit à fausser un test de non-distorsion, candidat idéal pour un exercice de détection de triche. La course résiduelle est belle mais coûteuse à reproduire en une journée ; mieux vaut l'utiliser comme cas de test de préservation de la distribution que comme brique à réimplémenter.
