# Détecter la contamination de benchmark par watermarking des questions

Note de lecture de arXiv:2502.17259v2, « Detecting Benchmark Contamination Through Watermarking », Tom Sander, Pierre Fernandez, Saeed Mahloujifar, Alain Durmus, Chuan Guo (Meta FAIR), 15 octobre 2025.

## 1. Problème et revendications

Un benchmark n'a de valeur que si les modèles évalués ne l'ont pas vu pendant leur pré-entraînement. Or les jeux de test circulent : scrapés, recopiés dans des dépôts, parfois ajoutés volontairement aux données d'entraînement par des équipes qui veulent de bons scores. Détecter cette contamination est difficile : un modèle qui a mémorisé une question et un modèle qui sait répondre se ressemblent.

Les méthodes existantes reposent sur des canaries, faciles à repérer et à supprimer, sur des tests de perplexité, bruyants et dépendants d'un modèle de référence, ou sur des comparaisons de versions du benchmark.

L'idée est de watermarker les questions à la publication : tout modèle entraîné dessus mémorise le biais, détectable par un test à faux positifs contrôlés. Le benchmark devient radioactif au sens de Sander et al. L'utilité et le classement sont préservés, et la détection résiste à un changement de tokenizer.

## 2. Méthode

Le watermarking se fait par rephrasage. Chaque question est réécrite par Llama-3.1-8B-Instruct avec un prompt d'assistant de reformulation, en top-p à p = 0,7 et température 0,5, avec un watermark liste verte et rouge : fenêtre k = 2, liste verte de taille |V|/2, biais δ sur les logits des tokens verts. Quatre forces sont comparées : δ = 0 (rephrasage sans watermark), 1, 2 et 4. Une clé distincte par benchmark évite qu'un modèle contaminé sur ARC le soit sur MMLU.

La détection utilise le mode lecture. On passe la question watermarkée au modèle suspect, on prend la prédiction top-1 à chaque position, on rejoue le hachage sur la fenêtre de tokens de la question d'origine, et l'on ajoute 1 si le token prédit est vert. Le score somme les positions retenues après déduplication : chaque fenêtre n'est scorée qu'une fois, ce qui est indispensable puisque le même k-gram revient souvent dans une question.

Sous H0, le score suit une binomiale B(Ñ, 1/2), où Ñ est le nombre de fenêtres dédupliquées. La p-value s'écrit p = I_{1/2}(s + 1, Ñ − s), avec I la fonction bêta incomplète régularisée. La proposition 1 énonce que si l'on définit « contaminé » comme « a mémorisé le watermark », alors « non contaminé » correspond exactement à H0, et le test de seuil α a un taux de faux positifs égal à α. Le papier précise la limite : c'est plus faible que « la performance est gonflée ». Un modèle peut réussir sans mémoriser le biais, mais les expériences montrent que c'est rare.

Le point technique le plus utile est l'algorithme 1, qui traite des tokenizers différents. On tokenise la question avec T1, utilisé pour le watermarking, et avec T2, celui du modèle suspect. On ne score que les positions où il existe un préfixe textuel commun aux deux tokenisations, et seulement si le token prédit appartient au vocabulaire de T1. La liste verte est calculée avec T1. Le score reste valide sans vocabulaire partagé.

## 3. Protocole expérimental

Trois benchmarks : ARC-Easy avec 1 172 questions, soit 112 000 tokens ; ARC-Challenge avec 2 372 questions, soit 64 000 tokens ; un sous-ensemble de MMLU de 5 000 questions tirées dans toutes les disciplines, MMLU*, soit 325 000 tokens. La concaténation des trois fait environ 500 000 tokens.

Les modèles suspects sont des transformers de 1B entraînés de zéro avec Meta Lingua sur 10 milliards de tokens de DCLM, avec le tokenizer de Llama-3. Architecture : dimension cachée 2 048, 25 couches, 16 têtes. Entraînement : 10 000 pas, batch de 4, séquence de 4 096, sur 64 GPU A-100, learning rate 3 × 10⁻³, weight decay 0,033, warmup de 5 000 pas, décroissance jusqu'à un ratio de 10⁻⁶, gradient clipping à 1,0.

Entre les pas 2 500 et 7 500, on remplace un batch DCLM par un batch tiré des trois benchmarks, tous les 5000/nombre_de_contaminations pas. Chaque batch fait 4 × 4 096 × 64, soit environ 1 million de tokens, donc chaque contamination couvre l'intégralité du benchmark. Niveaux testés : 0, 4, 8 et 16 contaminations.

L'évaluation distingue deux templates. En distribution, le format vu à l'entraînement : « Question: ... Answer: ... ». Hors distribution : « During a lecture, the professor posed a question: ... After discussion, it was revealed that the answer is: ... ». C'est la seconde qui compte, car un benchmark réel utilise un template absent des fichiers ; le tableau 1 est en OOD.

Les ablations portent sur la taille du modèle (135M, 360M, 1B), la fenêtre k (0, 1, 2), la taille du benchmark, le modèle de rephrasage (8B contre 70B) et le tokenizer du modèle suspect (Llama-1/2, Gemma-1/2, Gemma-3, Llama-3). Un essai de canary est mené : une chaîne de 64 chiffres insérée dans une question de MMLU, vue 160 fois pendant l'entraînement d'un modèle de 360M.

## 4. Résultats chiffrés

L'utilité est préservée (figure 3a) : sur ARC-Easy, Llama-3.2-1B, 3B et 8B gardent des performances comparables entre original et versions rephrasées, y compris à 79,5 % de tokens verts, et le classement ne change pas. Les proportions de tokens verts sont 49,9 % à δ = 0, 58,7 % à δ = 1, 66,3 % à δ = 2, 79,5 % à δ = 4. Sur MMLU*, Llama-3.2-1B passe de 38 % à 42 %, mais l'écart existe aussi sans watermark.

Le tableau 1, à δ = 4 et en OOD, relie contaminations, confiance et gain de performance. ARC-Easy : 0 contamination donne -0,3 de log10 p et 53,5 % ; 4 donnent -3,0 et 57,9 % (+4,3 points) ; 8 donnent -5,5 et 63,0 % (+9,5) ; 16 donnent moins de -12 et 71,7 % (+18,2). ARC-Challenge : -0,3 et 29,4 % ; -1,2 et 32,4 % (+3,1) ; -4,5 et 39,3 % (+9,9) ; moins de -12 et 54,3 % (+24,9). MMLU* : -0,9 et 30,6 % ; -5,7 et 35,7 % (+5,1) ; moins de -12 et 40,8 % (+10,2) ; moins de -12 et 54,0 % (+23,5).

Sans contamination, les p-values restent autour de 0,5 (-0,3 en logarithme), conformément à H0. Dès que le gain dépasse 10 %, la détection est très confiante sur les trois benchmarks. À 4 contaminations, le gain de 3 à 5 points donne une p-value convaincante sur ARC-Easy et MMLU*, mais douteuse sur ARC-Challenge, parce que ce benchmark est plus petit : 64 000 tokens contre 112 000 et 325 000.

La taille de fenêtre (tableau 2, 16 contaminations, δ = 4, ARC-Easy) illustre un compromis contre-intuitif. La proportion de tokens verts prédits reste à 0,53, mais le nombre de tokens scorés après déduplication passe de 5 000 à k = 0, à 28 000 à k = 1 et 47 000 à k = 2. La p-value suit : -6,07, -25,89 et -38,69. Contrairement au fine-tuning, où une fenêtre courte aidait la radioactivité, la déduplication limite ici le nombre de tokens disponibles, et une fenêtre plus grande donne plus de preuves.

La taille de modèle (figure 4) joue : à nombre fixe de contaminations, les petits modèles gagnent moins. Mais à gain égal, les p-values sont cohérentes : 4, 8 et 16 contaminations sur les modèles 1B, 360M et 135M donnent environ +6 % et des p-values autour de 10⁻⁵. La méthode mesure le gain réel, pas la taille.

Le canary échoue (tableau 3). Après 160 contaminations, un modèle de 360M ne prédit correctement que 4, 8, 6 et 9 chiffres sur 64 aux pas 2 500, 5 000, 7 500 et 10 000, avec des pertes de 7,4, 6,4, 3,8 et 2,9, et des p-values de 0,9, 0,3, 0,63 et 0,19. Aucune détection, à budget de contamination dix fois supérieur.

Le changement de tokenizer fonctionne (tableau 4, 16 contaminations sur MMLU*, δ = 4). Avec contamination, les log10 p sont -7 pour Llama-1/2 (376M paramètres, 149 000 tokens scorés), -12 pour Gemma-1/2 (806M, 142 000), -15 pour Gemma-3 (818M, 142 000) et -14 pour Llama-3 (561M, 154 000). Sans contamination : -0,1, -0,2, -0,1 et -0,6, donc pas de faux positif. Les exactitudes avec contamination sont 39,1 %, 44,3 %, 44,5 % et 41,2 %, contre 27,4 %, 30,1 %, 30,3 % et 29,6 % sans. Le test est plus faible avec Llama-1, dont le modèle a moins de paramètres.

Le modèle de rephrasage compte pour les benchmarks techniques. Sur les questions mathématiques, le 8B échoue parfois à produire une reformulation cohérente, et le 70B résout une partie de ces cas, sans que le papier sache le quantifier. Avec le 70B, il faut monter δ à 8 pour retrouver la proportion de tokens verts obtenue à δ = 2 avec le 8B. Le réglage de δ dépend donc du benchmark, du modèle de rephrasage et du décodage, et doit être refait à chaque fois.

## 5. Ce que le papier ne donne pas

La méthode vise la contamination non intentionnelle. Un acteur malveillant peut rephraser les questions pour affaiblir le watermark, ou n'entraîner son modèle que sur les réponses conditionnées aux questions. Watermarker les réponses serait une parade, mais leur longueur la rend coûteuse.

Le test suppose un accès en boîte blanche aux logits, ou au moins le calcul de la prédiction top-1 à chaque position. Rien n'est proposé pour un modèle fermé, ce qui exclut la production.

La reformulation dégrade parfois la cohérence d'une question, et le papier admet que ces cas sont difficiles à repérer automatiquement. Pas d'évaluation humaine à grande échelle, pas de mesure du taux de questions cassées. Sur MMLU*, l'écart de 4 points montre que le problème n'est pas théorique.

Pas de garantie sur un rephrasage ultérieur du benchmark par un tiers, ni sur la coexistence de plusieurs watermarks. Pas d'analyse du coût de rephrasage à grande échelle, ni du cas où le benchmark est traduit.

Coût total estimé : environ 10 000 heures GPU, et une détection prend moins de 30 minutes sur un seul GPU.

## 6. Usage concret en hackathon 24 h

C'est le plus directement transposable en démo : rephraser un petit benchmark, entraîner un modèle jouet sur un mélange contaminé, lancer le test en mode lecture. Avec 1 172 questions ARC-Easy et un modèle de 135M, tout tient sur un seul GPU en quelques heures, et la courbe p-value contre nombre de contaminations sort immédiatement.

La valeur ajoutée pour un jury est la comparaison avec le canary : à budget égal, le canary ne détecte rien alors que le watermark donne 10⁻¹². C'est une démonstration chiffrée, reproductible, qui répond à la question « pourquoi watermarker un benchmark plutôt que planter un marqueur ».
