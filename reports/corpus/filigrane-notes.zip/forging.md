# Forging de watermark en boîte noire, à partir d'une seule image

Tomáš Souček, Sylvestre-Alvise Rebuffi, Pierre Fernandez, Nikola Jovanović et al., arXiv 2510.20468, « Transferable Black-Box One-Shot Forging of Watermarks via Image Preference Models », Meta FAIR. Code dans `facebookresearch/videoseal/tree/main/wmforger`.

## 1. Problème et revendications

Le papier attaque un angle mort : le forgery, alors que les travaux existants mesurent le retrait (diffusion, inversion de modèle, attaque guidée par le décodeur). Il ne s'agit pas d'effacer un watermark, mais de le voler sur un contenu authentique et de le recoller sur un contenu qui ne l'est pas. Un faux positif peut faire passer un contenu malveillant pour authentique, ou saturer un détecteur.

Les travaux antérieurs supposent beaucoup trop : Wang et al. exigent des paires image propre / marquée, Li et al. et Dong et al. des milliers d'images au même message pour entraîner un générateur. Ces hypothèses tombent dès que le message change selon l'utilisateur ou la date, ce qui est l'usage réel d'un watermark multi-bit.

La revendication est donc un forgery en conditions réalistes : une seule image marquée, aucune connaissance de la méthode, aucun accès au décodeur, aucune donnée appariée. Et une observation qui donne sa portée au papier : même des méthodes dites « content-aware » (Video Seal, TrustMark) sont attaquables, parce que leur décodeur n'est pas réellement content-aware. Il accepte le watermark extrait d'une autre image.

## 2. Méthode, équations, hyperparamètres

L'idée est de séparer le contenu du watermark en apprenant un prior d'image naturelle. On entraîne un modèle de préférence `R` (ConvNeXt) qui note une image : haut score pour une image propre, bas score pour une image portant des artefacts. On optimise ensuite l'image marquée pour maximiser ce score ; la différence entre l'image d'origine et l'image optimisée est une estimation du watermark, qu'on peut soustraire (retrait) ou recoller ailleurs (forgery).

L'entraînement du modèle de préférence utilise une perte de rang, pas une classification (éq. 1 et 2). Pour une paire `(x+, x−)`, le modèle de Bradley-Terry donne `p(x+ ≻ x−) = exp(R(x+)) / (exp(R(x+)) + exp(R(x−)))`, et la perte est `−E[log σ(R(x+) − R(x−))]`. C'est important : les deux images sont presque identiques, il n'existe pas de seuil global entre les classes, donc une BCE ou une hinge échoue. L'ablation le confirme (tableau 3) : la BCE donne 0.60 / 0.53 / 0.52 / 0.47 en exactitude sur CIN, MBRS, TrustMark, Video Seal, la hinge 0.62 / 0.55 / 0.52 / 0.47, la perte de rang 1.00 / 0.83 / 0.61 / 0.83.

Les paires sont générées procéduralement, sans aucune image marquée réelle. Une image réelle sert de positive, et on ajoute un artefact synthétique `ω` comme négative, tiré dans le domaine de Fourier selon trois familles. Wave : amplitude non nulle sur `N` points le long d'une courbe `(r^{4/5} cos θ, r^{4/5} sin θ)`, avec `N` entre 2 et `N_max`, `r` entre 0 et `r_max`, `θ` sur `[0, 2π]`. Noise : amplitude uniforme entre 0 et `exp(−||(i/σ², j/σ²)||_p)`, avec `p = 4 − 3√p'`. Line : `M` lignes horizontales ou verticales, position gaussienne de variance `ρ²`. La phase est aléatoire, l'artefact est ramené dans `[-0.05, 0.05]`, en RGB ou niveaux de gris, et multiplié dans 50 % des cas par une carte JND pour le localiser dans les zones texturées.

Les valeurs sont en annexe C : `N_max = 50`, `r_max` dans `[60, 200]`, `s_min = 20`, `s_max = 50`, `M_max = 10`.

Le second ingrédient est l'entraînement adversarial du prior. Un modèle entraîné avec l'équation 2 seule produit des gradients ininterprétables et des motifs en damier. On ajoute donc une paire `(x+, x~−)` où `x~− = x− + ε · ∇_{x−} R(x−)`, avec une perturbation plus petite que le watermark : si l'artefact ajouté est plus faible que le watermark, l'image ne doit pas être préférée. Le but n'est pas la robustesse, mais un gradient sémantiquement utile.

L'extraction (éq. 3) est `ŵ = argmax_δ R(x_w − δ)`, par montée de gradient sur `k` pas à learning rate fixe ; le budget de pas contrôle la distorsion. Pour les hautes résolutions, on applique la stratégie de redimensionnement (éq. 4) : on réduit l'image à `H×W`, on estime `ŵ'` à cette résolution, puis on redimensionne `ŵ'` à la résolution de l'image cible `y` et on l'ajoute. Le retrait est la même opération, signe inversé.


Hyperparamètres (section 4.1 et annexe C). ConvNeXt V2-Tiny, entraîné de zéro sur SA-1B, images redimensionnées à 768×768, artefact aléatoire, puis même augmentation et même crop 256×256 pour les deux membres de la paire. 120 k pas, 8 GPU, batch 16 par GPU, 60 heures sur V100, AdamW, learning rate 1e-5. Un batch sur deux remplace la négative par sa version perturbée (deux pas de gradient, learning rate dans `[0.03, 0.09]`). Pour l'attaque : images ramenées à 768×768, SGD, learning rate 0.05, `k` de 50 à 500, six secondes pour `k=50` sur une Quadro GP100 en PyTorch vanilla. Le papier utilise `k=500` pour les résultats principaux, et `k=50` pour les illustrations.

## 3. Protocole et métriques

Quatre cibles post-hoc publiques : CIN (30 bits), MBRS (256 bits), TrustMark (100 bits), Video Seal (96 bits). Cent images SA-1B de validation sont marquées avec le même message, parce que les baselines multi-images ne gèrent pas des messages différents. L'exactitude binaire est la métrique principale, avec le PSNR par rapport à l'image propre comme garde-fou : sans lui, on atteint 100 % en détruisant l'image.

Le protocole est propre : on vole le watermark sur 100 images de test, on l'applique à 100 nouvelles. Pour le retrait, on mesure l'exactitude après retrait, l'objectif étant le hasard.

Baselines : Warfare (six jours sur 8 V100, 1 000 images, un modèle par méthode), moyenne d'images (100 images), noise blending (alpha 0.1) et gray image blending, tous deux via API, DiffPure avec FLUX.1 dev sur les trois derniers pas, CtrlRegen (step 0.1), et un passage VAE encode/décode.

## 4. Résultats chiffrés

Forgery, tableau 1 (exactitude binaire, PSNR). Gray blending : 1.00 / 0.80 / 0.54 / 0.83, PSNR 52.9. Noise blending : 0.82 / 0.61 / 0.52 / 0.53, PSNR 21.8. Warfare : 0.93 / 0.50 / 0.53 / 0.74, PSNR 39.6. DiffPure : 1.00 / 0.83 / 0.59 / 0.75, PSNR 26.6. Moyenne d'images : 1.00 / 0.91 / 0.61 / 0.59, PSNR 26.2. Ours avec une seule image : 1.00 / 0.83 / 0.61 / 0.83, PSNR 31.3.

Lecture. Sur CIN, tout le monde ou presque réussit, parce que le watermark est quasi indépendant du contenu. Sur MBRS, la moyenne d'images fait mieux (0.91 contre 0.83) mais elle a besoin de 100 images. Sur Video Seal, la moyenne d'images s'effondre à 0.59 et la méthode proposée fait 0.83 avec une seule image : c'est le résultat central, l'embedder dépend de l'image mais le décodeur l'ignore en grande partie, donc le watermark est volable. Sur TrustMark, personne ne dépasse 0.61 : l'embedder et le décodeur dépendent tous deux de l'image, et le forgery échoue. C'est la seule méthode qui résiste, et c'est un enseignement de conception.

Retrait, tableau 2 (exactitude, à minimiser). Moyenne d'images : 0.39 / 0.50 / 0.60 / 0.89, PSNR 26.3. DiffPure : 0.86 / 0.56 / 0.56 / 0.60, PSNR 25.4. CtrlRegen : 0.86 / 0.70 / 0.56 / 0.55, PSNR 24.4. Ours : 0.82 / 0.64 / 0.60 / 0.49, PSNR 31.2. La méthode n'est pas la meilleure partout, mais elle combine retrait correct et PSNR élevé, sans hallucination. Le passage VAE ne retire rien (0.99 à 1.00) : la compression neuronale n'est pas une défense.

Ablations, tableau 3. Sans perturbation adversariale : 0.97 / 0.65 / 0.52 / 0.49, PSNR 34.7. Avec de vrais watermarks comme données d'entraînement (scénario gray-box) : 1.00 / 0.67 / 0.58 / 0.77, PSNR 36.9. Avec la recette complète : 1.00 / 0.83 / 0.61 / 0.83, PSNR 31.3. Le résultat contre-intuitif est que les artefacts synthétiques battent les vrais watermarks : ces derniers sont moins divers, et le modèle overfit.

Types d'artefacts, tableau 4 (retrait, à minimiser). Wave seul : 0.98 / 0.83 / 0.55 / 0.45. Noise seul : 1.00 / 0.97 / 0.99 / 0.97. Line seul : 1.00 / 0.95 / 0.99 / 0.95. Les trois : 0.82 / 0.64 / 0.60 / 0.49. Le wave porte presque tout le signal, les deux autres évitent surtout le sur-apprentissage.

Budget de pas, tableau 5 (forgery). `k=50` : 0.99 / 0.75 / 0.56 / 0.75, PSNR 39.3. `k=100` : 1.00 / 0.79 / 0.57 / 0.80, PSNR 37.4. `k=200` : 1.00 / 0.81 / 0.59 / 0.82, PSNR 35.0. `k=300` : 1.00 / 0.82 / 0.60 / 0.83, PSNR 33.4. `k=500` : 1.00 / 0.83 / 0.61 / 0.83, PSNR 31.3. La courbe est plate après 200 pas : on peut donc travailler à `k=200` et gagner 3.7 dB de PSNR pour 0.01 d'exactitude sur MBRS.

Retrait, tableau 6. `k=50` : 1.00 / 0.83 / 0.95 / 0.85, PSNR 38.8. `k=200` : 0.93 / 0.70 / 0.73 / 0.50, PSNR 34.6. `k=500` : 0.82 / 0.64 / 0.60 / 0.49, PSNR 31.2. Il faut 200 pas pour passer sous 0.75 sur TrustMark, contre 50 sur Video Seal : le retrait est plus dur quand le watermark est content-aware.

## 5. Ce qui manque

Le papier ne couvre pas les watermarks sémantiques (Tree-Ring, RingID) : ces méthodes modifient les objets et leur position, un prior d'artefacts haute fréquence ne peut pas les forger.

Le mécanisme du succès sur Video Seal n'est pas isolé : les auteurs l'expliquent par un décodeur qui ignore l'image, mais aucune expérience ne mesure séparément la sensibilité du décodeur au contenu.

La qualité visuelle est mesurée par PSNR uniquement, et l'ablation montre que cette métrique est ambiguë, les variantes qui échouent ayant un PSNR plus élevé. Aucun LPIPS ni jugement humain pour le forgery.

Rien sur la détection du forgery : comment un défenseur repère-t-il un watermark recollé. C'est la question pratique la plus importante, et elle est absente.

## 6. Usage concret en hackathon 24 h

C'est le papier le plus réutilisable pour une épreuve « forcer un détecteur par perturbation minimale » : au lieu d'attaquer le décodeur, on apprend un prior d'image propre et on optimise l'image pour maximiser le score. Avec `k=200` et SGD à 0.05, une image se traite en quelques secondes.

Pour une épreuve de forgery, le protocole du papier est reproductible tel quel : une image marquée suffit, on extrait `ŵ`, on l'ajoute à une image cible, et on mesure l'exactitude binaire du détecteur cible. Le point à vérifier en priorité est le PSNR, sinon le résultat est trivial.

Le tableau 1 cartographie les méthodes fragiles : CIN et MBRS sont volables par simple moyenne, Video Seal par une seule image, TrustMark résiste. Video Seal d'abord, TrustMark en dernier.
