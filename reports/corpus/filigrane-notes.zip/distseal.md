# DistSeal : apprendre à watermarker dans l'espace latent

Sylvestre-Alvise Rebuffi, Tuan Tran, Valeriu Lacatusu, Pierre Fernandez et al., arXiv 2601.16140, Meta FAIR. Code dans `facebookresearch/distseal`.

## 1. Problème et revendications

Le watermarking post-hoc en pixels a deux défauts que le papier attaque frontalement. Le premier est le coût : marquer une image 512×512×3 suppose de faire tourner un U-Net sur 786 432 valeurs, alors que le modèle génératif, lui, a produit un latent de 8×8×128, soit 8 192 valeurs. Le second est la sécurité : dans un modèle open source, l'utilisateur supprime une ligne de code et le watermark disparaît. Le post-hoc est donc efficace pour un déploiement fermé et fragile pour un déploiement ouvert.

DistSeal propose de déplacer le watermark dans le latent, à deux niveaux. D'abord un watermarker post-hoc qui opère sur `z` avant décodage, donc rapide. Ensuite, si on le souhaite, une distillation de ce watermarker soit dans le modèle génératif, soit dans le décodeur latent, ce qui donne un watermark « in-model » : il fait partie des poids et ne peut pas être désactivé par une ligne de code.

Les revendications chiffrées sont : jusqu'à 20 fois plus rapide que le post-hoc pixel, robustesse compétitive, et surtout une observation contre-intuitive, distiller un watermarker latent marche mieux que distiller un watermarker pixel. Le papier présente cela comme la recette d'un watermarking in-model état de l'art pour modèles ouverts.

Un troisième apport, plus discret mais utile, est l'étude des compromis : compatibilité multi-watermark, oubli du watermark après fine-tuning, et choix entre distillation dans le modèle et dans le décodeur.

## 2. Méthode, équations, hyperparamètres

Le watermarker latent prend `z` et un message de `K` bits, et sort `z_w = z + ε · W_θ(z, m)`, où `ε` est le facteur d'échelle qui règle la force. L'image marquée est `x_w = D(z_w)`. À comparer au post-hoc pixel classique, `x_w = x + ε · W_θ(x, m)` : même architecture, même perte, seule change la résolution d'application.

Pour l'autorégressif, il y a deux variantes. Avant quantification : `z_w = Q(z + ε · W_θ(z, m))`, avec estimation straight-through pour rétropropager à travers `Q`. Après quantification : on modifie directement les embeddings des tokens discrets, sans créer une nouvelle séquence de tokens.

La perte (éq. 1) est `L = λ_w · L_w(x_w, m) + λ_disc · L_disc(x, x_w)`. Point notable : aucun terme de reconstruction ni de perception n'est utilisé pour l'embedder post-hoc. Les auteurs expliquent que, sur des latents quantifiés, une petite perturbation dans le latent produit des modifications sémantiques de l'image ; ils préfèrent donc contraindre la force par `ε` et par le discriminateur en pixel, plutôt que par une MSE ou un LPIPS qui pousserait à annuler le signal. C'est un choix contre-intuitif, mais cohérent avec les résultats.

La distillation dans le modèle génératif (éq. 2) est un simple réentraînement supervisé : `L_gen = L_recon(G_φ(x), z_w)`, avec MSE pour le diffusion et entropie croisée pour l'autorégressif. On remplace la cible `z` par `z_w`, et le modèle apprend à produire des latents marqués.

La distillation dans le décodeur (éq. 3) est plus fine : `L_dist = L_rec(D_o(z_w), D(z)) + λ_w · L_w(E_θ(D(z)), m)`, avec `L_rec = ℓ1 + λ_p · L_LPIPS`. On entraîne le décodeur à imiter la sortie du décodeur original appliqué à un latent marqué, tout en gardant l'extracteur dans la boucle. La différence avec Stable Signature est explicite : ici on reconstruit l'image marquée, pas seulement on laisse l'extracteur guider.

Hyperparamètres réellement donnés (section 5.1). Diffusion : DCAE, UViT-H conditionné par classe sur ImageNet, latents 8×8×128 décodés en 512×512. Autorégressif : RAR-XL, autoencodeur MaskGIT-VQGAN, 256×256 en 256 tokens, codebook 1024. Watermarker : architecture VideoSeal, U-Net embedder et ConvNeXt-tiny extractor, mais on retire les couches de downsampling et d'upsampling de l'embedder pour l'adapter à la basse résolution spatiale. Messages de 64 bits. 600 k pas, batch 128, ImageNet. La force `ε` démarre plus haut sur les 100 k premiers pas, puis décroît en cosinus sur 100 k pas. DCAE : de 1.5 à 0.5. RAR après quantification : de 2.0 à 0.5. RAR avant quantification : de 3.0 à 1.5. Pixel : de 0.2 à 0.02.

Distillation : DCAE, reprise de l'entraînement du transformer préentraîné pendant 100 k pas avec latents marqués. RAR, 10 k pas avec séquences de tokens marquées. Décodeur : 10 k pas, Adam, batch 16, montée de learning rate sur 1 k pas jusqu'à 1e-4 puis cosinus, `λ_p = 0` pour DCAE et `λ_p = 1` pour RAR (sans LPIPS, RAR donne des reconstructions floues, figure 14).

## 3. Protocole et métriques

Robustesse : exactitude binaire après transformations, sur 50 000 images générées (post-hoc) ou 50 000 images tirées du modèle distillé (in-model). Les familles sont identité, valuémétrique, géométrique, compression, combiné, avec une moyenne. Qualité : PSNR quand il a un sens, FID et IS sur 50 000 images contre le validation set ImageNet, avec guidance par classifieur pour RAR et sans guidance pour DCAE.

Le protocole post-hoc est apparié : pixel et latent partagent objectifs, schedule, augmentations et hyperparamètres, seul `ε` change pour compenser les échelles de valeur. C'est la bonne façon de comparer, et ça évite l'objection « vous avez moins bien entraîné la baseline ».

## 4. Résultats chiffrés

DCAE, tableau 1. Pixel : PSNR 43.48, FID 10.84, IS 99.53, exactitude 100.00 en identité, 99.89 valuémétrique, 94.70 géométrique, 99.90 compression, 97.29 combiné, 97.78 en moyenne. Latent : PSNR 31.06, FID 11.42, IS 98.11, 99.75 / 98.08 / 91.62 / 99.23 / 84.28, moyenne 95.18. Version coverless : 91.81 de moyenne, 73.94 en combiné. Le FID de référence sans watermark est 10.66, donc l'écart est de +0.18 pour le pixel et +0.76 pour le latent. La chute de PSNR (43.5 vers 31.1) est présentée comme un artefact de métrique : une petite perturbation latente se propage à travers le décodeur et change beaucoup de pixels sans changer la perception. Le FID et l'IS le confirment.

RAR, tableau 2. Pixel : PSNR 41.80, FID 3.09, IS 292.75, moyenne 97.27. Latent avant quantification : pas de PSNR calculable, FID 3.56, IS 239.00, moyenne 90.60, combiné 77.00. Latent après quantification : PSNR 24.54, FID 3.44, IS 250.50, moyenne 93.96, combiné 82.35. Le message : marquer après quantification est meilleur, parce que la quantification efface les perturbations fines et qu'il faut donc changer les tokens eux-mêmes. Mais seule la version avant quantification peut être distillée dans le modèle génératif, puisqu'elle produit une vraie séquence de tokens marquée.

Vitesse. DCAE : 3 ms contre 63 ms par image sur CPU, soit 20 fois. RAR : 17 ms contre 41 ms, soit 2.4 fois, parce que le latent est moins comprimé (16×16×256 contre 256×256×3). C'est le chiffre qui décide de l'usage : 20 fois seulement quand le latent est spatialement très compressé.

Distillation dans le décodeur, tableau 3 (DCAE). Enseignant latent : 95.18 de moyenne. Décodeur distillé avec `λ_w = 0` : 94.41 de moyenne, FID 11.34, donc quasi identique à l'enseignant sans perdre en qualité. Avec `λ_w = 0.1` : 96.77 de moyenne, FID 11.48, soit mieux que l'enseignant. Enseignant pixel : 97.78. Décodeur distillé depuis le pixel avec `λ_w = 0` : 51.38, c'est un échec net. Avec `λ_w = 1.0` : 92.95 mais FID 17.08. Le pixel ne se distille pas dans un décodeur latent ; le latent, si.

Distillation dans le décodeur, tableau 4 (RAR). Enseignant latent après quantification : 93.96, FID 3.44. Décodeur distillé, `λ_w = 0` : 81.40, FID 3.57. Avec `λ_w = 0.5` : 92.33, FID 3.70. Depuis le pixel : 50.15 sans extracteur, 71.25 avec extracteur fort et FID 5.05. Le décodeur de RAR a moins de capacité, et le papier le dit.

Distillation dans le modèle, tableau 5. DCAE : enseignant 95.18, modèle distillé 94.78, décodeur distillé 96.77, avec FID 10.90 pour le modèle contre 11.48 pour le décodeur. RAR : enseignant avant quantification 90.60, modèle 89.13 ; enseignant après quantification 93.96, décodeur 90.57. Conclusion pratique : le modèle génératif donne une meilleure qualité, le décodeur une meilleure robustesse.

Section 5.4 : l'exactitude augmente progressivement au fil des pas de diffusion, et appliquer le modèle distillé seulement sur les derniers pas suffit à retrouver une exactitude élevée. C'est un résultat exploitable : on peut watermarker tard dans la trajectoire et garder l'image quasi identique à la référence, ce qui permet de visualiser le motif par différence.

## 5. Ce qui manque

La sécurité n'est pas évaluée au sens adversarial : pas de forging, pas d'attaque par perturbation minimale, pas de copy attack. L'argument « ne peut pas être désactivé » vaut pour un utilisateur naïf, pas pour un attaquant qui a les poids et peut fine-tuner.

Le tableau 6 mentionne la vulnérabilité du décodeur distillé au remplacement de décodeur et l'oubli du watermark sous LoRA pour le modèle, mais sans chiffres dans le corps. Les chiffres sont renvoyés en annexe H.

Il n'y a pas de résultats sur vidéo, alors que l'architecture vient de VideoSeal et que le latent vidéo est le cas où le gain de vitesse serait le plus spectaculaire. Le titre parle de modèles génératifs en général, le contenu se limite à l'image.

Les transformations géométriques fortes restent un point faible reconnu en conclusion, avec renvoi explicite à SyncSeal comme piste de combinaison, mais aucune expérience de combinaison n'est fournie.

Enfin, `K=64` bits est fixé partout ; aucun balayage de charge utile n'est donné, donc on ne sait pas où se situe le point de rupture quand on veut attribuer un identifiant par utilisateur.

## 6. Usage concret en hackathon 24 h

Pour une épreuve de détection sur contenu généré, le post-hoc latent est le meilleur rapport vitesse / robustesse : 3 ms par image sur CPU, 95 % d'exactitude moyenne, et il s'applique à toutes les sorties d'un même autoencodeur, donc à plusieurs modèles génératifs qui partagent le VAE.

Pour une épreuve d'attribution de modèle, distiller dans le décodeur avec `λ_w = 0.1` donne un watermark dans les poids, qui survit à un fine-tuning du générateur et ne peut pas être retiré en supprimant un appel de fonction : c'est la démo la plus convaincante à faire en 24 h.

Pour une épreuve d'attaque, la distinction pixel / latent est une hypothèse testable en quelques heures : appliquer un débruitage ou une compression neuronale et comparer la chute d'exactitude des deux variantes, ce qui donne un tableau de vulnérabilité par famille de transformation.
