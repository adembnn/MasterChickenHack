# Invariants fonctionnels pour filigraner les grands Transformers (arXiv 2310.11446)

Fernandez, Couairon, Furon, Douze, « Functional Invariants to Watermark Large Transformers », v2 du 18 janvier 2024 (ICASSP 2024). Texte integral lu, version HTML arXiv (38 357 caracteres).

## 1. Probleme et revendications

Le filigranage de modeles (DNN watermarking) cherche a inserer un identifiant dans les poids pour tracer une fuite ou une redistribution non autorisee. Les methodes existantes optimisent les poids pour imprimer le signal : cout de calcul prohibitif a l'echelle d'un 70B, et risque de degrader le modele. Les auteurs proposent l'inverse : exploiter des symetries exactes de l'architecture Transformer pour produire des copies fonctionnellement equivalentes, sans aucun entrainement.

Revendications : (i) identifier un modele par une transformation de ses poids qui ne change strictement aucune sortie, pour tout input ; (ii) un cout d'insertion et d'extraction negligeable, sans GPU, ce qui passe a l'echelle des tres grands modeles ; (iii) une robustesse aux manipulations classiques (fine-tuning, quantification, elagage, bruit) parce que le filigrane est structurel, pas appris ; (iv) un test statistique assorti d'une p-value, puisqu'on veut accuser un modele.

La contrepartie est enoncee par les auteurs eux-memes : un filigrane sans distorsion est aussi effacable sans cout par un attaquant qui connait la methode. Le papier est donc un outil de tracage de copies non malveillantes, pas de preuve contre un adversaire informé.

## 2. Methode, equations

Le cadre est blanc boite non aveugle : on suppose acces au modele original et au modele suspect. Une invariance est une transformation des poids theta vers theta' telle que, pour tout x, f_{theta'}(x) = f_theta(x). Trois familles sont exploitees.

Permutation. Quatre niveaux au moins. (a) Dimension d'embedding : si E' = E_{:,pi} (colonnes permutees selon pi dans Pi^d), il faut propager : W^Q, W^K, W^V, W_1, W_out, Ln_att, Ln_ffn et b_2 permutes sur leur premiere dimension par pi, et W^O, W_2 sur leur seconde. (b) Dimension cachee du FFN : si W_1' = (W_1)_{:,pi} et W_2' = (W_2)_{pi,:} avec pi dans Pi^{d_ff}, la sortie est identique. (c) Tetes d'attention : interchangeables a condition de permuter W^O par blocs de taille d_v sur sa premiere dimension. (d) Interieur de la tete : W^Q et W^K permutables sur leur seconde dimension seulement si les embeddings positionnels n'interviennent pas dans le produit QK, ce qui exclut les rotary embeddings.

Scaling/unscaling. Quand un LayerNorm (ou variante, ici RMSNorm) precede ou suit une couche lineaire, on peut remettre a l'echelle composante par composante les parametres g et b par un vecteur alpha dans R^d, a condition de diviser les lignes de la couche lineaire voisine par le meme alpha. Invariance exacte, mais la quantification des poids en 16 bits fait apparaitre une petite distorsion.

Matrices inversibles dans les produits QK. Si P dans R^{d_k x d_k} est inversible, poser (W^Q)' = W^Q P et (W^K)' = W^K (P^T)^{-1} laisse QK^T inchange. Avec rotary embeddings, P doit etre bloc-diagonale de rotations 2x2 avec un facteur d'echelle lambda, par commutativite des rotations 2D.

Les trois familles se composent dans n'importe quel ordre, ce qui est presente comme un avantage de securite : si Bob annule une invariance, les autres restent, et la collusion entre plusieurs Bobs est brouillee par l'ordre inconnu des operations.

Encodage. Pour chaque invariant et chaque niveau, on restreint l'ensemble des transformations a 2^k choix tires au hasard (par exemple 2^k permutations parmi d!). On choisit celle qui minimise la MSE entre poids observes et poids originaux, et ce choix s'encode sur k bits. Chaque couche porte donc k bits par invariant. Pour LLaMA 7B (L = 32 couches), la permutation et le scaling encodent 2 octets par couche, le produit QK 1 octet, soit 64 octets pour les deux premiers et 32 pour QK ; les trois combines donnent 160 octets. L'extraction accelere en ne gardant que 100 lignes des matrices (facteur 100 environ), au prix d'une robustesse legerement moindre.

Test statistique. Le message extrait est compare a tous les identifiants possibles ; on compte s, nombre de chunks errones. La p-value, probabilite d'obtenir mieux pour un modele aleatoire, s'ecrit

p-value(s) = 1 - (1 - I_{1/2^k}(m - s, s + 1))^N

ou I est la fonction beta incomplete regularisee, m le nombre de chunks et N le nombre de modeles distribues. Formule exacte, donnee en equation (8) du papier.

## 3. Protocole et metriques

Modele : LLaMA, principalement 7B, avec pre-normalisation RMSNorm, activation SwiGLU et rotary embeddings ; 13B et 30B pour le cout de calcul. Utilite mesuree par prediction du token suivant sur des sequences aleatoires de Wikipedia tokenisees avec le tokenizer LLaMA : 1k sequences de 256 tokens, token predit par argmax, distorsion = proportion de tokens predits differents entre modele filigrane et original.

Attaques : fine-tuning supervise, 3 epochs, learning rate 2e-5, memes reglages que la reference citee ; bruit gaussien centre de variance sigma ajoute aux poids ; quantification uniforme sur b bits entre min et max ; elagage L1 (mise a zero des plus petits poids) a 50 % de sparsite.

Reglages du filigrane : permutation des tetes d'attention et des couches FFN ; scaling avec log10(alpha) uniforme sur [-1, 1] ; pour QK, d/2 angles de rotation tires aleatoirement ; k = 8 choix par bloc, donc un octet par choix ; 2 octets par couche sauf QK (1 octet).

Metrique principale : byte accuracy, pourcentage d'octets correctement recuperes, moyennee sur N = 100 modeles filigranes (un seul pour le fine-tuning). S'y ajoute la p-value du test.

## 4. Resultats chiffres

Table 1, sur LLaMA 7B, colonnes bruit sigma = 1,0, quantification 3 bits, elagage 50 %, fine-tuning :

Permutation : distorsion 0,20 %, byte accuracy 51,4 (99,6 sans acceleration de l'extraction), 72,0 (100,0), 100,0, 100,0.
QK : distorsion 0,18 %, 100,0 partout.
Scaling : distorsion 0,24 %, 100,0, 98,1 (100,0), 100,0, 100,0.
Combine : distorsion 1,77 %, 60,8 (99,8), 70,0 (99,4), 100,0, 100,0.

Les auteurs notent que les erreurs viennent essentiellement de l'acceleration de l'extraction, pas des attaques. Une byte accuracy de 50 % sur 64 octets suffit a identifier un modele : les p-values sont toujours sous 10^-60, et 8 octets corrects sur 64 donnent deja 10^-8.

Utilite : distorsion sous 1,8 % des tokens predits pour toutes les variantes, jusqu'a 2,5 % au dernier token d'une sequence de 1024 pour le scaling. Les auteurs qualifient cela de negligeable pour l'usage du modele.

Cout (Table 2) : sur 7B, insertion 3,5 s (permutation), 2,7 s (scaling), 7,4 s (QK) ; extraction 9,2 s, 31,7 s, 6,0 s. Sur 13B (L = 40, d = 5120) : 7,0, 4,9, 15,8 s en insertion et 14,1, 30,3, 7,7 s en extraction. Les temps sont mesures sur 2 coeurs Xeon 6230, 480 Go de RAM, sans GPU ; l'extraction complete sans acceleration prend environ 20 minutes.

## 5. Ce qui manque

Le modele de menace est faible. L'article reconnait que la methode est inutile contre un Bob qui connait l'algorithme : il peut annuler l'invariance sans degrader le modele, et Alice ne peut alors que conclure a une copie non autorisee, sans identifier le fuyard. Aucune experience ne mesure cette attaque, alors que c'est l'attaque evidente.

La comparaison aux methodes d'optimisation de poids est qualitative : pas de tableau face a Uchida et al. ou aux methodes de « deep watermarking » sur le meme LLaMA, donc l'affirmation « passe a l'echelle » n'est chiffree que par le temps d'insertion.

L'evaluation se limite a LLaMA et a la prediction du token suivant sur du Wikipedia. Rien sur des taches en aval, rien sur des modeles a expert (MoE), rien sur les modeles vision ou audio, qui ont d'autres symetries (permutation de canaux, de tetes) et qui sont precisement ceux qui circulent le plus.

Le point faible du scaling est la quantification : l'invariance n'est exacte qu'en arithmetique reelle, et le papier mesure l'ecart mais ne propose pas de correction (arrondi coordonne, choix de alpha entier).

Enfin, la detection exige les poids originaux. C'est un cadre non aveugle, donc inutilisable par un tiers qui n'a pas le modele source, ce qui limite le cas d'usage « detection de contenu genere » et cantonne la methode au controle de licence.

## 6. Usage concret en hackathon 24 h

C'est le papier le plus rapide a reproduire : aucune formation, du calcul matriciel pur, et un resultat binaire (le modele est-il une copie de celui-la ?). En 24 h, on peut implementer la permutation des tetes sur un petit modele (GPT-2, Llama 3.2 1B), verifier bit a bit que les sorties sont identiques, puis extraire le message apres quantification 4 bits et elagage, et tracer la byte accuracy en fonction du taux d'elagage. Le protocole du tableau 1 est directement transposable.

Deuxieme usage, plus offensif : implementer l'attaque manquante du papier, c'est-a-dire annuler l'invariance (retrier les tetes selon un ordre canonique, normaliser les RMSNorm) et mesurer le cout en temps et en distorsion. Un hackathon qui montre qu'un filigrane « sans distorsion » s'efface en dix minutes de script est un resultat fort, et le papier fournit toutes les equations necessaires.

Troisieme usage, en detection de provenance : combiner cette methode avec un hash de poids pour distinguer « copie non modifiee », « copie filigranee » et « fine-tuning ». Le test p-value de l'equation (8) donne une reponse propre a la question « est-ce le meme modele ? » sans ambiguite, ce qui est rare dans ce domaine.
