# SyncSeal : synchronisation géométrique par watermarking profond

Pierre Fernandez, Tomáš Souček, Nikola Jovanović, Hady Elsahar, Sylvestre-Alvise Rebuffi et al., arXiv 2509.15208, Meta FAIR. Code dans `facebookresearch/wmar/tree/main/syncseal`.

## 1. Problème et revendications

La synchronisation est la brique oubliée du watermarking. Un détecteur suppose que l'image est dans le même repère géométrique que celle qui a été marquée. Dès qu'on recadre, tourne, retourne ou applique une perspective, ce repère disparaît et le détecteur échoue, même si le signal est intact. Le papier rappelle que le problème est ancien (les années 1990, avec motifs de synchronisation ou recherche exhaustive) mais qu'il a été largement contourné par les méthodes profondes, qui comptent sur l'augmentation de données pour rendre le watermark « invariant » à la géométrie.

Les auteurs contestent cette solution. L'invariance s'obtient au prix de la capacité et de l'invisibilité, et elle ne couvre jamais toute la famille des homographies. Deux exemples cités font mal : Tree-Ring tombe sur une simple translation, Stable Signature sur un flip horizontal. Plus récemment, WMAR a introduit une couche de synchronisation autonome, mais limitée à quatre messages binaires dans les quadrants, avec recherche de lignes séparatrices, donc seulement rotation modérée, flip et crop en coin haut-gauche.

SyncSeal revendique une synchronisation générique, autonome, qui prédit directement les paramètres de la transformation plutôt que de les chercher. La revendication forte est dans le tableau 1 : rotation, flip horizontal, crop et perspective, tous complets, là où LECA ne fait que le crop, DWSF que le crop, Wang et al. partiellement rotation et crop, et WMAR partiellement rotation et crop, sans perspective.

## 2. Méthode, équations, hyperparamètres

Toute transformation géométrique raisonnable est une homographie `H ∈ R^{3×3}` à 8 degrés de liberté (`H_33 = 1`), qui envoie un point normalisé `p ∈ [-1,1]^2` de l'image d'origine vers `q` dans l'image transformée (éq. 1). Une homographie est déterminée par quatre paires de points non colinéaires. D'où le choix central : au lieu de régresser les 8 coefficients de `H`, le réseau prédit les quatre points `p_1..p_4` de l'image d'origine qui correspondent aux quatre coins de l'image transformée, `q_1..q_4 = (-1,-1), (1,-1), (1,1), (-1,1)`. C'est une paramétrisation plus stable, et elle rend la sortie interprétable : on voit où le cadre d'origine se trouve dans l'image reçue.

L'embedder (éq. 2) produit une distorsion `w` de même dimension que l'image, contrainte par `tanh` et appliquée sur le canal de luminance seulement, avec une carte JND qui atténue le signal là où l'œil est sensible :

`I_w = I + α_w · w`, `w = JND(I) ⊙ tanh(Emb(I))`.

L'extracteur prend l'image possiblement transformée `Ĩ_w` et sort un vecteur de `R^8`, les quatre points prédits. On en déduit `H`, puis on inverse la transformation avant d'appeler l'extracteur du watermark primaire. C'est un module autonome : il s'ajoute après n'importe quelle méthode.

Les deux réseaux sont entraînés de bout en bout. La perte (section 3.3) est `L = L_sync + λ_adv · L_adv`, avec `L_sync = Σ_{i=1..4} ||p̂_i − p_i||_1`. Le choix de la norme L1 plutôt que L2 est justifié par la parcimonie et de meilleurs résultats en pratique. Le terme adversarial est `L_adv = -D(I_w)` avec un discriminateur en patchs, entraîné séparément avec une perte hinge ; l'architecture du discriminateur est reprise telle quelle d'une référence citée.

Hyperparamètres donnés : embedder U-Net de 3.3 M de paramètres, extracteur ConvNeXt-v2 Tiny de 27.9 M, images 256×256, SA-1B, AdamW, learning rate 1e-3, 300 000 itérations, batch 192, `α_w = 0.2`, `λ_adv = 0.1`, environ deux jours sur 8 V100 16 Go.

Augmentations : chaque image subit au hasard 3 transformations géométriques parmi identité, crop, flip horizontal, rotation, perspective, et 2 transformations valuémétriques parmi JPEG, flou gaussien, luminosité, contraste, saturation. Les plages sont explicites : aire du crop de 0.3 à 1.0, rotation de ±135 degrés, perspective jusqu'à 0.3 de déplacement relatif d'un coin le long d'un bord, JPEG qualité 40 à 80, luminosité, contraste et saturation de 0.5 à 2.0, flou de noyau 1 à 9. La rotation à ±135 degrés est le chiffre à retenir : c'est bien au-delà des ±20 degrés de WMAR.

Limite assumée et importante : la méthode ne prédit pas les changements d'échelle. Elle ne peut pas retrouver la résolution d'origine d'une image redimensionnée. Ce n'est pas gênant pour les méthodes qui travaillent à résolution fixe (Tree-Ring, Gaussian Shading, WMAR, WAM), mais ça le serait pour HiDDeN ou pour un watermark de modèle génératif utilisé à plusieurs résolutions.

## 3. Protocole et métriques

Trois mesures. Qualité : PSNR et SSIM sur 1 000 images SA-1B de test à 512×512. Précision de synchronisation : distance L2 moyenne, en pixels, entre coins prédits et coins réels, sur une grille de transformations géométriques (identité, flip, rotation 5 et 90 degrés, crop 0.5 et 0.9, perspective 0.3) croisée avec des transformations valuémétriques (identité, gris, teinte 0.1, luminosité 0.5 et 2.0, contraste 0.5 et 2.0, JPEG 40, flou 9). Application : exactitude binaire du watermark primaire, avec et sans SyncSeal, sur CIN, MBRS, TrustMark, WAM à 512×512, et TPR à FPR 1 % pour WMAR et Tree-Ring à 256×256 sur 1 000 images conditionnées par classe ImageNet. Comparaison externe : SIFT + RANSAC (non aveugle, il faut l'image d'origine) et la synchronisation de WMAR (aveugle).

Le point méthodologique solide est que la comparaison se fait à augmentations identiques, sauf pour WMAR, restreint au crop haut-gauche parce qu'il ne sait pas faire les autres crops. C'est une asymétrie qui joue en faveur de WMAR sur ce point précis, et il perd quand même largement.

## 4. Résultats chiffrés

Précision de synchronisation, tableau 2, en pixels (plus bas est mieux). Moyenne sur toutes les colonnes valuémétriques : 0.8 en identité, 3.8 en flip, 4.9 en rotation 5, 6.3 en rotation 90, 8.9 en crop 0.5, 4.9 en crop 0.9, 21.7 en perspective 0.3, soit 7.3 en moyenne générale avec un écart-type de 16.4. Les cas durs sont identifiés : contraste 0.5 avec perspective 0.3 monte à 90.2 ± 50.6 pixels, et luminosité 2.0 avec crop 0.5 à 14.5 ± 19.6. Autrement dit, la synchronisation tient sous transformation isolée, et se dégrade quand une photométrie extrême se combine à une géométrie forte. C'est exactement le régime d'une image retouchée puis recadrée.

Comparaison, tableau 3. SyncSeal : PSNR 43.9 dB, SSIM 0.994, insertion 12 ms, extraction 12 ms. WMAR : PSNR 35.2, SSIM 0.971, insertion 69 ms, extraction 565 ms. SIFT : extraction 146 ms. En distance de coins, SyncSeal fait 3.3 / 0.5 / 3.8 / 6.6 (flip, rotation 10, crop 0.7, perspective 0.1) contre 1.7 / 5.5 / 55.1 / 49.3 pour WMAR et 1.5 / 1.8 / 1.6 / 1.5 pour SIFT. Le message est clair : SyncSeal est environ 47 fois plus rapide que WMAR à l'extraction, avec une qualité d'image très supérieure, et il reste compétitif avec SIFT qui triche en utilisant l'original. Le crop 0.7 est le seul cas où WMAR n'est pas ridicule, et c'est précisément la transformation qu'il a été conçu pour faire.

Application, tableau 4. CIN passe de 0.60 à 0.93 d'exactitude moyenne (identité 1.00, flip 0.98, rotation 30 de 0.49 à 1.00, crop 0.5 de 0.50 à 0.83, perspective 0.3 de 0.50 à 0.84). MBRS de 0.60 à 0.76. TrustMark de 0.71 à 0.97, WAM de 0.83 à 0.99. WMAR avec sa propre synchronisation : 0.56 de moyenne, 0.01 en rotation 30 et 0.01 en perspective 0.3 ; avec SyncSeal : 0.97, et 1.00 en rotation 30, 0.92 en crop 0.5, 0.95 en perspective 0.3. Tree-Ring passe de 0.39 à 0.88 de moyenne, avec 0.94 en rotation 30 et 0.77 en perspective 0.3.

Deux chiffres à retenir pour un jury : la TPR de WMAR sous rotation 30 degrés passe de 1 % à 99.8 %, et sous perspective 0.3 de 1 % à 95 %. C'est un facteur cent, pas une amélioration marginale.

## 5. Ce qui manque

Aucune analyse de sécurité. Le module ajoute un signal connu et détectable ; on peut se demander si un attaquant qui perturbe la synchronisation ne gagne pas plus qu'en attaquant le watermark primaire. Le papier ne pose pas la question.

Pas d'évaluation de l'empilement de deux watermarks en termes de capacité ou de bruit : SyncSeal ajoute sa propre distorsion à celle du watermark primaire, et la qualité finale est mesurée pour SyncSeal seul (43.9 dB), pas pour SyncSeal plus WAM ou plus TrustMark. Le tableau 4 ne donne pas les PSNR des combinaisons.

Le changement d'échelle est explicitement hors scope, ce qui exclut les images redimensionnées entre plateformes, cas pourtant banal.

Les résultats par force de transformation sont partiellement agrégés : on a la grille du tableau 2, mais pas de courbe continue par angle ou par ratio de crop.

Enfin, l'entraînement et l'évaluation se font en 256×256 pour l'embedder, en 512×512 pour l'évaluation de qualité. Rien n'est dit sur le comportement à 4K, alors que l'upsampling de la distorsion est justement ce qui pourrait casser la précision des coins.

## 6. Usage concret en hackathon 24 h

Importer le module et le mettre devant un détecteur qui échoue : sur une épreuve de contenu transformé (crop, rotation, flip), synchroniser puis extraire donne un gain immédiat et mesurable, sans réentraîner le détecteur principal.

Utiliser la sortie en quatre points comme signal d'analyse : la distance résiduelle entre coins prédits et coins estimés par une autre méthode (SIFT, features) est un indicateur de manipulation, et elle est gratuite en calcul.

Pour une épreuve d'attaque, tester la synchronisation comme point faible : une perturbation qui vise la prédiction des coins, et non le watermark, peut faire tomber tout le pipeline en aval, ce qui est une piste à documenter même sans résultat complet en 24 h.
