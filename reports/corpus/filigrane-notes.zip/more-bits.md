# We Can Hide More Bits: The Unused Watermarking Capacity in Theory and in Practice (arXiv 2510.12812v2)

## 1. Problème et revendications

L'état de l'art du watermarking d'images s'est stabilisé autour de 100 à 200 bits pour un PSNR supérieur à 40 dB, avec une bonne robustesse. Les progrès récents portent sur la qualité et la robustesse, mais la capacité ne bouge plus. La question que pose le papier (Aleksandar Petrov, Pierre Fernandez, Tomáš Souček, Hady Elsahar, Oxford et Meta FAIR) est donc directe : ce plateau est-il une limite fondamentale ou une défaillance des modèles.

La réponse se construit en deux temps : une théorie géométrique de la capacité, où l'image est un point sur une grille entière de dimension $cwh$ et la capacité le nombre de points admissibles sous contraintes de fidélité et de robustesse ; puis des expériences contrôlées qui éliminent une à une les explications de l'écart, distribution des données, résolution, augmentations, architecture.

Les revendications sont triples. (i) Des bornes supérieures de capacité sous contrainte PSNR seule et sous contrainte PSNR plus robustesse à des transformations linéaires, qui dépassent de plusieurs ordres de grandeur ce que font les modèles. (ii) La démonstration expérimentale que ces bornes ne sont pas absurdes : un modèle linéaire encode 2 048 bits, du tuilage atteint 32 768 bits, un schéma artisanal atteint 456 509 bits à 42 dB, là où Video Seal échoue à 1 024 bits. (iii) Chunky Seal, une version agrandie de Video Seal, qui encode 1 024 bits, soit quatre fois plus, avec une qualité et une robustesse comparables.

Le message final : les modèles actuels sont significativement sous-optimaux, et il reste de la place pour de l'innovation architecturale, pas seulement pour du scaling.

## 2. Méthode, équations, hyperparamètres réellement donnés

Le cadre est purement géométrique. Une image est un vecteur de longueur $cwh$, chaque élément prenant $2^k$ niveaux, avec $\rho = 2^k - 1$. L'ensemble des images valides est $\mathcal{I} = \{0,\dots,\rho\}^{cwh}$, une grille entière. Bound 1 donne la capacité absolue, $\log_2(2^k)^{cwh} = cwhk$ bits, soit 1,57 Mbit pour une image couleur $256 \times 256$.

La contrainte de fidélité est un PSNR minimal $\tau$, qui équivaut à une boule $\ell_2$ :
$$\mathrm{PSNR}(x,\tilde{x}) \geq \tau \iff \|x - \tilde{x}\|_2 \leq \epsilon(\tau), \quad \epsilon(\tau) = \rho\sqrt{cwh}\,10^{-\tau/20}.$$
Le problème devient un comptage de points entiers dans l'intersection d'un cube et d'une boule. Trois régimes : boule contenant le cube (Bound 2, capacité $cwhk$), boule dans le cube (Bounds 3 et 4), intersection partielle (Bounds 5 et 6). Le cas de l'image arbitraire au coin du cube est traité en section 3.3 (Bounds 7 à 9) : le recouvrement est divisé par $2^{cwh}$, mais la perte est au plus de 1 bit par pixel. La position de l'image dans la plage dynamique n'explique donc pas le déficit observé.

La robustesse est traitée en section 3.4. Une transformation linéaire $M$ suivie d'une quantification $Q$ (arrondi) transforme la boule en ellipsoïde, éventuellement de rang inférieur. Les auteurs introduisent un facteur heuristique basé sur les valeurs singulières :
$$\xi_M = \prod_{i : \sigma^i_M > 0} \min(\sigma^i_M, 1),$$
qui capture l'effet des directions comprimées (perte de capacité) et ignore les directions étirées (pas de gain, puisque deux points peuvent se projeter sur la même image). Les Bounds 10 à 12 donnent la capacité sous $M$ comme capacité sans contrainte plus $\log_2 \xi_M$, avec des corrections quand la boule sort du cube. Ce ne sont pas de vraies bornes : la figure 9 montre un cas où la capacité réelle dépasse la prédiction de 20 %, la figure 10 un cas où elle lui manque de 16 %. Un Bound 13 conservateur, fondé sur un majorant du volume de la préimage d'un cube par un zonotope, donne une vraie borne inférieure, très lâche.

JPEG est traité par LinJPEG : l'unique étape non linéaire, l'arrondi des coefficients DCT, est remplacée par la suppression des diagonales hautes fréquences, ce qui donne un opérateur linéaire de rang réduit. La qualité va de 0 à 15, 15 signifiant aucune fréquence supprimée.

Les expériences contrôlées réentraînent Video Seal dans un cadre simplifié : une image grise uniforme, aucune augmentation, perte MSE seule. Paramètres : 600 epochs, batch 256, 1000 batches par epoch, cosinus avec 20 epochs de warmup. Messages testés : 128, 256, 512 et 1 024 bits, à $256 \times 256$ puis $32 \times 32$.

Chunky Seal monte Video Seal en échelle : dimension d'embedding 2 048, multiplicateurs de canaux du U-Net de $[1,2,4,8]$ à $[4,8,16,32]$, watermark sur les trois canaux, soit un embedder 90 fois plus gros. L'extracteur ConvNeXt passe de profondeurs $[3,3,9,3]$ à $[3,3,27,3]$, de dimensions $[96,192,384,768]$ à $[256,512,1024,2048]$, avec un stride initial de 2 au lieu de 4, soit 23 fois plus gros. Tailles : 1 022,7 M et 773,7 M de paramètres. Clipping de gradient à 0,01, décrit comme critique pour la stabilité.

## 3. Protocole et métriques

Les bornes sont calculées en bits par pixel à $16 \times 16$, l'intégration numérique en dimension 768 n'étant pas tractable plus haut, et la capacité par pixel étant invariante en résolution.

Trois familles de transformations sont étudiées : recadrage et redimensionnement (échelles 0,25, 0,5, 0,75), rotation (15°, 30°, 45°), et LinJPEG (qualités 8, 10, 15). Le PSNR de référence des tableaux conservateurs est 42 dB.

Le tuilage marque indépendamment chaque tuile de $32 \times 32$ avec un message distinct et concatène les décodages. Le schéma artisanal encode un mot en base $q$ sur les axes d'un hypercube inscrit dans la boule PSNR, avec
$$q = 2\lfloor 2^k 10^{-\tau/20} \rfloor + 1,$$
ce qui donne une capacité de $cwh \log_2 q$ bits et un décodage trivial par mesure de position sur chaque axe.

Chunky Seal est évalué sur SA-1B à résolution originale, avec PSNR, SSIM, MS-SSIM, LPIPS, temps d'embedding et d'extraction, et comparaison à Video Seal, HiDDeN, MBRS, TrustMark et WAM.

## 4. Résultats chiffrés

Bornes. À 45 dB sur une image $16 \times 16 \times 3$, environ 2 000 bits, soit plus de 2,5 bpp, et environ 500 000 bits pour $256 \times 256$. Le coin du cube coûte au plus 1 bpp, la distribution des données environ 0,05 bpp. Le tableau 1, à 42 dB, en borne conservatrice : flip horizontal 3,064 bpp (602 353 bits) ; recadrage et redimensionnement 25 % 0,107 bpp (20 958 bits) ; 50 % 0,015 bpp (3 013 bits) ; 75 % 0,005 bpp (904 bits) ; LinJPEG q=8 0,134 bpp (26 273 bits) ; q=10 0,136 bpp (26 757 bits) ; q=15 0,137 bpp (27 020 bits) ; rotation 15° 0,084 bpp (16 502 bits) ; 30° 0,075 bpp (14 676 bits) ; 45° 0,083 bpp (16 401 bits). En borne heuristique, un recadrage à 0,25 laisse encore environ 0,5 bpp à 40 dB, soit 98 304 bits.

Video Seal réentraîné (tableau 2). À $256 \times 256$ : 128 bits à 53,45 dB et 100 %, 256 bits à 53,98 dB et 100 %, 512 bits à 51,45 dB et 100 %, mais 1 024 bits à 40,10 dB et seulement 89,63 %. À $32 \times 32$ : 512 bits à 41,66 dB et 100 %, 1 024 bits plafonne à 84,39 % à 29,66 dB, et les variantes à 33,20 et 34,63 dB restent à 83,86 et 83,78 %. Le modèle échoue donc à 1 024 bits même sur une image grise uniforme sans augmentation.

Modèle linéaire : 1 024 bits à 100 % pour 44,28 dB, et 2 048 bits à 100 % pour 40,40 dB, après 50 epochs seulement, avec $\lambda_i$ balayé sur 4, 8, 12, 20. Tuilage : le modèle $32 \times 32$ à 512 bits, qui atteint 100 % à 41,66 dB, répété 64 fois, donne 32 768 bits au même PSNR, soit 0,167 bpp. Schéma artisanal : 623 232 bits à 36 dB, 551 948 à 38 dB, 456 509 à 42 dB, 311 616 à 48 dB, tous à 100 %.

Chunky Seal (tableau 3, SA-1B). Capacité 1 024 bits, soit 0,0052 bpp contre 0,0013 pour Video Seal. PSNR 45,32 dB contre 44,42, SSIM 0,995 contre 0,996, MS-SSIM 0,997, LPIPS 0,0085 contre 0,0019. Exactitude des bits : 99,74 % en identité, 99,65 % après flip, 98,27 % en rotation jusqu'à 10°, 99,74 % en redimensionnement 71 à 95 %, 98,25 % en recadrage 77 à 95 %, 98,99 % en luminosité, 99,54 % en contraste, 98,79 % en JPEG 50 à 80, 99,74 % en flou jusqu'à $k=9$, et 99,15 % en moyenne globale.

Les tableaux étendus nuancent le résultat. Sur SA-1B (tableau 4), Chunky Seal reste à 97,18 % en JPEG 40. Mais sur COCO (tableau 5), il tombe à 65,86 % en JPEG 40, 72,47 % en JPEG 50, 84,65 % en flou $k=17$ et 49,84 % en recadrage 32 %, alors que Video Seal garde 97,79 % en JPEG 40 sur le même jeu. La capacité n'est donc pas gratuite sur toutes les distributions.

## 5. Ce qui manque

Les bornes sous robustesse sont des heuristiques, pas des bornes supérieures, et les bornes valides sont si conservatrices qu'elles restent peu informatives. Les calculs à $16 \times 16$ supposent que le bits par pixel s'extrapole, ce qui reste une hypothèse. Les transformations ne sont pas combinées : la robustesse à un recadrage plus une rotation plus un JPEG n'est pas bornée. Le cas vidéo est laissé de côté. Chunky Seal est très gros et lent, donc difficile à déployer à l'échelle. Enfin, l'échec de Video Seal n'est pas expliqué causalement : le papier évoque l'apprentissage d'une identité comme difficulté connue, sans diagnostic fin.

## 6. Usage concret en hackathon 24 h

Le premier usage est un budget. Pour attribuer une image à un générateur parmi trois, il faut coder $\log_2 3$ informations, avec redondance. Le tableau 1 donne le budget après un recadrage à 25 % et un JPEG : environ 20 000 bits en borne conservatrice, donc plusieurs centaines de bits par zone survivent. De quoi dimensionner un identifiant de 64 bits répété.

Le second usage est le schéma artisanal en base $q$ : trivial, sans entraînement, 456 509 bits à 42 dB. Si un watermark pixel direct est autorisé, c'est le baseline le plus rapide à coder.

Le troisième usage concerne la perturbabilité : $\epsilon(\tau) = \rho\sqrt{cwh}\,10^{-\tau/20}$ donne la norme $\ell_2$ autorisée pour un PSNR cible, donc le budget d'une attaque par perturbation minimale avant de coder l'optimisation. Une attaque à 38 dB a bien plus de marge qu'à 45 dB.

Les échecs rapportés sont une carte des pièges. Video Seal ne sait pas encoder 1 024 bits même sur une image grise : pour entraîner un détecteur en une nuit, mieux vaut un modèle linéaire ou du tuilage qu'un U-Net, et mieux vaut valider sur COCO JPEG 40 que sur SA-1B, où Chunky Seal perd plus de 30 points.
