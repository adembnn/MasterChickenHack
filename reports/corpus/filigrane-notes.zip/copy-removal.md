# Sécurité du watermarking ML : attaques de copie et de retrait

Vitaliy Kinakh, Brian Pulfer et al., Université de Genève, arXiv 2409.18211, « Evaluation of Security of ML-based Watermarking: Copy and Removal Attacks ».

## 1. Problème et revendications

Le papier évalue la sécurité d'une famille précise de watermarking : celle qui utilise l'espace latent d'un modèle de fond préentraîné. Le schéma étudié vient de travaux antérieurs (référence 5 dans le papier), et il fonctionne par optimisation adversariale : on optimise une image pour que sa représentation latente `f_φ(x)` tombe dans une région de détection, ou projette le bon signe sur des porteuses orthogonales, sous contrainte de distorsion. L'approche est élégante : elle ne modifie pas le modèle et s'applique aux modèles de fondation ouverts.

La question est simple et rare : que se passe-t-il si l'attaquant connaît le modèle de fondation, mais ni la clé ni le message ? C'est le cas réaliste, puisque DINOv1 est public et que la clé est secrète. Les auteurs en déduisent deux attaques, et une conclusion sévère : DINOv1 est trop vulnérable pour servir de support à un watermark, et son usage n'est pas recommandé.

Quatre contributions : une attaque de copie généralisée qui ne suppose pas l'additivité du watermark, des attaques de retrait ciblée et non ciblée, une étude du choix de cible, et une alerte sur les modèles de fondation publics.

## 2. Méthode, équations, hyperparamètres

Le cadre de détection est d'abord posé, parce que les attaques en dépendent.

En zéro bit, la clé `k` génère une porteuse secrète `w` de norme 1 dans l'espace latent de dimension `d`. La région de détection est le double cône (éq. 1) : `D_k = {z : |z^T w| > ||z|| cos γ}`. L'angle `γ` est fixé par le taux de fausse acceptation visé, via la fonction bêta incomplète régularisée (éq. 2) : `P_fa = 1 − I_{cos²γ}(1/2, (d−1)/2)`. La fonction de perte associée (éq. 3) est `L_Z^I(z, w) = ||z||² cos²θ − (z^T w)²` ; son signe dit si l'échantillon est dans la région, son amplitude à quelle distance il se trouve de la frontière ou à quelle profondeur il est à l'intérieur.

En multi-bit, le message `m ∈ {−1,1}^ℓ` est décodé par le signe des projections sur une famille orthogonale de porteuses `{w_1, ..., w_ℓ}` générée par la clé : `m̂ = (sign(z^T w_1), ..., sign(z^T w_ℓ))`. La marge est contrôlée par `μ ≥ 0` dans la perte (éq. 4) : `L_Z^II(z, m) = (1/ℓ) Σ max(0, μ − (z^T w_i)·m_i)`.

L'insertion (éq. 5 et 6) minimise, sur les transformations `T` tirées uniformément dans un ensemble `T` (rotation, crop, flou), `L_W(x, x_0, T) = λ L_Z(f_φ(T(x))) + L_X(x, x_0)`. L'ensemble admissible `C(x_0)` est défini par deux normalisations du delta pixel : une atténuation par carte SSIM, qui cache le signal dans les zones peu visibles, puis une remise à l'échelle pour atteindre un PSNR cible.

L'attaque de copie (éq. 7) prend une image marquée `x_w` et une image cible `x_t`, et optimise `L_A^C = L_X(x_a, x_t) + λ L_Z^III(z_a, z_w)`, avec `L_Z^III = − z_a^T z_w / sqrt(||z_a||² ||z_w||²)`. C'est une similarité cosinus négative : on rapproche le latent de l'image attaquée de celui de l'image marquée, sans jamais utiliser la clé. La version multi-images (éq. 8) moyenne la similarité sur `L` images marquées avec la même clé et le même message, ce qui compense l'ignorance de la région d'acceptation ; les auteurs observent que `L=1` suffit déjà, et n'expérimentent donc pas la variante multi-images en section V.

Le retrait non ciblé (éq. 9) éloigne le latent de `z_w` : `L_A^{R-U} = L_X(x_w, x_a) − λ L_Z^IV(z_w, z_a)`, avec `L_Z^IV = (z_a^T z_w)² / sqrt(||z_a||² ||z_w||²)`. Le carré supprime le signe, donc éloigner dans un sens ou dans l'autre revient au même. Le retrait ciblé (éq. 10) rapproche le latent d'une image cible `x_t` : `L_A^{R-T} = L_X(x_w, x_a) + λ L_Z^III(z_t, z_a)`.

Les deux attaques sont des descentes de gradient sur `N` itérations, suivies des mêmes deux normalisations (masque SSIM, remise à l'échelle au PSNR cible) et d'un arrondi des pixels. Les hyperparamètres réellement donnés : `PSNR_w` fixé à 42 dB pour l'image marquée d'origine, `PSNR_a` cible variant de 30 à 45 dB, `P_fa` cible dans `{10^-5, 10^-6, 10^-7}`, charge utile `ℓ` dans `{10, 30, 50, 100}` bits, 10 clés différentes, 800 images DIV2K de résolution typique 2000×1500. Le `λ` et le nombre d'itérations `N` ne sont pas chiffrés dans le corps du papier.

Le choix de cible pour le retrait ciblé est étudié explicitement, avec trois stratégies : une image non marquée quelconque, une version fortement dégradée de l'image marquée (filtre de Wiener), ou un vecteur aléatoire de l'espace latent. La deuxième est la meilleure : Wiener 25×25 maximise la probabilité de non-détection pour tous les `P_fa` testés, parce que l'optimisation part d'une image déjà dépourvue de watermark et se contente de restaurer la qualité.

## 3. Protocole et métriques

Backbone : ResNet-50 entraîné avec DINOv1, donc self-supervisé. Le watermark est celui de la référence 5, en version zéro bit et multi-bit, avec les mêmes paramètres que la publication d'origine.

Métriques. Pour la copie en zéro bit, le taux de succès est la proportion d'images non marquées qui sont faussement acceptées après l'attaque, à `P_fa` cible donné. Pour la copie en multi-bit, c'est le BER. Pour le retrait en zéro bit, c'est la probabilité de non-détection `P_m` (l'image n'est plus détectée). Pour le retrait en multi-bit, c'est le BER, avec 0.5 comme borne du hasard.

Le PSNR atteint dépasse souvent la cible, la normalisation SSIM et la remise à l'échelle ne garantissant pas la valeur exacte. Les courbes sont tracées contre le PSNR effectif, pas contre la cible, ce qui est la bonne pratique.

## 4. Résultats chiffrés

Copie, zéro bit (section V-A). Le taux de succès vaut 1 sur toute la plage de `PSNR_a` et pour les trois `P_fa` testés (10^-5, 10^-6, 10^-7), avec une seule image marquée. C'est un résultat sans nuance : la copie fonctionne toujours, à toutes les qualités d'attaque.

Copie, multi-bit (figure 2). À faible `PSNR_a`, le BER est nul ou quasi nul, et le message binaire est parfaitement copié. À `PSNR_a = 45 dB`, le BER reste très inférieur à 1 %, même avec 100 bits. L'augmentation de la charge utile dégrade le BER seulement à `PSNR_a = 47.5 dB`, valeur qui sort de la plage principale. Autrement dit, la clonabilité est forte et la longueur du message n'est pas une défense.

Retrait non ciblé, zéro bit (figure 3). `P_m` approche 1 pour `PSNR_a` autour de 40 dB, et décroît quand `PSNR_a` augmente vers 50 dB. C'est attendu : plus on autorise de distorsion, plus le watermark est détruit.

Retrait non ciblé, multi-bit (figure 4). Le BER augmente fortement et la majorité des bits est inversée, pour toutes les charges utiles testées. À 30 dB de `PSNR_a`, l'attaque est dévastatrice.

Retrait ciblé, zéro bit (figure 5). Avec Wiener 25×25 comme cible, `P_m` atteint les meilleures valeurs pour les trois `P_fa`. La comparaison des figures 3 et 5 donne le chiffre clé : retrait ciblé et non ciblé atteignent tous deux `P_m` proche de 1 dès que `PSNR_a ≤ 41 dB`. Le ciblé est plus stable, mais l'écart pratique est faible.

Retrait ciblé, multi-bit (figure 6). Le BER décroît quand `PSNR_a` augmente. Les trois stratégies de cible ont des profils différents : "autre image" exige le plus de distorsion (30 à 37 dB) pour casser le message, le vecteur latent aléatoire atteint des BER comparables dès 37 dB mais avec une variance élevée selon la longueur du message, et l'image débruitée atteint des résultats similaires dès 39 dB avec la même variabilité. La conclusion est que la sélection de cible déplace le point de fonctionnement de plusieurs dB, ce qui est beaucoup pour une attaque qui ne connaît ni clé ni message.

Asymétrie copie / retrait. Le papier conclut que le retrait est plus efficace que la copie contre les deux schémas, et que la copie est plus facile en zéro bit qu'en multi-bit, parce que l'espace latent multi-bit est plus difficile à imiter : il faut satisfaire `ℓ` projections simultanément, alors que le zéro bit ne demande qu'une direction. C'est cohérent avec les courbes : la copie zéro bit est parfaite, la copie multi-bit dépend de la charge utile.

Un point qualitatif utile : les résultats du retrait non ciblé sont instables selon `PSNR_a`. Les auteurs l'expliquent par la nature du problème : éloigner un latent sans cible définit une infinité de solutions optimales, alors qu'une cible fixe impose une direction unique. C'est une observation de méthode, pas seulement d'expérience.

## 5. Ce qui manque

Un seul backbone, DINOv1 ResNet-50. Les auteurs le reconnaissent et appellent à tester d'autres modèles de fondation et autoencodeurs, mais aucune conclusion générale n'est possible : on ne sait pas si la vulnérabilité est propre à DINOv1 ou à la famille entière.

Aucune défense n'est évaluée. Pas de watermark avec clé dépendante du contenu, pas de détection de forge, pas de réentraînement de l'extracteur. Le papier mesure l'attaque, pas la contre-mesure.

Les paramètres d'optimisation (`λ`, `N`, pas de gradient) ne sont pas chiffrés dans le corps, ce qui rend la reproduction dépendante du code des auteurs. Le coût par image n'est pas donné non plus, alors que c'est ce qui décide de la faisabilité d'une attaque à l'échelle d'une plateforme.

Le protocole est limité aux images DIV2K et aux transformations d'insertion (rotation, crop, flou) : rien sur la vidéo, les codecs ou le redimensionnement.

La comparaison avec des schémas classiques comme Broken Arrows est citée en perspective mais absente : on ne sait pas si le problème vient du watermarking ML ou de cette implémentation.

## 6. Usage concret en hackathon 24 h

C'est la référence pour une épreuve de reconstruction de données privées ou de retrait : l'attaque ne demande ni clé ni message, seulement le backbone public. Sur un watermark latent, une descente de gradient sur la similarité cosinus, avec masque SSIM et PSNR cible, suffit à faire tomber la détection.

Le réglage utile est le PSNR cible : à 41 dB, la non-détection est quasi totale, et c'est un bon point de départ. En dessous, on détruit trop l'image et le jury le verra ; au-dessus de 45 dB, l'attaque devient marginale.

Pour une épreuve de forgery, la copie zéro bit est le cas le plus simple : une seule image marquée, une cible, et un taux de succès de 1. Elle permet de démontrer en quelques minutes qu'un détecteur latent ne prouve rien sur la provenance d'une image.

Limite à garder en tête : le résultat est obtenu sur DINOv1 ; sur un autre backbone, l'attaque est transférable dans son principe, pas dans ses chiffres.
