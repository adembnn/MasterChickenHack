# Watermarking post-hoc par rephrasage : ce que valent vraiment les schémas de décodage

Note de lecture de arXiv:2512.16904v2, « How Good is Post-Hoc Watermarking With Language Model Rephrasing? », Pierre Fernandez, Tom Sander, Hady Elsahar, Hongyan Chang, Tomáš Souček, Valeriu Lacatusu, Tuan Tran, Sylvestre-Alvise Rebuffi, Alexandre Mourachko (FAIR, Meta Superintelligence Labs), 16 janvier 2026.

## 1. Problème et revendications

Le watermarking de génération suppose que l'on contrôle le décodeur au moment où le texte est produit. Or une grande partie des textes à tracer existe déjà : livres sous droit, articles, bases documentaires indexées par un RAG, jeux d'évaluation. La question est donc simple : peut-on appliquer un watermark de type génératif à un texte déjà écrit, en le faisant réécrire par un LLM lui-même watermarké, sans détruire le sens ni la qualité ?

Cette pratique, le watermarking post-hoc par rephrasage, hérite d'une littérature ancienne de substitution de synonymes, qui plafonne à un ou deux bits par phrase. Les watermarkers neuronaux apportent autre chose : des tests statistiques avec contrôle du taux de faux positifs. Le papier revendique la première évaluation à grande échelle du paradigme, sur prose littéraire, Wikipedia et code, avec un cadre logiciel ouvert, TextSeal.

La thèse centrale est que le post-hoc transforme le compromis : le budget de calcul devient un paramètre, alors qu'en génération temps réel la latence l'interdit.

## 2. Méthode et hyperparamètres

Le pipeline tient en quatre étapes : découper le texte en chunks, demander à un modèle instruct de paraphraser chaque chunk avec un contexte antérieur et des consignes de préservation, échantillonner le token suivant sous watermark, agréger les scores sur les chunks.

Le prompt système impose de préserver sens, style et structure, et de ne sortir que le texte reformulé, sans commentaire.

Côté watermark, tous les schémas partagent une fenêtre de deux tokens et une fonction pseudo-aléatoire qui prend le token candidat, la fenêtre et la clé secrète. Les variantes testées, avec leurs grilles réellement balayées, sont : Green-Red List de Kirchenbauer avec δ dans {1, 2, 4} ; DiPMark avec α dans {0,2 ; 0,3 ; 0,4} ; MorphMark avec κ fixé à 10 et p0 dans {0 ; 0,05 ; 0,1 ; 0,2} ; SynthID-Text avec un nombre de tournois k dans {10, 20, 30}, en score moyen et pondéré ; Gumbel-max, piloté par la température et top-p ; et WaterMax, avec L dans {4, 8, 16} candidats et m dans {4, 8}.

Le traitement de la clé est le point statistique le plus intéressant. Un tirage de clé fixé peut biaiser la proportion attendue de tokens verts sous H0, par exemple de 0,5 à 0,505, ce qui suffit à faire s'effondrer les p-values sur des textes longs. La parade consiste à tester 50 clés candidates par combinaison (tokenizer, schéma, profondeur SynthID), à mesurer l'écart à la loi uniforme par la statistique de Kolmogorov-Smirnov sur 100 textes non watermarkés, puis à retenir la meilleure. La validité est contrôlée sur 1,5 million de documents Wikipedia, dont la longueur va jusqu'à 100 000 tokens pour une moyenne de 715. Sans ce tri, les résultats mesureraient en partie un artefact de clé.

Le décodage est le second levier : échantillonnage noyau avec T dans {0,7 ; 1,0 ; 1,2} et top-p dans {0,9 ; 0,95 ; 0,99} ; beam search avec des largeurs B dans {3, 5, 10} et deux critères de sélection, probabilité du modèle de base (non biaisé) ou du modèle watermarké (biaisé) ; WaterMax, qui génère plusieurs candidats non watermarkés puis garde celui qui maximise le score.

La détection peut être filtrée par l'entropie : on recalcule l'entropie par token sur le texte watermarké, avec le même modèle que pour le rephrasage, et l'on ne score que les positions au-dessus d'un seuil τ balayé de 0 à 2,0 par pas de 0,2. L'original n'étant pas disponible à la détection, les entropies diffèrent de celles de la génération, ce que les auteurs signalent.

Quatre métriques : p-value, BERTScore, entropie croisée du texte rephrasé sous Mistral-7B-v0.3 avec préfixe de contexte, ratio de longueur. Pour le code s'ajoute le pass@1. Les chiffres des sections 4.2 à 4.5 et 4.8 sont des médianes sur 100 passages d'environ 800 caractères, soit 200 tokens, tirés des romans de Dickens.

## 3. Protocole expérimental

Trois corpus : les livres de Gutenberg, des débuts d'articles Wikipedia, et le code de HumanEval et MBPP. Le code représente 164 échantillons HumanEval de 180 tokens en moyenne et 974 échantillons MBPP de 80 tokens, avec des longueurs de 20 à 500 tokens. Les tests unitaires sont exclus du watermarking, et un post-traitement restaure le nom du point d'entrée attendu par le harnais.

Les modèles de rephrasage couvrent quatre familles et toutes leurs tailles : Llama-3 instruct en 1B, 3B, 8B et 70B ; Gemma-3 en 1B, 4B, 12B et 27B ; Qwen-2.5 en 0,5B, 1,5B, 3B, 7B, 14B et 32B ; SmolLM-2 en 135M, 360M et 1,7B. Le filtrage de longueur ne retient que les sorties dans un rapport de 0,75 à 1,25, et une configuration n'apparaît dans les figures que si assez de générations valides subsistent.

Pour le code, la TPR est mesurée à FPR = 10⁻³ sur tous les échantillons puis sur les seuls codes qui passent les tests, car les échecs produisent des répétitions qui gonflent artificiellement la TPR.

## 4. Résultats chiffrés

Sur la frontière qualité-détectabilité en échantillonnage aléatoire avec Llama-3.2-3B-Instruct (figure 2), Gumbel-max domine, suivi de MorphMark et de SynthID. C'est contre-intuitif, car Gumbel-max est critiqué en génération temps réel pour son déterminisme : à prompt identique, sortie identique. En post-hoc, la critique perd l'essentiel de sa portée.

Le beam search améliore la frontière pour toutes les méthodes compatibles, surtout avec le score biaisé (figure 4). Gumbel-max est exclu de la comparaison puisqu'il est déterministe. Un schéma médiocre en échantillonnage peut donc devenir compétitif si l'on paie le coût du beam search.

La taille de modèle joue en sens inverse selon la métrique (figure 3). Les grands modèles préservent mieux le sens : dans la famille Llama, le 8B atteint une entropie croisée plus basse que le 3B et le 1B à force de watermark comparable. Mais ils atteignent difficilement des p-values très basses, parce que leur distribution est moins entropique. Gemma-3 est pratiquement absent de la zone de forte détectabilité, y compris dans ses petites tailles. Il faut donc un petit modèle pour cacher un watermark fort, et un gros pour préserver finement le style.

Le filtrage par entropie à la détection déçoit. Le gain ne dépasse jamais 20 %, et selon les méthodes la proportion de configurations pour lesquelles il existe un seuil améliorant la détection de plus de 5 % sur au moins la moitié des textes va de 36 % à 57 %, avec 0 % pour WaterMax (figure 5). Pour WaterMax, tout seuil dégrade la détectabilité, parce que la méthode optimise le score au niveau de la phrase et non du token : filtrer ne fait que retirer des preuves.

WaterMax est le contre-exemple le plus instructif. Ses performances de détection sont faibles dans tous les hyperparamètres testés, et surtout il n'est pas radioactif : sur environ 100 000 tokens watermarkés, le test de radioactivité donne une p-value de 0,93 pour Green-Red en échantillonnage aléatoire, 0,76 pour Green-Red en beam search biaisé, mais 1,0 × 10⁻⁶ pour WaterMax (annexe A.4). La sélection du meilleur candidat crée un biais vers les tokens verts qui n'est pas appris au niveau du token, donc un modèle innocent qui partage la distribution du générateur paraît contaminé.

Sur le code (tableau 3, Gumbel-max, top-p 0,95), le compromis est plus dur. À T = 1,4, Llama-3.2-1B a un pass@1 de 0,16 mais une médiane de -log10 p de 9,10 sur l'ensemble et de 1,56 sur le code correct, avec une TPR de 0,72 et 0,29. Llama-3.2-3B monte à 0,53 de pass@1, avec 1,84 et 1,00 de détection et une TPR de 0,34 et 0,13. Llama-3.1-8B atteint 0,71 de pass@1, 2,31 et 1,83 de détection, 0,41 et 0,29 de TPR. Llama-3.3-70B a 0,90 de pass@1 mais 0,44 de détection et une TPR nulle. Le 8B offre une meilleure frontière que le 70B à pass@1 comparable (figure 7b). Aucune configuration n'obtient à la fois un pass@1 et une TPR élevés.

Le multilinguisme (tableau 4, Llama-3.1-8B, Gumbel-max) montre un coût supplémentaire. À T = 1,2, l'anglais donne 8,147 de -log10 p pour une SBERT de 0,946, l'espagnol 20,098 pour 0,921, le français 19,705 pour 0,911, le russe 23,689 pour 0,836. Les langues non anglaises sont watermarkables, mais avec une similarité plus basse.

Le découpage en chunks est déterminant sur les documents longs (tableau 5, Llama-3.2-3B). À 4 000 tokens, le contexte complet donne un ratio de longueur de 0,70, une détection de 24,9 et une similarité de 0,84 ; le découpage en chunks de 500 tokens avec jusqu'à 1 000 tokens de contexte donne 0,86, 198,3 et 0,91.

## 5. Ce que le papier ne donne pas

Aucune évaluation humaine. Les auteurs le justifient par le recours au code comme mesure objective, mais la fidélité stylistique reste mesurée par BERTScore et entropie croisée, deux proxys aux angles morts connus.

Aucune étude de robustesse aux attaques. Le texte watermarké est supposé rester en l'état. On ne sait pas ce que devient la détection après un nouveau paraphrasage, un résumé ou une traduction, alors que ce sont les manipulations naturelles d'un document diffusé. Pour un usage défensif, c'est une vraie limite.

Pas de théorie de la capacité : des points expérimentaux, mais aucune borne sur les bits ou la p-value atteignables pour un budget, une longueur et une fidélité donnés. Pas de multi-bit, pas de traçage d'utilisateur, pas de scénario où plusieurs versions circulent avec des clés différentes. Pas d'analyse du coût en tokens ni du temps de rephrasage, alors que le procédé multiplie les appels au modèle.

## 6. Usage concret en hackathon 24 h

Le papier est directement exploitable comme banc d'essai : prendre 100 passages, rephraser avec un petit modèle, comparer Gumbel-max et Green-Red, tracer la courbe p-value contre BERTScore. Faisable en quelques heures sur un GPU.

Deux résultats à réutiliser tels quels : Gumbel-max est le meilleur choix par défaut en échantillonnage, et le beam search biaisé est le levier le plus rentable pour les autres schémas. Le troisième, plus subtil, est le tri de clé par statistique KS, qui évite de présenter une fausse détection comme un résultat.
