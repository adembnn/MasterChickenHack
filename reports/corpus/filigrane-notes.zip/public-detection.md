# La détection de watermark LLM peut-elle être publique ?

Papier arXiv 2610.12106, Meta FAIR et University of Maryland (Georgios Milis, Tom Sander, Tomáš Souček, Heng Huang, Pierre Fernandez). Code : github.com/facebookresearch/textseal.

## 1. Problème posé et revendications

Les fournisseurs gardent leurs détecteurs secrets, au motif qu'un détecteur public aiderait à faire des éditions ciblées guidées par le score. Or les watermarks sont déjà vulnérables sans aucun accès. Deux questions : combien un détecteur public aide-t-il réellement, à chaque niveau d'accès, du score par token au verdict binaire ? Et, aucune construction cryptographique n'étant à la fois robuste, rapide et vérifiable publiquement, existe-t-il un compromis praticable pour les watermarks statistiques ?

La réponse proposée est une construction à clé scindée : une clé publique alimente un détecteur ouvert, une clé privée reste pour la vérification complète et la forensique. Un attaquant informé ne peut déplacer que le signal public, ce qui crée un déséquilibre entre les deux canaux. Les auteurs en font un test statistique calibré, puis l'intègrent dans un mécanisme à deux étages. Ils revendiquent que le détecteur public améliore surtout la suppression à petits budgets d'édition, active la falsification mais que celle-ci reste majoritairement détectable, et que divulguer une moitié du watermark est un compromis acceptable entre transparence et sécurité.

## 2. Méthode

Rappel. Le Gumbel-max choisit x_t = argmax_v r_t(v)^(1/p_t(v)) et le détecteur teste S = somme_t -log(1 - r_t(x_t)), qui suit Gamma(n,1) sous H0. TextSeal route chaque token vers l'une de deux clés avec probabilités alpha et 1 - alpha, puis fusionne les scores en S = alpha S1 + (1 - alpha) S2, calibré par une Gamma à moments appariés qui donne p_fus.

Clé scindée. On note S_pub et S_priv les scores accumulés sous k_pub et k_priv, chacun testé contre sa propre loi nulle, ce qui donne deux p-values p_pub et p_priv. Le détecteur public renvoie p_pub à tout le monde. La plateforme garde le test sur le score fusionné alpha S_pub + (1 - alpha) S_priv, noté p_fus, pour son verdict forensique. Le papier fixe alpha = 0.5, ce qui rend les deux canaux échangeables sur un texte non altéré : les différences par token d_t = s_pub,t - s_priv,t sont symétriques autour de zéro.

Test d'altération. La statistique est T = S_pub - S_priv = somme_t d_t. Une suppression diminue le signal public (T < 0), une falsification l'augmente (T > 0). Les deux queues testent l'échangeabilité des clés. La loi de T sous watermark n'ayant pas de forme fermée, elle est calibrée par un test de permutation à retournement de signe : R vecteurs epsilon dans {-1,+1}^n, T(r) = somme epsilon_t d_t. Les p-values sont

p_removal = (1 + #{r : T(r) <= T}) / (1 + R),
p_forgery = (1 + #{r : T(r) >= T}) / (1 + R).

Avec R = 5 x 10^4 permutations, la plus petite p-value atteignable est 2 x 10^-5, ce qui couvre le seuil de 10^-3.

Mécanisme à deux étages. Le premier étage compare p_fus au seuil du FPR cible et produit le label binaire y_fus. Le second réévalue ce verdict avec le test d'altération : un texte non détecté est testé pour suppression, un texte détecté pour falsification. Choisir la queue selon y_fus laisse les deux calibrées, car renommer les canaux change leur différence mais pas leur somme. Conséquence assumée : un texte non filigrané peut échouer à l'un ou l'autre test, donc son FPR est 2 x 10^-3, tandis qu'un texte authentiquement filigrané ne fait face qu'à la queue de falsification.

Attaques informées. Quatre niveaux d'accès : no-box (aucun détecteur), black-box (verdict binaire), gray-box (p-value du texte), white-box (scores par token). Le gray-box équivaut au white-box : le score d'un token s'approxime par la différence de p-value qu'il cause. Deux familles : paraphrase par régénération autorégressive, et éditions de mots en place. En white-box, la paraphrase utilise le Gumbel inversé, x_t = argmax_v (1 - r_v)^(1/p_v), ou un biais additif, l_v <- l_v - lambda log r_v. Les éditions remplacent le token de plus haut score par le candidat MLM de plus bas score. La falsification inverse les objectifs : (1 - r_v) devient r_v, le biais devient + lambda log r_v, et les éditions visent les tokens de faible r.

Métriques. Une attaque réussit quand le test de watermark et le test d'altération renvoient tous deux le mauvais label. Avec y le vrai label, y_c le label du détecteur c dans {pub, fus} et t = 1 l'événement "altération détectée" :

ASR_c = Pr[y_c != y], ADR = Pr[t = 1 | y_fus != y], ASR_net = ASR_fus (1 - ADR).

ASR_pub est ce que l'attaquant observe, ASR_fus ce que le défenseur voit avant le second étage, ASR_net ce qui survit aux deux. La distortion est mesurée par 1 - BERT-F1 contre le texte d'avant attaque.

## 3. Protocole expérimental

Génération avec Qwen2.5-7B, watermark TextSeal à deux clés, alpha = 0.5, contextes h = 3 symétriques dans chaque canal. 1 000 échantillons ELI5 : chaque entrée fournit un prompt pour obtenir un texte filigrané destiné aux attaques de suppression, et la réponse humaine comme texte porteur pour la falsification. Longueur maximale 400 tokens (360 en moyenne), top-p 0.95, top-k 50, température 1. Les porteurs de falsification sont les 1 000 réponses ELI5 les plus longues, 220 tokens en moyenne. Seuil de détection et seuil d'altération à FPR = 10^-3. Proxy de paraphrase : Qwen2.5-3B avec lambda = 1, sauf mention contraire. Éditions de mots avec RoBERTa MLM. L'attaquant black-box essaie des paraphrases à températures croissantes par pas de 0.2 et garde la première qui inverse le verdict ; pour les éditions, il interroge le détecteur après chaque mot et s'arrête au premier retournement ou au budget.

Extensions : Gemma-3-4B-IT et SmolLM2-1.7B-Instruct (D.2), CaLMQA (D.9), Maryland (gamma = 0.25, delta = 2) et SynthID-Text (profondeur 30, gamma = 0.5) en section 4.5. Calibration sur 10 000 textes non filigranés et 5 992 générations filigranées intactes.

## 4. Résultats chiffrés

Vulnérabilité d'un détecteur public (tableau 1, Gumbel-max et Maryland, paraphrase additive et 10% d'éditions de mots). Gumbel-max à une clé, suppression par paraphrase : 70.4% en no-box, 81.4% en black-box, 99.9% en white-box. Suppression par éditions de mots : 1.5%, 1.6%, 72.2%. Falsification par paraphrase : 0.0%, 0.6%, 20.8%. Maryland à une clé : suppression par paraphrase 90.1%, 96.1%, 100.0% ; falsification par paraphrase 0.4%, 1.1%, 78.6%. Maryland à deux clés : suppression par éditions 34.4%, 40.4%, 98.7%. Le white-box est le seul niveau qui active directement la falsification, jusqu'à 79% d'ASR sur Maryland : publier un détecteur pleinement transparent est exclu. En black-box, la falsification reste au hasard, faute de score à viser, mais la suppression gagne en compromis ASR/distortion, l'attaquant s'arrêtant au retournement.

Défense par clé scindée (section 4.3, figure 4). Les attaques informées atteignent presque 100% d'ASR public, mais élargissent l'écart public/privé que le test d'altération détecte, donc l'ASR net baisse. L'attaquant informé ne fait mieux que le no-box qu'aux plus petits budgets, où il lui faut moins d'éditions pour le même effet. Pour la falsification, c'est l'inverse : sans accès elle ne réussit qu'au hasard, tandis que l'accès public permet d'élever les scores publics. L'ASR_net reste au-dessus de la ligne de base quasi nulle mais il est borné : les attaques faibles ne bougent pas le score fusionné, les fortes séparent les canaux et le test d'altération en attrape la majorité. En black-box, l'ADR est de 0%, car des éditions non ciblées affaiblissent les deux canaux également et laissent T inchangé ; le premier étage assure alors toute la défense.

Attaques adaptatives (tableau 2, rephrase T = 1, éditions 20%). Un attaquant qui dépasse la p-value cible d'un facteur m évite mieux le test d'altération, mais le prix est asymétrique. Suppression par paraphrase : ASR_net 80.7% en no-box, 88.1% à m = 10, 98.7% à m = 10^3. Suppression par éditions : 25.6% en no-box, 8.8% à m = 10, 0.6% à m = 10^3, avec un ADR de 99.4% à ce réglage. Pousser très loin rend donc l'attaque de nouveau détectable.

Calibration du test d'altération (annexe C.3, tableau 3). Sur 799 générations non filigranées, les taux de signalement sont 3.88%, 5.01% et 8.51% (watermark, altération, l'un ou l'autre) à eta = 0.05 ; 0.63%, 0.88% et 1.50% à eta = 0.01, sous la borne d'union 2 eta (9.75% et 1.99%). Sur 5 992 générations filigranées non altérées, les faux verdicts de falsification tombent à 5.31%, 1.05% et 0.17% pour eta = 0.05, 0.01 et 10^-3.

Coût (tableau 4). La détection coûte 43.9 ms en moyenne CPU sur 1 000 textes et partage une passe de scoring avec le test d'altération, qui coûte 23.3 ms pour 5 x 10^3 permutations, 276.9 ms pour 5 x 10^4 (réglage par défaut) et 5 518.5 ms pour 10^6.

Généralisation et variantes (tableaux 8, annexe D.2 et E). Gemma-3-4B à température 1.5 : paraphrase white-box 98.8% d'ASR_fus avec ADR 12.2%, éditions white-box 68.6% avec ADR 53.1%, falsification par éditions 20.1% avec ADR 20.4%. SmolLM2-1.7B : paraphrase no-box 91.7%, éditions white-box 23.7% avec ADR 26.2%. Donner une fenêtre plus large au canal public, (10,3) contre (3,3), dégrade l'ASR_net à toutes les tailles (65.3% contre 78.8% à 296 tokens) tout en portant l'ADR à environ 40% : l'asymétrie n'apporte qu'une preuve forensique.

## 5. Ce que le papier ne donne pas

Le papier ne revendique aucune sécurité cryptographique : elle repose sur le secret de la clé privée. Le code des expériences n'est pas encore publié, seule la base TextSeal est disponible. Le gray-box n'est traité qu'en annexe D.7, avec un score estimé par différence de p-value qui devient bruité pour les éditions, car retirer un token re-seed les h positions suivantes. Le FPR du pipeline complet est 2 x 10^-3 et non 10^-3. La distortion se limite à 1 - BERT-F1, sans mesure humaine. La graine et l'implémentation du PRNG de permutations ne sont pas détaillées, et la résolution de p-value (2 x 10^-5) limite les seuils bas. Enfin, l'évaluation principale couvre un seul jeu de données, et les taux par langue de CaLMQA reposent sur moins de 100 documents.

## 6. Ce qu'un participant peut en tirer

C'est le papier le plus utile pour une épreuve de 24 h sur l'attaque et la détection : taxonomie d'accès claire, attaques précises (Gumbel inversé, biais additif, éditions MLM) et métrique unique ASR_net, qui empêche de se mentir sur un succès apparent. Le test de permutation est implémentable en quelques dizaines de lignes et donne un avantage immédiat pour distinguer un texte réécrit d'un texte authentique. Résultat contre-intuitif à exploiter : un attaquant qui s'arrête au seuil est plus facile à coincer qu'un attaquant qui pousse loin, et un détecteur binaire suffit presque pour la suppression, donc on peut prototyper sans accès fin.
