# Mutations log-normales et detection d'images truquees (arXiv 2409.15119)

Labiad, Back, Fernandez, Najman, Sander, Ye, Zameshina et al., « Log-normal Mutations and their Use in Detecting Surreptitious Fake Images », v2 du 25 septembre 2024. Texte integral lu, version HTML arXiv (72 955 caracteres, 1865 lignes).

## 1. Probleme et revendications

Deux problemes s'emboitent. Premier probleme, optimisation boite noire : beaucoup d'attaques contre les systemes de detection (et contre les filigranes) se ramenent a minimiser une fonction inconnue avec un budget de requetes, et les methodes classiques sont soit tres specialisees (Square Attack pour les images), soit generiques mais lentes. Deuxieme probleme, detection d'images truquees : les detecteurs d'images generees sont attaques par des methodes boite noire qui rendent une image fausse invisible au detecteur, et il faut detecter ces attaques pour que la moderation tienne.

Revendications : (i) etendre la mutation log-normale, concue pour le pseudo-booleen, a des domaines continus, entiers et mixtes, ce qui la rend applicable aux pixels ; (ii) montrer qu'elle reste competitive sur les benchmarks Nevergrad et qu'elle egale Square Attack en succes d'attaque, avec moins d'artefacts ; (iii) proposer une defense : des classifieurs qui detectent les images attaquees, y compris pour des attaques non vues a l'entrainement.

C'est le papier le plus methode du lot : peu de theorie, un algorithme simple, et une etude systematique. Il est aussi le plus directement transposable a l'attaque de watermarking, puisque la boucle « attaquer un detecteur puis detecter l'attaque » est exactement celle qui occupe un hackathon de securite.

## 2. Methode, equations

Algorithme (1 + lambda) EA avec mutation log-normale. On part d'un point x tire uniformement, puis a chaque generation on produit lambda descendants. Pour chacun :

q ~ N(0, 1)
p^(i) = (1 + ((1 - p) / p) * exp(gamma * q))^(-1)
l^(i) ~ Bin_{>0}(n, p^(i))
y^(i) = Mutate(l^(i), x)

Le point cle est que la mediane de la loi de p^(i) vaut p : le taux de mutation s'adapte en ligne, sans parametre de pas explicite, ce qui explique la robustesse sur des paysages varies. Le meilleur descendant remplace le parent s'il fait au moins aussi bien (ties en faveur du plus petit indice), et le p utilise pour le meilleur descendant devient le p courant.

Generalisation (Algorithme 2). Pour un domaine produit Omega = prod X_i avec X_i dans {0,1}, Z, R ou N, Mutate tire l positions distinctes uniformement, puis pour chaque position tire une nouvelle valeur uniformement dans le domaine, en rejetant la valeur actuelle. Sur le binaire, cela revient a retourner l bits ; sur les pixels, a remplacer des valeurs ; l'algorithme devient donc applicable aux images sans adaptation.

Hyperparametres : gamma = 0,22 (valeur reprise de Kruisselbrink et al. 2011 et Doerr et al. 2020), p initial dans {0,2, 0,8}, plusieurs tailles de population (Lognormal standard, Big, Huge, Small, XLognormal avec un p initial plus grand, OLN avec Optimism de Nevergrad pour le bruit). Les variantes d'attaque ajoutent des modificateurs fournis par Nevergrad (Smooth, SuperSmooth) et deux modificateurs propres aux attaques : G (remplacer loss(x) par loss(0,03 * sign(x)) quand la norme linf autorisee est 0,03) et SM (remplacer f par f(convolve(x)) avec un flou gaussien d'ecart-type 3/8). GSM combine les deux. Six variantes nommees algo1 a algo6, dont GSM-SuperSmoothLognormalDiscreteOnePlusOne (algo1) et GSM-BigLognormal (algo5).

Attaque du detecteur d'images fausses : detecteur universel de Ojha et al. (2023), acces boite noire, budget 10k requetes, norme linf = 0,03 pour les comparaisons principales, et grilles {0,01, 0,03, 0,05} x {1k, 10k} pour les tests de defense.

Defense. Trois classifieurs : un pour les purificateurs no-box (DiffPure, ImageRephrase, parametre 0,1 a 0,3), un pour Square Attack, un pour les mutations log-normales. Architecture SRnet (meilleure que ResNet50 dans leurs essais), entrainement sur Dataset2 (20k images, 80/10/10), test sur Dataset3 qui est distribue differemment. Metriques : FPR, FNR au seuil 0,5 et AUC, plus une restriction aux « cas critiques » : images fausses attaquees pour paraitre vraies, et images reelles non modifiees.

## 3. Protocole et metriques

Jeux de donnees (Table 3) : Dataset1 = 5k images fausses (2k Fake3, 2k Fake2, 1k LatentFake-200) pour comparer les variantes d'attaque ; Dataset2 = Dataset1 plus 5k images reelles (RealWorld500-) et leurs versions purifiees ou attaquees, soit 20k images ; Dataset3 = 1k reelles (RealWorld500+) plus 500 fausses de classes non vues plus 500 Fake1 et leurs contreparties attaquees, soit 4k images, utilise comme test hors distribution ; Dataset4 sert au test de transfert.

Benchmarks Nevergrad : 41 problemes, comparaison au « wizard » NGOpt et au rang parmi tous les algorithmes proposes.

Metriques d'attaque : taux de succes, calcule uniquement sur les images propres correctement classees, et qualite visuelle (PSNR, inspection des artefacts). Metriques de defense : FPR, FNR, AUC.

## 4. Resultats chiffres

Optimisation (section 4.2) : la mutation log-normale bat NGOpt sur 17 des 41 benchmarks et se classe devant plus de 50 % des algorithmes sur 29 benchmarks. Sur les deux benchmarks discrets, les variantes log-normales sont les meilleures (figure 1).

Attaque du detecteur (Table 4, budget 10k, linf 0,03, Dataset1) : Square Attack 100 %, algo1 91,0 %, algo2 94,1 %, algo3 64,6 %, algo4 82,0 %, algo5 99,2 %, algo6 99,1 %. Donc une methode generique sans aucun prerequis sur la structure de l'image atteint 99,2 % de succes, a 0,8 point de SA, avec moins d'artefacts horizontaux et verticaux puisque la mutation remplace des valeurs au lieu de dessiner des carres.

Defense contre les purificateurs (Tables 6 et 7) : detecteur ImageRephrase, hold-out 0,9 % FPR, 0,3 % FNR, AUC 0,99 ; sur Dataset3 complet (distribution differente), FPR 23,1 %, FNR 0,1 a 0,2 %, AUC 0,95 a 0,96 ; sur la partie critique, FPR 1,7 %, FNR 0,0 %, AUC 0,99. Detecteur DiffPure : hold-out 1,9 % / 3,9 % / 0,99 ; Dataset3 complet 23,0 % FPR, 3,7 a 4,2 % FNR, AUC 0,87 a 0,88 ; partie critique 2,2 % FPR, 3,0 % FNR a 0,1.

Le FPR de 23 % sur le jeu complet s'explique, selon les auteurs, par un transfert involontaire : le classifieur apprend aussi a reconnaitre des images generees, donc il flague des images de generateurs non vus. C'est un exemple concret de biais de dataset.

Defense contre Square Attack (Table 8) : hold-out 1,8 % FPR, 0,5 % FNR, AUC 0,99 ; sur Dataset3-SA, quel que soit le budget et l'amplitude, FPR 0,8 %, FNR 0,0 a 0,9 %, AUC 0,99. Mais le transfert vers les attaques log-normales est catastrophique : FNR 79,5 % sur Dataset4. Autrement dit, un detecteur de SA ne voit pas les mutations log-normales.

Defense contre log-normal (Table 9) : entraine uniquement sur algo1, hold-out 0,7 % FPR, 2,1 % FNR, AUC 0,99 ; sur Dataset3-LN avec algo1 a differentes amplitudes, FPR 4,1 %, FNR 2,3 a 5,4 %, AUC 0,98 a 0,99. Surtout, le detecteur generalise aux variantes non vues : algo2 4,1 % FNR, algo3 11,7 % (la variante la plus faible en attaque), algo4 1,6 %, algo5 0,4 %, toutes avec FPR 4,1 % et AUC 0,95 a 0,99. C'est le resultat le plus utile : la famille d'attaque est apprise, pas l'instance.

## 5. Ce qui manque

Le lien avec le watermarking est affirme mais jamais mesure. Les auteurs citent les travaux de Fernandez sur la robustesse des filigranes et la purification, sans attaquer un filigrane reel. Or la question « combien de requetes pour casser un watermarking d'image » est ouverte et c'est celle qui interesse un hackathon.

Le detecteur universel de Ojha est un modele de 2023, deja ancien a la publication ; rien sur les detecteurs recents, ni sur les detecteurs de diffusion, qui sont la cible actuelle.

La defense est entrainee et testee sur des distributions d'images qui se recouvrent partiellement (Dataset2 et Dataset3 partagent RealWorld500 et Fake1/Fake3). Le FPR de 23 % sur le jeu complet montre justement que le protocole n'est pas propre, et les auteurs ne proposent pas de correction.

Budget d'attaque petit (10k requetes) et amplitude linf 0,03 visible ; rien sur le regime a 100 ou 1000 requetes, qui est celui d'une API de detection reelle.

Enfin, aucun cout de calcul pour la defense : un classifieur SRnet par famille d'attaque, cela fait trois reseaux a entrainer et a maintenir, et rien n'est dit sur la possibilite d'un detecteur unique multi-attaques.

## 6. Usage concret en hackathon 24 h

C'est le papier ideal pour la partie offensive d'un hackathon watermarking, parce que l'algorithme tient en 20 lignes et ne demande aucun gradient. En 24 h : implementer la mutation log-normale generalisee, attaquer un detecteur de watermarking (ou un detecteur d'images generees) avec un budget de 1k puis 10k requetes, et tracer le taux de succes contre le PSNR. La comparaison a Square Attack est directe et le resultat est deja connu (99,2 % contre 100 %), donc l'interet est de le refaire sur une cible differente.

Deuxieme usage : la defense. Entrainer un petit SRnet a separer images attaquees et images propres, puis tester le transfert entre familles d'attaques. Le resultat du tableau 8 (FNR 79,5 % en transfert) est un point de depart spectaculaire : un detecteur d'attaques specialise ne voit rien d'autre, et le montrer sur un jeu maison prend une demi-journee.

Troisieme usage, en lien avec l'indexation active : utiliser les mutations comme test de robustesse d'un index de detection de copies, en mesurant combien de mutations font sortir une image de son bucket. C'est une experience que ni ce papier ni celui sur l'indexation active ne fait, et qui tient dans les 24 h.
