# Watermarking across modalities, these de Pierre Fernandez (arXiv 2502.05215)

« Watermarking across Modalities for Content Tracing and Generative AI », these de doctorat, janvier 2025, Centre Inria de l'Universite de Rennes et Meta FAIR Paris. Texte integral lu : version HTML arXiv tronquee au chapitre 3, puis PDF complet (91 951 mots extraits, 55 Mo). Les contributions watermark et la taxonomie des modalites sont traitees ici, la bibliographie est laissee de cote.

## 1. Probleme et revendications

Le watermarking est traite par communaute, avec des metriques et des modeles de menace incompatibles : bit accuracy pour les images, IoU pour l'audio, p-value pour le texte, temps d'extraction pour les poids. Un regulateur qui veut tracer du contenu n'a aucune base commune. La these revendique une lecture unifiee, non pas une methode unique mais un cadre : le watermarking comme systeme de communication (cover, embedder, canal bruite, detecteur), decline par modalite.

Trois revendications, chacune adossee a des papiers publies : (i) un watermarking « actif » des images en circulation, indexation active pour la detection de copies (chapitre 5) et filigrane dans l'espace latent auto-supervise (chapitre 4) ; (ii) un watermarking des modeles generatifs, dans le decodeur de diffusion (chapitre 6, Stable Signature) et dans la forme d'onde pour la voix (chapitre 7, AudioSeal) ; (iii) un watermarking des LLM et des poids, avec des tests statistiques corrects (chapitre 8), la notion de « radioactivite » (chapitre 9) et des invariants fonctionnels dans les poids des Transformers (chapitre 10).

La these defend aussi une position de fond, en conclusion : le watermarking ne protege pas contre un adversaire determine, il « garde les honnetes gens honnetes ». Les vrais problemes sont la gouvernance et l'interoperabilite, pas la robustesse.

## 2. Methode, equations, hyperparametres

La these se lit comme une taxonomie a quatre axes.

Axe 1, le domaine d'insertion. Pixel, espace latent auto-supervise (chapitre 4 : on modifie l'image pour que sa representation SSL porte la marque), latent d'un index de recherche (chapitre 5 : descente de gradient vers q(x_o), avec attenuation JND), poids du decodeur de diffusion (chapitre 6 : message de 48 bits dans la representation des images generees), forme d'onde (chapitre 7 : residu additif, perte de localisation et perte de sonie inspiree du masquage auditif), distribution de tokens (chapitre 8 : biais sur le logit selon un hash des tokens precedents), et poids du Transformer (chapitre 10 : permutation, scaling, matrices inversibles dans QK).

Axe 2, la nature du message. Zero-bit (AudioSeal, indexation active), multi-bit (16 bits chez AudioSeal, 48 bits chez Stable Signature, jusqu'a 160 octets chez les invariants), et identification d'un modele parmi N par distance de Hamming.

Axe 3, le modele de menace. Boite blanche, boite noire (API), et « no-box » (purification sans connaissance du systeme, du type DiffPure, traitee au chapitre 5 et dans le papier log-normal de la meme equipe). L'efficacite d'une attaque croit avec la connaissance de l'attaquant, et la seule defense tenable est de garder le detecteur secret, pas l'algorithme.

Axe 4, la statistique de detection. Seuil empirique (images, audio), p-value exacte (chapitre 8 : calibration Lugannani-Rice, detection par maximum sur fenetres pour les tests multiples, extension multi-bit), test non asymptotique sur les poids (chapitre 10, fonction beta incomplete regularisee), et test sur modele entier (chapitre 9 : rejet de H0 « B n'a pas ete entraine sur les sorties de A »).

Elements techniques precis, tels que donnes. Chapitre 9 : la radioactivite se definit par un seuil alpha sur la p-value ; alpha = 10^-6 signifie une chance sur un million d'observer un resultat aussi extreme si le modele n'a pas ete entraine sur les donnees d'Alice. Le test corrige le fait que les p-values theoriques s'effondrent quand on les calcule naivement sur environ 1M de tokens. Chapitre 10 : k = 8 choix par bloc et par invariant, 2 octets par couche pour permutation et scaling, 1 octet pour QK, 160 octets au total sur un 7B.

## 3. Protocole et metriques

Chaque chapitre a son protocole, et c'est precisement ce que la these met en evidence.

Images en circulation (chapitres 4 et 5) : DISC21, 1M images de reference, 10k requetes transformees ; metriques R@1, muAP, PSNR, SSIM ; detection de copies au protocole de l'Image Similarity Challenge (10 voisins, seuil, precision, rappel).

Images generees (chapitre 6) : prompts COCO et ImageNet, 10 modeles fine-tunes avec des messages differents, bit accuracy sur 1k images par modele, FID entre generateur original et filigrane, robustesse au recadrage, au redimensionnement et au JPEG 50, plus inpainting et super-resolution.

Audio (chapitre 7) : 10k positifs et 10k negatifs de 10 s, accuracy au meilleur seuil avec TPR et FPR, AUC ; localisation par IoU et accuracy par echantillon ; attribution sur 100 messages de 16 bits et 100k audios ; qualite par PESQ, STOI, ViSQOL et MUSHRA.

Texte (chapitres 8 et 9) : p-value et FPR theoriques contre empiriques, detection sur textes courts, et pour la radioactivite, comparaison a l'inference d'appartenance et aux methodes de protection de propriete intellectuelle.

Poids (chapitre 10) : LLaMA 7B, 13B, 30B ; byte accuracy apres bruit gaussien, quantification 3 bits, elagage 50 %, fine-tuning ; distorsion en proportion de tokens predits differents.

## 4. Resultats chiffres

Chapitre 5 (indexation active) : jusqu'a +60 points de R@1 sur des changements forts de luminosite et de contraste, muAP multiplie par 2, et par 3 a PSNR 30 dB ; l'index approximatif est 500 fois plus rapide et 256 fois plus compact que la recherche exhaustive. Le chapitre 11 resume : le watermarking atteint environ 8 fois le rappel du fingerprinting apres des recadrages qui conservent 50 % de l'image.

Table 5.7, comparaison directe (R@1 moyen sur transformations) : indexation active 0,75, HiDDeN 0,48, indexation passive 0,45, SSL watermarking 0,42. Le message est que le watermarking n'est pas le bon outil pour retrouver une image dans une base, et l'auteur ajoute une limite mesuree : avec 64 bits de message, le taux d'erreur binaire explose, donc pas de correction d'erreur possible a ce budget.

Chapitre 6 (Stable Signature) : message de 48 bits, bit accuracy le plus souvent au-dessus de 0,9 selon les taches et transformations (tableau 6.1), FID non degrade de facon significative, robustesse superieure aux methodes post-hoc sur images generees.

Chapitre 7 (AudioSeal) : detection moyenne sur 14 editions a 0,96 d'accuracy et 0,97 d'AUC, contre 0,85 et 0,84 pour WavMark ; localisation IoU 0,99 contre 0,35 quand une seconde de parole est generee ; detection 485 fois plus rapide que WavMark quand il n'y a pas de filigrane.

Chapitre 9 (radioactivite) : avec rho = 5 % de texte filigrane dans les donnees de fine-tuning, la detection atteint p < 10^-5 des que le degre de supervision d depasse 2 %, la ou l'inference d'appartenance devient inoperante ; en modele ouvert supervise, cette derniere atteint alpha = 10^-30, mais elle s'effondre en non supervise, alors que le watermark tient.

Chapitre 10 (invariants) : 160 octets sur un 7B, byte accuracy de 100 % apres quantification 3 bits, elagage 50 % et fine-tuning pour QK et scaling ; 51,4 a 60,8 % avec extraction accelere pour permutation et combinaison ; p-values sous 10^-60 ; distorsion sous 1,8 % des tokens predits.

Chapitre 11 (synthese) : a taux de vrais positifs egal, le watermarking atteint une FPR 10 millions de fois plus faible que la forensique sur des images recadrees, redimensionnees et compressees, ce qui rend la validation empirique insuffisante a l'echelle de millions de contenus.

## 5. Ce qui manque

Trois manques genent pour un usage hackathon.

Pas d'evaluation inter-modale de bout en bout. La seule comparaison directe est celle de la section 5.8, et elle oppose deux methodes d'image. Aucune experience ne fait traverser un meme identifiant par image, audio et texte, ni ne mesure ce que devient un filigrane lors d'une conversion de modalite (image decrite en texte puis regeneree), qui est le scenario des pipelines generatifs actuels.

Pas de banc d'attaque commun. Les attaques sont traitees par chapitre (purification, adversarial, paraphrase, fine-tuning) sans suite unifiee, alors que la these cite le papier log-normal de la meme equipe, qui fournit une famille d'attaques boite noire generique.

Gouvernance annoncee comme le vrai enjeu (section 11.2.2) mais traitee qualitativement. Rien de chiffre sur la gestion des cles, la revocation, l'interoperabilite entre fournisseurs, ni le cout de deploiement, qui est pourtant la partie la plus utile a un regulateur.

Enfin, les chapitres 4 a 9 protegent des contenus, le chapitre 10 protege des modeles, et le lien entre les deux n'est jamais instrumente de bout en bout.

## 6. Usage concret en hackathon 24 h

Cette these est la carte du terrain, pas une brique a executer. Trois usages.

Choisir la bonne metrique et le bon test. Attaquer du texte sans le chapitre 8 (p-value calibree, detection par fenetre) conduit a une FPR theorique fausse, erreur la plus frequente dans les projets de watermarking LLM. Attaquer de l'audio demande le protocole du chapitre 7 (TPR a FPR fixe, IoU), qui tient en une page.

Cadrer le pitch. La phrase du chapitre 11 (8 fois le rappel du fingerprinting apres recadrage, FPR 10 millions de fois plus faible que la forensique) est un argument de 30 secondes, chiffre et source, face a un jury qui demande « pourquoi pas un classifieur ».

Trouver un sujet neuf. Les trois manques ci-dessus sont trois sujets : identifiant unique traversant les modalites, suite d'attaques unifiee, prototype de gestion de cles et de revocation. Le dernier est le moins technique et le plus presentable a un jury de politique publique.
