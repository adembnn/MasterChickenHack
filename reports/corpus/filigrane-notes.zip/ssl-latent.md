# Watermarking Images in Self-Supervised Latent Spaces (arXiv 2112.09581v2, ICASSP 2022)

## 1. Problème et revendications

Le watermarking par réseau pré-entraîné consiste à ne pas entraîner d'encodeur/décodeur dédié, mais à réutiliser un réseau existant comme espace d'insertion. On optimise alors directement les pixels pour que la caractéristique extraite par le réseau tombe dans une région secrète. Vukotić et coll. avaient montré la voie avec un ResNet-50 entraîné en classification supervisée. Les auteurs (Pierre Fernandez, Alexandre Sablayrolles, Teddy Furon, Hervé Jégou, Matthijs Douze, Meta AI et Inria) font deux constats qui motivent leur papier.

Premier constat : un réseau entraîné en supervision explicite jette l'information non nécessaire à la classification. Les caractéristiques sont donc sémantiquement appauvries, et surtout peu adaptées à l'insertion. Second constat : l'auto-supervision entraîne explicitement l'invariance aux augmentations (recadrage, couleur, flou), exactement la propriété recherchée par un watermark. Les auteurs choisissent DINO, justifié par sa vitesse d'entraînement et ses performances en recherche d'images.

Les revendications sont au nombre de trois. (i) Un algorithme qui encode un marqueur zero-bit ou un message binaire dans l'espace latent de n'importe quel réseau pré-entraîné, sans entraîner d'architecture dédiée. (ii) L'utilisation d'augmentations au moment du marquage, ce qui rend le watermark robuste sans réentraîner le réseau. (iii) La démonstration expérimentale que l'auto-supervision produit de meilleurs espaces d'insertion que la supervision, avec un gain net sur les rotations, les recadrages et le flou gaussien.

Le papier revendique aussi un avantage de correction mathématique sur HiDDeN et ses successeurs : le décodeur y est un simple signe de projection, et le taux de faux positifs est calculable analytiquement, alors qu'un décodeur entraîné n'offre aucune garantie sur la distribution de ses bits.

## 2. Méthode, équations, hyperparamètres réellement donnés

On note $\mathcal{I}$ l'espace des images et $\mathcal{F} = \mathbb{R}^d$ l'espace des caractéristiques, avec $\varphi : \mathcal{I} \to \mathcal{F}$ l'extracteur. Le cahier des charges est double : les transformations géométriques et photométriques doivent peu modifier $\varphi(I)$, et il doit être possible de modifier $\varphi(I)$ par une perturbation invisible.

Le backbone est un ResNet-50, caractéristiques prises à la dernière couche convolutionnelle, $d = 2048$. Il est entraîné sur ILSVRC2012 sans étiquettes, 200 epochs de DINO avec les paramètres par défaut, en ajoutant l'augmentation rotation. Une couche de blanchiment PCA, apprise sur 100 000 images distinctes de YFCC (ou de COCO selon le jeu d'évaluation), recentre les vecteurs et leur donne une covariance unité. Cette couche est présentée comme essentielle : sans elle, les caractéristiques DINO ne sont pas uniformément réparties sur l'hypersphère et la région d'insertion est mal conditionnée.

Zero-bit. À partir d'une clé secrète $a \in \mathcal{F}$ de norme 1, la région de détection est le hypercône dual
$$\mathcal{D} := \{ x \in \mathbb{R}^d : |x^\top a| > \|x\| \cos(\theta) \}.$$
Le taux de faux positifs s'en déduit exactement, pour une clé uniformément distribuée :
$$FPR = P(\varphi(I) \in \mathcal{D}) = 1 - I_{\cos^2(\theta)}\left(\frac{d-1}{2}, \frac{1}{2}\right),$$
où $I$ est la fonction bêta incomplète régularisée. C'est cette formule qui fait la différence avec un décodeur entraîné : le FPR est une fonction déterministe de l'angle et de la dimension, pas une estimation empirique. Le meilleur marquage maximise, sous contrainte de distorsion,
$$-L_w(x) = (x^\top a)^2 - \|x\|^2 \cos^2(\theta),$$
quantité négative hors de $\mathcal{D}$, positive dedans. Les auteurs rappellent que Cox et coll. appelaient cela l'estimation de robustesse.

Multi-bit. Le message est $m = (m_1,\dots,m_k) \in \{-1,1\}^k$. La clé est une famille orthogonale de porteuses $a_1,\dots,a_k \in \mathbb{R}^d$, et le décodeur est
$$D(I) = \left[ \mathrm{sign}(\varphi(I)^\top a_1), \dots, \mathrm{sign}(\varphi(I)^\top a_k) \right].$$
La perte devient une perte charnière avec marge $\mu \geq 0$ :
$$L_w(x) = \frac{1}{k} \sum_{i=1}^{k} \max\left(0, \mu - (x^\top a_i) \cdot m_i\right).$$
Le marquage est une optimisation sur les pixels :
$$I_w := \arg\min_{I \in \mathcal{C}(I_o)} \mathbb{E}_{t \sim \mathcal{T}} \left[ \lambda L_w(\varphi(\mathrm{Tr}(I,t))) + L_i(I, I_o) \right],$$
où $\mathcal{C}(I_o)$ est l'ensemble des images admissibles. Cet ensemble est défini par deux normalisations appliquées au résidu $\delta = I - I_o$ : une atténuation par carte de saillance SSIM, qui concentre la modification dans les zones texturées, puis un recadrage du PSNR si la cible est dépassée. La carte SSIM est calculée avec $C_1 = 0.01^2$, $C_2 = 0.03^2$, sur des tuiles $17 \times 17$ par canal, sommées puis bornées à zéro.

L'algorithme 1 est explicite : à chaque itération, on impose les contraintes, on tire une transformation $t$, on applique $\mathrm{Tr}$, on calcule la caractéristique, la perte, puis on met à jour l'image par Adam. Paramètres donnés : learning rate 0,01, 100 itérations de descente, $\lambda = 1$ en zero-bit et $\lambda = 5 \cdot 10^4$ en multi-bit, marge $\mu = 5$. Le résultat est arrondi après la dernière itération.

La distribution des transformations est détaillée, ce qui est rare et directement réutilisable. Cinq familles : identité, rotation, flou, recadrage, redimensionnement. L'angle de rotation suit une loi de von Mises de moyenne 0 et concentration $\kappa = 1$, divisée par 2, ce qui donne des angles dans $\pi/2 \times [-1,1]$ avec plus de masse près de zéro. Les échelles de recadrage et de redimensionnement sont uniformes dans $[0.2, 1.0]$ ; le rapport d'aspect du recadrage est tiré entre $3/4$ et $4/3$. Le noyau de flou $b$ est un entier impair entre 1 et 15, avec $\sigma = 0.15b + 0.35$. Un flip horizontal est appliqué avec probabilité 0,5.

## 3. Protocole et métriques

Trois jeux : 1 000 images YFCC100M choisies pour la variété de contenu, 118 images CLIC professionnelles haute résolution, et 1 000 images MS-COCO pour la comparaison avec HiDDeN et Dist. Agnostic. Le protocole zero-bit est fixé à PSNR 40 dB et FPR $10^{-6}$, sauf pour la comparaison à Vukotić et coll. sur CLIC où le FPR est $10^{-3}$ et le PSNR au moins 42 dB, comme dans leur papier. Le protocole multi-bit est de 30 bits à PSNR 40 dB, avec BER et WER (taux d'erreur par mot) comme métriques. La comparaison au tableau 3 se fait dans le protocole des concurrents : 30 bits, PSNR 33 dB, COCO redimensionné à $128 \times 128$.

Contrôle de faux positifs : détection sur 100 000 images naturelles de YFCC, aucune déclarée marquée, et une seule fausse détection sur les 1 281 167 images d'ImageNet. C'est un point à retenir pour un concours : le FPR annoncé est vérifié à grande échelle.

## 4. Résultats chiffrés

Zero-bit, tableau 1, TPR à FPR $10^{-6}$. Sur YFCC, avec SSL (DINO) contre ResNet-50 supervisé : identité 1,00 contre 1,00 ; rotation 25° 0,97 contre 0,54 ; recadrage 0,5 0,95 contre 0,79 ; recadrage 0,1 0,39 contre 0,06 ; redimensionnement 0,7 0,99 contre 0,85 ; flou 2,0 0,99 contre 0,04 ; JPEG 50 0,81 contre 0,20 ; luminosité 2,0 0,94 contre 0,71 ; contraste 2,0 0,96 contre 0,65 ; teinte 0,25 1,00 contre 0,46 ; mème 0,99 contre 0,94 ; capture d'écran 0,76 contre 0,18. Le gain de l'auto-supervision est donc massif sur le flou et les rotations, et net sur les recadrages agressifs.

Sur CLIC, toujours au tableau 1, la méthode atteint 1,00 en identité, rotation 25°, recadrage 0,5 et redimensionnement 0,7 ; 0,98 en recadrage 0,1 ; 0,97 en JPEG 50 ; 1,00 en contraste et en teinte ; 0,97 en capture d'écran. La comparaison directe avec l'implémentation de Vukotić et coll. donne, pour cette dernière, environ 0,3 en rotation et 0,0 en recadrage 0,1. L'écart est attribué à la fois à DINO et aux augmentations au marquage.

Multi-bit, tableau 2, 30 bits à PSNR 40 dB sur YFCC. BER et WER en pourcentage : identité 0,1 et 0,7 ; rotation 25° 3,3 et 43,4 ; recadrage 0,5 4,8 et 58,3 ; recadrage 0,1 28,9 et 100 ; redimensionnement 0,7 2,1 et 29,1 ; flou 2,0 0,5 et 4,6 ; JPEG 50 20,8 et 98,9 ; luminosité 2,0 8,7 et 60,7 ; contraste 2,0 8,4 et 62,6 ; teinte 0,2 2,5 et 31,6 ; mème 6,4 et 75,9 ; capture d'écran 23,9 et 100. Le WER est nettement meilleur que ce que prédirait le BER seul, ce que les auteurs expliquent par l'hétérogénéité des images : certaines sont faciles à marquer, d'autres non, et le WER agrégé n'est pas $1-(1-BER)^k$.

Comparaison au tableau 3, COCO $128 \times 128$, 30 bits à 33 dB, BER : identité 0,00 ; JPEG 0,04 ; flou 0,00 ; recadrage 0,18 ; redimensionnement 0,00 ; teinte 0,03. HiDDeN donne 0,00, 0,23, 0,01, 0,00, 0,15, 0,29 et Dist. Agnostic 0,00, 0,18, 0,07, 0,02, 0,12, 0,06. La méthode est donc au niveau de l'état de l'art, sauf sur le recadrage central où elle échoue.

Ablation. La figure 3 montre que l'augmentation rotation est nécessaire à la fois au pré-entraînement DINO et au marquage pour obtenir une bonne robustesse aux rotations. Les images peu texturées sont plus difficiles à marquer, conséquence directe de la normalisation SSIM.

## 5. Ce qui manque

Il n'y a pas d'encodeur ni de décodeur entraîné : le marquage est une optimisation par image, 100 itérations d'Adam sur les pixels. C'est lent et coûteux à l'échelle, et cela interdit tout usage au moment de la génération. Le recadrage à 10 % reste un point faible en multi-bit (BER 28,9 %, WER 100 %), et le papier reconnaît que le recadrage central est le seul cas où la méthode perd face à HiDDeN. La capacité étudiée est de 30 bits, sans montée en charge. Il n'y a ni localisation, ni messages multiples, ni robustesse aux attaques adverses ciblées. Enfin, le blanchiment PCA dépend du jeu d'images utilisé pour l'apprendre, ce qui pose une question de reproductibilité entre domaines.

## 6. Usage concret en hackathon 24 h

C'est le papier le plus directement recyclable pour une épreuve de perturbation minimale, parce que son algorithme 1 est déjà une boucle d'optimisation sous contrainte de PSNR et de SSIM, avec un pas Adam et une augmentation aléatoire à chaque itération. Il suffit de remplacer la perte $L_w$ par la perte du détecteur à trois classes visé : le reste (contraintes, SSIM, arrondi) fonctionne tel quel.

Deuxième usage : la formule du FPR en hypercône donne une calibration analytique. Si le détecteur adverse est de ce type, on peut calculer exactement la probabilité de fausse détection en fonction de l'angle, donc choisir la perturbation qui maximise le taux d'erreur sans sortir du budget perceptuel.

Troisième usage : la distribution des transformations est un générateur d'attaques prêt à l'emploi, avec les paramètres exacts (von Mises pour la rotation, uniforme 0,2 à 1 pour les échelles, flou impair 1 à 15 avec $\sigma = 0.15b+0.35$). En une heure, on produit un jeu d'images transformées qui teste la robustesse de n'importe quel détecteur, ce qui est souvent l'étape qui manque dans un prototype de 24 h.
