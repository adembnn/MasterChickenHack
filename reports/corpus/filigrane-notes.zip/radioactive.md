# Radioactivité : quand un watermark contamine tout ce qui l'a lu

Note de lecture de arXiv:2402.14904v2, « Watermarking Makes Language Models Radioactive », Tom Sander, Pierre Fernandez, Alain Durmus, Matthijs Douze, Teddy Furon (Meta FAIR, Inria), NeurIPS 2024.

## 1. Problème et revendications

Le watermarking de texte est habituellement présenté comme un détecteur de contenu généré : on observe un texte, on calcule une p-value, on conclut. Le papier déplace la question. Ce qui l'intéresse, c'est ce que le watermark fait au modèle qui apprend sur des textes watermarkés. Si Alice watermarke ses sorties et que Bob fine-tune son modèle sur ces sorties, alors le modèle de Bob devient lui-même détectable comme ayant été exposé au watermark d'Alice. Les auteurs appellent ce phénomène la radioactivité.

La revendication est plus forte qu'une analogie. Ils formalisent la radioactivité d'un jeu de données et celle d'un modèle, construisent des détecteurs pour quatre combinaisons d'accès (modèle ouvert ou fermé, supervision ou non), prouvent la validité des tests sous H0, et mesurent la puissance de détection. Résultat principal : avec accès aux logits, une contamination de 1 % suffit à obtenir une p-value inférieure à 10⁻³⁰, alors que les attaques par inférence d'appartenance échouent dans le même régime.

## 2. Méthode

Alice possède un modèle A exposé par API, Bob un modèle B. Alice soupçonne Bob d'avoir fine-tuné B sur des sorties de A. On note D le jeu de fine-tuning, D_A la partie issue de A, et ρ = |D_A| / |D|. La supervision est le degré de connaissance d'Alice : d = |D_A| / |D̃_A|, où D̃_A est l'ensemble des sorties de A qu'Alice a conservées parce que Bob les a demandées.

Définition 1 : un jeu de données D est α-radioactif pour un test T si « B n'a pas été entraîné sur D » est inclus dans H0 et si T rejette H0 au seuil α. Définition 2 : le modèle A est α-radioactif si « B n'a pas été entraîné sur des sorties de A » est inclus dans H0 et si T rejette H0 au seuil α. Un α de 10⁻⁶ signifie une chance sur un million d'observer un score aussi extrême si Bob n'a rien utilisé.

Le détecteur détourne le test de watermark : au lieu de scorer les tokens observés dans un texte, on score les tokens prédits par B. En mode lecture, on passe à B un texte watermarké produit par A et on score sa prédiction du token suivant à chaque position, en utilisant les tokens du texte comme fenêtre.

Pour Kirchenbauer, la statistique est la proportion de prédictions dans la liste verte : S = (1/|U|) Σ_{t∈U} 1[h(ŷ_t, y_{t−k:t−1}, s) < γ], où ŷ_t = argmax P_θ(v | y_<t) et U est l'ensemble des positions retenues après déduplication. Sous H0, le nombre de prédictions vertes suit une binomiale B(|U|, γ), et la p-value s'obtient par la fonction bêta incomplète régularisée I_γ(t + 1, N − t).

Le point technique décisif est la déduplication, énoncée en proposition 1. Le résultat ne tient que si les tuples (x_i) sont deux à deux distincts et si le token courant n'apparaît pas dans le contexte. La seconde condition est nouvelle par rapport à la détection classique, parce qu'ici le prompt est souvent lui-même watermarké. Sans cela, le modèle recopie des tokens verts présents dans son contexte, ce qui produit de faux positifs massifs.

Le filtre φ, utilisé en modèle fermé, restreint le scoring aux k-grams qui peuvent réellement être contaminés, c'est-à-dire présents dans les données d'Alice. En supervisé, φ est l'ensemble des k-grams de D̃_A ; en non supervisé, celui des k-grams de 100 000 nouvelles instructions watermarkées générées par A.

## 3. Protocole expérimental

Les instructions sont générées par A = Llama-2-chat-7B avec Self-Instruct : une instruction, trois exemples, puis 20 paires instruction-réponse. Le watermark est celui de Kirchenbauer avec δ = 3,0, γ = 0,25, k = 2, nucleus p = 0,95 et T = 0,8. Après suppression des réponses inachevées et des quasi-doublons, on obtient 100 000 paires, soit environ 14 millions de tokens. Six jeux mixtes sont construits avec ρ dans {0, 1, 5, 10, 50, 100} %, le reste étant non watermarké, à volume total constant.

B = Llama-1-7B est fine-tuné avec AdamW, 3 000 pas, batch de 8, learning rate 10⁻⁵, contexte de 2 048 tokens, soit environ 3 époques, schedule cosinus et 100 pas de warmup. Le modèle de base diffère de A pour éviter les biais d'un modèle qui aurait déjà vu les mêmes données.

En modèle ouvert, la détection score N = 225 000 tokens. En modèle fermé, elle score N = 600 000 tokens après filtrage et déduplication sur environ 1,5 million de tokens générés, soit environ 10⁴ requêtes si l'on suppose une réponse de 100 tokens.

Les ablations portent sur le taux d'apprentissage, le nombre d'époques, le type d'adaptation (full fine-tuning contre Q-LoRA), la taille du modèle (7B contre 13B), la taille de fenêtre k, la langue des données et une seconde passe de fine-tuning dite de purification.

## 4. Résultats chiffrés

La qualité du fine-tuning n'est pas affectée (tableau 2). Sans watermark, B obtient 5,0 sur Natural Questions, 33,6 sur TriviaQA, 11,8 sur GSM8K, 12,8 sur HumanEval, 15,8 en moyenne et 33,6 sur MMLU. Avec 100 % de données watermarkées : 5,6, 36,4, 11,1, 9,8, 15,7 et 31,0. Le modèle de base non fine-tuné est à 3,2, 36,2, 10,5, 12,8, 15,7 et 28,4. Les écarts sont dans le bruit, sauf HumanEval qui perd 3 points.

En supervisé, la radioactivité est détectée avec p < 10⁻³⁰ en modèle ouvert et p < 10⁻¹⁰ en modèle fermé, dès 1 % de données watermarkées. En non supervisé avec modèle ouvert, le test reste sous 10⁻⁵ tant que la proportion ne dépasse pas 5 %. En modèle fermé non supervisé, il faut monter à 10 % pour passer sous 10⁻⁵ (figure 5). C'est la limite pratique : sans les logits, il faut beaucoup de données contaminées ou beaucoup de requêtes.

L'effet du degré de supervision est mesuré à ρ = 5 % en modèle ouvert (tableau 3). À d = 0,1 %, le logarithme décimal de la p-value vaut -5,8 ± 1,8 ; à d = 1 %, -6,5 ± 0,9 ; à d = 5 %, -16,0 ± 2,6 ; à d = 10 %, moins de -30. Même une supervision très faible suffit.

La validité sous H0 est le résultat le plus important pour un déployeur (tableau 4). Quand B n'a jamais vu de données watermarkées, la p-value moyenne doit valoir 0,5. Avec déduplication, on obtient 0,46 ± 0,27 en modèle ouvert et 0,42 ± 0,30 en modèle fermé, ce qui est conforme. Sans déduplication : 0,053 ± 0,12 en ouvert et moins de 10⁻³⁰ en fermé. Une p-value de 10⁻³⁰ sur un modèle innocent est une fausse accusation catastrophique, que la déduplication supprime.

Le filtre apporte un gain mesurable en modèle fermé (figure 6). À ρ = 1 % en supervisé, après 75 000 tokens scorés, le logarithme de la p-value vaut -12 avec filtre contre -8 sans.

La taille de fenêtre est déterminante (tableau 5, N = 30k, ρ = 100 %, modèle fermé). Pour Kirchenbauer, la détection du watermark d'origine vaut -8,6 à k = 1, -6,4 à k = 2 et -6,7 à k = 4, tandis que la radioactivité vaut -43,7, -10,2 et -1,4. Pour Aaronson : -7,7, -7,6, -7,1 puis -47,2, -18,4, -2,8. Une fenêtre courte rend le watermark plus radioactif : les tuples se répètent davantage dans les données, donc sont plus mémorisés, et le nombre de fenêtres possibles |V|^k croît avec k alors que le nombre de tokens watermarkés est fixé.

L'intensité du fine-tuning compte aussi (tableau 6, N = 10k). Le learning rate 10⁻⁵ donne -32,4, 5 × 10⁻⁵ donne -49,6, 10⁻⁴ donne -58,0. Une époque donne -20,8, deux -29,2, trois -33,2, quatre -34,8. Le full fine-tuning donne -32,4 contre -11,0 pour Q-LoRA : un adaptateur léger laisse beaucoup moins de traces. La taille 13B donne -33,2 contre -32,4 pour 7B, donc la taille ne change pas grand-chose ici.

La langue des données compte énormément (tableau 7, 250k k-grams, modèle fermé). L'anglais donne moins de -50, le français -7,8, l'espagnol -5,7, l'allemand -4,0, le catalan -2,1. Un test sur une langue qui partage peu de k-grams avec les données d'entraînement perd l'essentiel de sa puissance. La parade est la méthode de Fisher : combiner les p-values par langue donne moins de 10⁻⁵⁰, ce qui permet de rejeter H0 sans connaître la distribution exacte des données de Bob.

La purification ne marche qu'à moitié. Après un second fine-tuning sur OASST1, la p-value passe de -15 à -8 (tableau 8). Le signal est divisé par deux en échelle logarithmique, donc très affaibli, mais pas effacé.

Enfin, la comparaison avec l'inférence d'appartenance est sans appel (annexe E.1). Les MIA ne fonctionnent qu'en supervisé avec accès ouvert et échouent en non supervisé, alors que le test de radioactivité fonctionne dans les quatre cas.

## 5. Ce que le papier ne donne pas

Le résultat « 1 % suffit » vaut pour un accès aux logits et un fine-tuning complet. En modèle fermé non supervisé, il faut 10 % de données contaminées et environ 10⁴ requêtes. Les auteurs notent qu'il faut interroger le modèle environ 1 000 fois, ce qui peut être bloquant face à un fournisseur qui limite le débit.

Pas de garantie sur des schémas autres que Kirchenbauer et Aaronson. WaterMax est explicitement exclu par le papier compagnon sur le rephrasage, parce que son biais de sélection produit de fausses radioactivités. Les watermarkers sémantiques ne sont pas testés.

Pas d'évaluation sur des modèles de production : les expériences portent sur des LLaMA de 7B et 13B, fine-tunés sur 14 millions de tokens. On ne sait pas ce que devient le signal après un pré-entraînement massif, un mélange à faible proportion, ou un entraînement avec decay. Pas de traitement du cas où plusieurs propriétaires watermarkent des données qui se mélangent. Pas de coût de détection en dollars, seulement une empreinte globale : environ 1 000 jours GPU, soit 25 000 heures GPU, pour 2 tonnes de CO2 équivalent.

## 6. Usage concret en hackathon 24 h

Le protocole de détection est directement réimplémentable : forward pass sur un texte watermarké, score des tokens prédits, déduplication des fenêtres, test binomial. C'est le squelette d'un détecteur de contamination de benchmark, et il tient en une centaine de lignes.

Le chiffre à retenir pour un jury est celui du tableau 4 : sans déduplication, un modèle innocent obtient une p-value de 10⁻³⁰, donc le test n'a aucune valeur. Avec déduplication, la distribution sous H0 redevient uniforme. C'est le genre de détail qui sépare une démo qui impressionne d'une démo qui se fait démolir en question.
