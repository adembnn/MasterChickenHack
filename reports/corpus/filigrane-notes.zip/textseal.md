# TextSeal: un watermark localisé pour la provenance et la protection contre la distillation

Papier arXiv 2605.12456, Meta FAIR (Tom Sander, Pierre Fernandez et al.). Code annoncé : github.com/facebookresearch/textseal.

## 1. Problème posé et revendications

Le papier part d'un constat de déploiement : un filigrane de texte doit marquer les sorties d'un LLM sans dégrader la qualité, sans tuer la diversité des réponses, sans ajouter de latence, et sans casser les optimisations de serving comme le décodage spéculatif. La famille "distortion-free" (Gumbel-max, SynthID-Text, Permute-and-Flip, DiPMark) préserve en espérance la distribution du modèle, mais Gumbel-max est déterministe : à prompt et clé fixés, la sortie est toujours identique, ce qui provoque des boucles dégénérées quand un n-gramme se répète et que le PRF retombe sur le même token.

TextSeal revendique trois apports : un routage à deux clés qui restaure la diversité sans trop perdre en détection, une détection pondérée par l'entropie avec des p-values calibrées, et une détection localisée multi-régions qui résiste à la dilution dans un document majoritairement humain. Le papier revendique aussi que le watermark est "radioactif" : il se transfère lors d'une distillation et permet de détecter qu'un élève a été entraîné sur les traces d'un professeur filigrané.

## 2. Méthode

Rappel Gumbel-max. À l'étape t, le PRF associe à chaque token candidat v une valeur R_v = PRF(v, w, K) dans [0,1], où w est la fenêtre des k derniers tokens et K la clé. Le token émis est

x_t = argmax_v R_v^(1/p_v^(t)),

ce qui est équivalent à un tirage Gumbel-max ou à une transformée inverse, et préserve exactement p^(t) en espérance sur la clé (proposition 1). Le détecteur recalcule R_t pour les tokens observés et agrège

S_T = - somme_{t=1..T} ln(1 - R_t).

Sous H0, S_T suit une Gamma(T,1), d'où une p-value exacte via la fonction gamma incomplète. Sous H1, l'espérance vérifie E[S_T] >= T + (pi²/6 - 1) H_T, où H_T est l'entropie du texte : la détectabilité croît avec l'entropie, ce qui motive la pondération.

Routage à deux clés. À chaque pas, une clé k(1) est choisie avec probabilité 1-alpha et k(2) avec probabilité alpha, alpha dans [0, 0.5], valeur par défaut alpha = 0.1. Le détecteur ne sait pas quelle clé a produit le token et fusionne tôt :

s_i = (1-alpha) s_i(1) + alpha s_i(2), avec s_i(j) = -ln(1 - R_i(j)).

Sous H0, s_i est une combinaison d'exponentielles de moyenne 1 et de variance theta_R = alpha² + (1-alpha)². La fusion précoce est comparée dans l'annexe C à Fisher et Bonferroni, et retenue empiriquement. Le routage double aussi la tolérance aux n-grammes répétés : première occurrence filigranée avec une clé, récurrence avec l'autre, repli non filigrané seulement à la troisième. Le papier n'applique pas le masquage des contextes répétés dans ses évaluations principales, sauf en E.1.

Pondération par entropie. Chaque score reçoit un poids

w_i^ent = 0.1 + 0.9 (H_i - H_min) / (H_max - H_min),

où H_i est l'entropie de la distribution du prochain token estimée par un modèle auxiliaire, normalisée dans la séquence. Le score devient S_combined = somme w_i^ent s_i. Comme la loi nulle est une somme pondérée d'exponentielles, les auteurs ajustent une Gamma par moments :

theta_new = theta_R * (somme w_i²) / (somme w_i), k_new = (somme w_i)² / (theta_R * somme w_i²).

La p-value est la queue de cette Gamma. La pondération est continue, contrairement aux méthodes qui filtrent les tokens de faible entropie.

Localisation. Le détecteur teste des fenêtres dyadiques de longueurs L0, 2L0, 4L0, etc., glissées avec un pas de L/2, soit environ M = 4n/L_min fenêtres, avec L_min = 50 par défaut. Une extraction gloutonne sélectionne la fenêtre la plus significative, masque ses tokens et recommence, jusqu'à Y_max = 5 zones. Trois tests sont mis en compétition (global, meilleure fenêtre unique, agrégation multi-zones) et une correction de Bonferroni plate k = 3 s'applique :

log10 p_final = min(log10 p_global, log10 p_single, log10 p_multi) + log10 3.

L'annotation fine des frontières (mIoU) est découplée de la détection : si H0 est rejetée, un lissage local par moyenne mobile pondérée marque les tokens.

## 3. Protocole expérimental

Modèle principal Qwen 3.5-27B, température 0.8, top-p 0.9, raisonnement désactivé, contexte de watermark k = 3. Données : 1 000 prompts ELI5, 5 graines, réponses tronquées à 400 tokens. Détection pondérée par l'entropie avec Qwen 3.5-0.8B, et variante 4 bits. Baselines : Gumbel-max et SynthID-Text profondeur 10, détecteur fréquentiste Z-test (le détecteur bayésien de SynthID est écarté : pas de contrôle du FPR, dépendance au domaine, incompatible avec la correction multi-tests, non reproductible selon les auteurs).

Calibration du FPR sur 1 million de passages Wikipédia non filigranés de 256 tokens. Évaluation humaine : 6 000 paires question-réponse (2 000 en anglais sur ELI5, 1 000 chacune en arabe, chinois, hindi, japonais sur CaLMQA), trois annotateurs par paire, vote majoritaire, test binomial bilatéral et procédure d'équivalence TOST avec une marge de 5%. Benchmarks : 12 tâches à température 0.6 et 1.0, top-p 0.95, budget de raisonnement 3 000 tokens. Localisation : 400 tokens filigranés insérés dans des textes Wikipédia jusqu'à 12 000 tokens, et découpés en K fragments dans un document de 8 000 tokens. Radioactivité : DeepSeek-R1-Distill-Qwen-14B comme professeur, Qwen2.5-3B comme élève, 5 000 problèmes OpenR1-Math-220k filtrés, LoRA, quatre schémas (Gumbel-max, TextSeal alpha = 0.1, SynthID profondeur 10, contrôle non filigrané). Le test de radioactivité utilise le teacher forcing, les prédictions top-1 de l'élève, et une double déduplication (une fenêtre par trace, puis les couples (contexte, token) globalement).

## 4. Résultats chiffrés

Détectabilité et diversité (section 4.2, figure 1a). TextSeal domine la frontière diversité-détectabilité face à SynthID ; utiliser le modèle 27B pour l'entropie ("TextSeal high") gagne 1 à 2 ordres de grandeur en médiane de -log10 p.

Qualité (tableau 1). À température 0.6, la moyenne sur 12 benchmarks est 70.6 avec et sans watermark. Les écarts par tâche restent dans le bruit, sauf le code : HumanEval 97.0 sans watermark contre 93.3 avec, MBPP 50.2 contre 49.2, soit une baisse de 1 à 4 points selon la tâche, attribuée à des omissions de format (imports manquants) et non à un échec algorithmique. À température 1.0, la moyenne est 69.1 avec watermark et 69.3 sans.

Évaluation humaine (tableau 2). Taux de préférence global pour le texte filigrané 50.9%, taux net +0.4%, p = 0.54, aucune langue significative après correction de Bonferroni (alpha/6 = 0.008). 79% des comparaisons sont des égalités. L'intervalle de confiance à 90% du taux net est [-0.6%, +1.4%], inclus dans [-5%, +5%] : l'équivalence est établie globalement et pour quatre langues sur cinq, l'arabe échouant marginalement (p = 0.06).

Dilution et fragmentation (section 4.5, figure 3). La détection globale décroche sous p = 0.01 vers 4 000 tokens ; l'ensemble adaptatif garde -log10 p > 4 à 12 000 tokens, soit 3.3% de texte filigrané et une dilution de 30 fois. En fragmentation, la détection reste bonne jusqu'à K = 3 fragments et se dégrade à K = 5, où chaque fragment fait environ 80 tokens.

Multilingue (section 5.3). GPT-OSS-20B, 6 000 paires : 63.3% de TPR à 0.1% de FPR globalement ; pas de différence significative sur les refus (p = 0.41) ni sur la cohérence d'écriture (p = 0.21). Les tokens de raisonnement augmentent d'environ 16% en moyenne, attribué à la variance d'échantillonnage.

Coût (tableaux 4 et figure 6). Surcoût d'échantillonnage 0.1 à 0.3% (0.43 ms contre 0.37 ms par token sur Qwen 3.5-0.8B ; 0.46 contre 0.39 sur 27B), contre 0.60 à 0.63 ms pour SynthID. Détection non pondérée 0.007 ms/token et 0 Go de VRAM, médiane -log10 p = 4.8 ; pondération par le 27B : 8.2 mais 50.1 Go et 0.213 ms/token ; modèle 0.8B en 4 bits : 6.2, 1.4 Go et 0.115 ms/token. Le décodage spéculatif MTP conserve un taux d'acceptation de 29 à 46% avec et sans watermark, et une perplexité identique.

Radioactivité (tableau 5, figure 8). TextSeal retient 2 352 traces (47.0% de taux de passage), contre 1 991 pour Gumbel-max (39.8%), 2 408 pour SynthID (48.2%) et 2 400 pour le contrôle (48.0%). La puissance de détection sur les traces du professeur est -log10 p = 33.15 pour TextSeal (score pondéré par l'entropie), 14.89 pour Gumbel-max, 14.39 pour SynthID, 0.39 pour le contrôle. Précision GSM8K de l'élève : 79.9% (TextSeal), 78.8% (Gumbel-max), 75.2% (SynthID), 75.5% (contrôle), contre 64.5% pour le modèle de base, soit +10 à +15 points. La pondération concave sqrt(H) donne p = 3.7 x 10^-110 contre 2.1 x 10^-84 pour la pondération uniforme, soit plus de 25 ordres de grandeur.

## 5. Ce que le papier ne donne pas

Le détail des nombres premiers et des constantes du PRF n'est pas fourni (seule la structure du hash est donnée, annexe A.1), donc une réimplémentation exacte doit deviner les constantes ou reprendre le code. Les hyperparamètres de localisation sont partiellement donnés (L_min = 50, Y_max = 5), mais pas les seuils tau de l'annotation mIoU ni le coût CPU exact de la recherche de couverture. La robustesse aux paraphrases n'est traitée que qualitativement dans la figure 6, sans tableau d'ASR par attaque. Le papier ne donne pas de FPR empirique au-delà de 10^-4 pour toutes les variantes, ni de courbe TPR à très bas FPR. La section limitations est très courte : elle ne parle que de la perte de diversité, et pas des attaques par réécriture, du vol de watermark, ni du coût de la détection localisée. Les résultats MTP portent sur le décodage spéculatif MTP de Qwen 3.5, pas sur un couple draft/target standard. Enfin, les résultats de radioactivité dépendent du volume de traces retenues, et le papier le reconnaît : à volume égal, Gumbel-max a un meilleur signal par token.

## 6. Ce qu'un participant peut en tirer

Le papier est directement exploitable : code public, test Gamma exact, PRF simple, paramètres par défaut clairs (k = 3, alpha = 0.1). Pour une épreuve de 24 h, les points d'entrée les plus rentables sont la pondération par entropie (gain de plusieurs ordres de grandeur pour un coût de proxy modeste) et la détection localisée, qui transforme un échec sur document dilué en détection confiante sans changer l'embedding. La faiblesse à exploiter côté attaque est la sensibilité à la paraphrase et au remplacement de mots, mentionnée mais non chiffrée : c'est un espace de travail immédiat. Le test de radioactivité, avec sa double déduplication, est aussi un bon point de départ pour une épreuve de détection de distillation.
