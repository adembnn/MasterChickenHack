# The Stable Signature: Rooting Watermarks in Latent Diffusion Models (arXiv 2303.15435v2)

## 1. Problème et revendications

Le point de départ est un constat sur les deux familles existantes. La détection passive, qui consiste à reconnaître une image générée par des artefacts statistiques, a un taux de faux positifs trop élevé pour un usage probatoire. Le watermarking a posteriori, qui marque l'image après génération, dégrade la qualité et reste vulnérable aux attaques qui ciblent l'extracteur. Les auteurs (Pierre Fernandez, Guillaume Couairon, Hervé Jégou, Matthijs Douze, Teddy Furon, Meta AI et Inria) proposent d'inscrire le watermark dans la génération elle-même, en ajustant le décodeur du modèle de diffusion latent pour que toute image produite porte une signature binaire donnée.

Deux tâches sont distinguées, ce qui rend le papier utile pour un concours d'attribution. La détection répond à « cette image a-t-elle été générée par mon modèle ? », l'identification à « lequel des N modèles a généré cette image ? ». Le même test statistique sert aux deux, mais le second paie un prix en faux positifs qui croît avec N, dont la formule exacte est donnée.

Les revendications sont les suivantes : une méthode qui n'ajoute aucun coût à l'inférence (le watermark est produit par le décodeur, pas par un réseau séparé), une qualité d'image quasi inchangée (FID), une robustesse comparable aux méthodes a posteriori, et surtout des garanties statistiques propres grâce à la décorrélation des bits extraits. Ce dernier point est un apport théorique souvent négligé : sans blanchiment, les bits extraits d'une image non marquée sont biaisés et corrélés, ce qui invalide le calcul du FPR par la loi binomiale.

## 2. Méthode, équations, hyperparamètres réellement donnés

La méthode se déroule en deux phases.

Phase 1, pré-entraînement de l'extracteur. On utilise HiDDeN, avec un encodeur $W_E$ et un extracteur $W$. L'encodeur prend une image $x_o \in \mathbb{R}^{W \times H \times 3}$ et un message $m \in \{0,1\}^k$, et produit un résidu $\delta$ de même taille, multiplié par un facteur $\alpha$ : $x_w = x_o + \alpha \delta$. À chaque pas d'optimisation, une transformation $T$ est tirée dans un ensemble $\mathcal{T}$ qui contient recadrage et compression JPEG. Un message « soft » est extrait de l'image transformée, $m' = W(T(x_w))$, et la perte est l'entropie croisée binaire entre $m$ et $\sigma(m')$ :
$$L_m = -\sum_{i=1}^{k} m_i \log \sigma(m'_i) + (1-m_i)\log(1-\sigma(m'_i)).$$
Deux modifications par rapport à HiDDeN sont détaillées. D'abord, comme $W_E$ est jeté après cette phase, la qualité perceptuelle de son résidu n'a pas d'importance : la perte perceptuelle et le réseau adversarial sont supprimés, la distorsion est bornée par une tanh en sortie et par $\alpha$. Cela améliore l'exactitude des bits et permet d'augmenter $k$. Ensuite, les bits sortis par $W$ sur des images naturelles sont corrélés et fortement biaisés, ce qui viole l'hypothèse d'indépendance du test statistique. Une transformation de blanchiment PCA est donc appliquée aux sorties de $W$.

Les paramètres de cette phase sont donnés précisément : $k = 48$ bits, images $256 \times 256$, 300 epochs sur 8 GPU, optimiseur Lamb, learning rate avec warmup linéaire de 5 epochs jusqu'à $10^{-2}$ puis décroissance cosinus jusqu'à $10^{-6}$, batch de 64 par GPU. L'entraînement prend environ une journée.

Phase 2, fine-tuning du décodeur. Dans un LDM, la diffusion se fait dans l'espace latent d'un autoencodeur. Le vecteur latent $z$ sorti de la diffusion entre dans le décodeur $D$ qui produit l'image. On ajuste $D$ en $D_m$ pour que l'image contienne une signature fixée $m$ extractible par $W$. L'image $x$ est encodée en $z = E(x)$, le décodeur reconstruit $x' = D_m(z)$, et l'extracteur récupère $m' = W(x')$. La perte de message est $L_m = BCE(\sigma(m'), m)$. Le décodeur original $D$ reconstruit la même image sans watermark, $x'_o = D(z)$, et la perte perceptuelle $L_i$ entre $x'$ et $x'_o$ contrôle la distorsion. On utilise la perte perceptuelle Watson-VGG, présentée comme une version améliorée de LPIPS, qui apprend le masquage de luminance et de contraste. L'objectif total est
$$L = L_m + \lambda_i L_i.$$
Le fine-tuning dure 100 itérations avec AdamW, batch de 4, soit moins de 500 images vues, et prend une minute sur un seul GPU. Le learning rate suit un cosinus avec 20 itérations de warmup jusqu'à $10^{-4}$ puis décroissance à $10^{-6}$. $\lambda_i = 2.0$ par défaut. Le point important pour un hackathon : cette phase ne touche que le décodeur, donc elle est compatible avec toutes les tâches du modèle (texte-image, édition, inpainting, super-résolution) sans réentraîner la diffusion.

Le test statistique. Soit $m \in \{0,1\}^k$ la signature. On extrait $m'$ et on compte les bits concordants $M(m,m')$. L'image est déclarée générée par le modèle si $M(m,m') \geq \tau$. Sous $H_0$, les bits $m'_i$ sont supposés i.i.d. de Bernoulli 0,5, donc $M$ suit une binomiale $(k, 0.5)$ et le taux de faux positifs s'écrit avec la fonction bêta incomplète régularisée :
$$FPR(\tau) = P(M > \tau \mid H_0) = I_{1/2}(\tau+1, k-\tau).$$
Pour l'identification parmi $N$ modèles, il y a $N$ hypothèses à tester, et le FPR global devient
$$FPR(\tau, N) = 1 - (1-FPR(\tau))^N \approx N \cdot FPR(\tau).$$
Ces formules sont utilisées à l'envers : on choisit $\tau$ pour atteindre un FPR cible. Le papier insiste sur le fait qu'elles ne valent que si les bits sont i.i.d., d'où le blanchiment PCA, validé expérimentalement en annexe.

## 3. Protocole et métriques

Les évaluations portent sur des prompts de validation MS-COCO. Cinq tâches sont considérées : texte-image avec un LDM de 2,2 milliards de paramètres entraîné sur un jeu interne de 330 millions de paires image-texte, édition d'image avec DiffEdit, inpainting avec GLIDE (version complète et version masque seul), super-résolution avec LDM. Les images sont en $512 \times 512$ et les signatures de 48 bits.

Pour la qualité : FID sur 5 000 images, et PSNR / SSIM entre les images du générateur original et celles du générateur watermarké. Le PSNR autour de 30 dB ne se compare pas aux 40 dB d'une méthode a posteriori : il mesure l'écart entre deux générations, pas entre une image et sa version marquée. Les auteurs le disent explicitement.

Pour la détection : courbe TPR/FPR en faisant varier $\tau$ de 0 à 48, sur 1 000 images et 10 signatures aléatoires. Le TPR est mesuré directement, le FPR est calculé par la formule (2) car il serait trop petit pour être mesuré sur un jeu raisonnable, approximation validée en annexe. Pour l'identification : proportion d'utilisateurs correctement identifiés, avec un FPR de $10^{-6}$, et une erreur comptée si l'image n'est même pas détectée.

Transformations évaluées : recadrage fort (10 % de l'image restante), luminosité facteur 2,0, et une combinaison recadrage 50 %, luminosité 1,5, JPEG 80. Le tableau 2 ajoute JPEG 50, contraste 2,0, saturation 2,0, netteté 2,0, filtre médian $k=7$, redimensionnement 0,7, et incrustation de texte.

## 4. Résultats chiffrés

Qualité (tableau 1). En texte-image, le LDM watermarké a un PSNR de 30,0 dB et un SSIM de 0,89 par rapport au LDM original, avec un FID de 19,6, soit 0,3 de moins que l'original. En édition DiffEdit, 31,2 dB et 0,92, FID 15,0 (−0,3). En inpainting complet avec GLIDE, 31,1 dB et 0,91, FID 16,8 (+0,6). En super-résolution, 34,0 dB et 0,94, FID 11,6 (+0,0). Le watermark ne dégrade donc pas le FID, et l'améliore même légèrement dans deux cas.

Robustesse (tableau 1, colonnes d'exactitude des bits). Texte-image : 0,99 sans transformation, 0,95 après recadrage, 0,97 après luminosité, 0,92 après la combinaison. Inpainting masque seul : 0,89, 0,76, 0,84, 0,78. Super-résolution : 0,98, 0,93, 0,96, 0,92. Le tableau 2 donne, sur COCO : JPEG 50 à 0,88, redimensionnement 0,7 à 0,91, filtre médian $k=7$ à 0,94, contraste 2,0 à 0,98, saturation 2,0 à 0,99, netteté 2,0 à 0,99, incrustation de texte à 0,99. L'exactitude reste au-dessus de 0,9 partout sauf en inpainting et en JPEG 50.

Détection (section 5.1, figure 3). Sans transformation, 99 % des images générées sont détectées pour un FPR de $10^{-9}$, c'est-à-dire une image naturelle sur un milliard. Au même FPR, 84 % des images sont détectées après un recadrage qui ne garde que 10 % de l'image, et 65 % après la combinaison recadrage, décalage de couleur et JPEG.

Compromis qualité / robustesse (tableau 3). En faisant varier $\lambda_i$ : 0,8 donne 31,4 dB et 0,85 d'exactitude sur la combinaison ; 0,4 donne 30,6 dB et 0,88 ; 0,2 donne 29,7 dB et 0,90 ; 0,1 donne 28,5 dB et 0,92 ; 0,05 donne 26,8 dB et 0,94 ; 0,025 donne 24,6 dB et 0,95. Le levier est donc direct et monotone.

Rôle de la couche de simulation d'attaques au pré-entraînement (tableau 4). Sans elle, l'extracteur reste robuste au recadrage (1,00) et à la luminosité (0,99) mais s'effondre sur la rotation 90° (0,56), JPEG 50 (0,50) et le redimensionnement 0,7 (0,48). Avec elle, on obtient 0,99, 0,90 et 0,91. C'est une information directement exploitable : les transformations non vues à l'entraînement ne sont pas couvertes.

Attaques (section 7). Contre les autoencodeurs neuronaux, il faut descendre sous 26 dB de PSNR pour ramener l'exactitude vers 50 %. Mais si l'attaquant connaît l'autoencodeur utilisé par le LDM (KL-f8), l'effacement devient efficace à PSNR supérieur à 29 dB. En boîte blanche, une attaque adverse sur l'image fonctionne aussi avec un budget plus faible.

## 5. Ce qui manque

Le papier ne donne pas de localisation : le watermark est global par construction, et une zone recadrée à 10 % reste décodable mais aucune carte spatiale n'est produite. La capacité est fixée à 48 bits. Le fine-tuning exige l'accès au décodeur, indisponible pour un modèle fermé. La qualité est mesurée par rapport à une autre génération, donc les PSNR ne sont pas comparables à ceux du watermarking a posteriori. Enfin, la robustesse géométrique dépend entièrement des transformations vues au pré-entraînement.

## 6. Usage concret en hackathon 24 h

Pour l'épreuve d'attribution, c'est le papier qui donne la mathématique exacte du vote majoritaire : $k = 48$, $FPR(\tau) = I_{1/2}(\tau+1, k-\tau)$, et $FPR \approx N \cdot FPR(\tau)$ pour $N$ modèles. Avec 48 bits et un seuil à 40 bits concordants, on obtient un FPR par paire très faible, ce qui permet de calibrer un classifieur à trois classes sans collecter des millions d'images de fond.

Le second point est le tableau 4 : l'extracteur n'est pas robuste à ce qu'il n'a pas vu, une rotation de 90° ou un redimensionnement à 0,7 faisant tomber l'exactitude à 0,50 et 0,48. Pour tromper un détecteur, c'est l'attaque la moins chère en PSNR : chercher la transformation hors distribution plutôt que perturber les pixels.

Troisième point : la phase 2 coûte une minute sur un GPU pour 100 itérations. Si le concours fournit un décodeur de diffusion ouvert, on peut watermarker un modèle complet pendant la nuit et produire un jeu d'images étiquetées pour entraîner ou valider son propre détecteur.
