# Indexation active d'images (arXiv 2210.10620)

Fernandez, Douze, Jegou, Furon, « Active Image Indexing », v1 du 5 octobre 2022 (WACV 2023). Texte integral lu, version HTML arXiv (76 150 caracteres, 2276 lignes).

## 1. Probleme et revendications

La detection de copies a grande echelle (copyright, contenus reutilises, images de synthese) repose sur deux briques : un descripteur profond et un index approximatif. L'index approximatif, typiquement IVF-PQ, est indispensable (il divise le temps de recherche par 500 et la taille par 256 dans les experiences), mais il introduit deux sources d'echec : la quantification produit (PQ) deforme les distances, et le partitionnement grossier (IVF) fait tomber une image transformee dans un autre bucket, donc elle n'est meme pas examinee.

L'idee est de deplacer le probleme du cote de l'image : au lieu d'ameliorer l'index, on modifie imperceptiblement l'image au moment de l'indexation pour que sa representation tombe au centre de sa cellule de quantification. Les auteurs appellent cela « activer » une image, par analogie avec le watermarking actif de la litterature (embedder plutot que detecter).

Revendications : (i) une optimisation de l'image, par descente de gradient a travers l'extracteur, qui minimise la distance entre representation et version quantifiee de la representation originale ; (ii) une attenuation perceptuelle par carte JND plutot qu'une boule l1 ou linf ; (iii) une compatibilite totale avec l'index existant, qui peut contenir images actives et passives sans distinction ; (iv) une analyse qui separe l'effet PQ de l'effet IVF, et des gains mesures sur DISC21.

C'est le papier le plus « attaque » du lot : la methode est exactement une perturbation adversarial optimisee, sauf que la cible est la sortie du quantifieur et non une classe.

## 2. Methode, equations

Index IVF-PQ : q_c est le quantifieur grossier (k-means), q_f le quantifieur produit sur les residus, et un vecteur x est approxime par q(x) = q_c(x) + q_f(x - q_c(x)).

On cherche une image I proche de I_o dont la representation x = f(I) est proche de q(x_o), ou x_o = f(I_o). Le probleme d'optimisation est resolu par descente de gradient, en remontant jusqu'aux pixels, comme pour generer une exemple adversarial. Deux termes :

L_f(x, q(x_o)) = || x - q(x_o) ||^2 (perte d'indexation, dans l'espace des representations)
L_i(I, I_o) = || I - I_o ||^2 (regularisation de distorsion, dans l'espace image)
L(I; I_o) = L_f + lambda L_i

Le point important : la cible q(x_o) est calculee une fois sur l'image originale, donc l'index continue de stocker la representation originale. L'image activee ressemble a l'originale mais son descripteur est celui de la version quantifiee. Formellement, pour deux images I, J et une version activee J*, avec representations x, y, y*, on a || q(y*) - x || = || q(y) - x || : l'index est aveugle au changement J vers J*. D'ou la compatibilite : on peut activer un sous-ensemble seulement, ou activer des images deja indexees.

Attenuation perceptuelle. Plutot que de borner la perturbation par une norme, on optimise delta et on l'applique via une carte JND (just noticeable difference) qui tient compte de la luminance et du masquage de contraste, et qui repondere par canal (l'oeil est plus sensible au rouge et au vert qu'au bleu) :

I = I_o + alpha . H_JND(I_o) ⊙ tanh(delta)

avec alpha un facteur global d'intensite et ⊙ le produit terme a terme. Le tanh borne la perturbation, le JND la repartit la ou elle se voit le moins.

Analyse. Section 4.1 : || x_hat - q(x) ||^2 = || x - q(x) ||^2 + || x_hat - x ||^2 + 2 (x - q(x))^T (x_hat - x). L'activation reduit le premier terme, donc la moyenne, au prix d'une variance plus forte (le troisieme terme croise). L'article montre empiriquement que la baisse de moyenne compense la hausse de variance. Section 4.2 : en recherche a une seule sonde, le rappel est borne par 1 - p_f, ou p_f = P(q_c(x) != q_c(x_hat)) ; l'activation abaisse p_f, et le decrochage brutal du rappel passe de R = 0,13 a R = 0,32.

Hyperparametres : Adam, learning rate 1, N = 10 iterations, lambda = 1, alpha = 3 (PSNR moyen autour de 43 dB). Cout : environ 40 ms par image sans EOT et 870 ms avec EOT (augmentation de donnees pour rendre l'activation robuste), soit 6 s pour 128 images sur un GPU de 32 Go.

## 3. Protocole et metriques

Dataset : DISC21, 1M images de reference, 50k requetes dont 10k vraies copies, plus 1M images disjointes pour entrainer l'index. Les requetes sont generees par les auteurs (transformations controlees : contraste 0,5 et 2,0, luminosite 0,5 et 2,0, teinte 0,2, flou 2,0, JPEG 50, rotation 25 et 90 degres, combinaisons aleatoires) parce que les transformations originales de DISC21 ont ete faites a la main et ne sont pas reproductibles.

Descripteur : SSCD, tronc ResNet50, image 288x288, representation normalisee dans R^512. Index : IVF4096, PQ8x8 (8 sous-quantifieurs de 256 centroids), une seule sonde (k' = 1), volontairement agressif pour rendre l'effet visible ; variante IVF-PQ† (IVF512, PQ32x8, k' = 32) pour un reglage moins approximatif.

Metriques : R@1 (proportion de requetes positives dont le top-1 est la bonne image), et pour la detection de copies le protocole de l'Image Similarity Challenge (10 plus proches voisins, seuil tau, precision, rappel, muAP sur 10k positifs et 40k negatifs). Qualite image : PSNR, SSIM, norme linf.

Generalisation (section 5.4) : meme protocole avec d'autres extracteurs, ResNext101 entraine par SSCD, Lyakaap-dt1 (EfficientNetv2, gagnant de la piste descripteur du NeurIPS ISC), DINO ResNet50 et DINO ViT-S.

## 4. Resultats chiffres

Effet principal (Table 1, section 5.2) : jusqu'a +60 points de R@1 pour des changements forts de luminosite et de contraste, en se rapprochant des resultats de la recherche exhaustive (brute force). L'IVF-PQ actif avec k' = 1 atteint environ les performances de l'IVF-PQ passif avec k' = 16, donc on peut chercher 16 fois moins de cellules a performance egale.

Detection de copies (section 5.2, figure 3) : muAP multiplie par 2 en moyenne avec l'indexation active. La detection reste loin du brute force, ce que les auteurs expliquent par l'approximation du partitionnement (section 4.2).

Compromis qualite (section 5.3) : a PSNR 30 dB, le muAP est triple par rapport au cas passif. A alpha = 3, PSNR = 43,8 plus ou moins 2,2 dB, SSIM = 0,98 plus ou moins 0,01, linf = 14,5 plus ou moins 1,2 (mesures sur 10k images). C'est une perturbation visible a l'oeil exerce mais acceptable en flux social.

Generalisation (Table 2, section 5.4) : R@1 meilleur pour les images activees sur toutes les transformations et tous les reseaux. Gain moyen de +12 % pour DINO ViT-S a +30 % pour SSCD ResNet50.

Cout et autres structures (Table 3) : 0,32 ms par requete pour un IVF 1024, avec R@1 moyen de 0,47 a 0,83 et muAP de 0,16 a 0,43 ; OPQ 8x8 a 5,71 ms, 0,92 a 0,94 et 0,48 a 0,55 ; PCA64 plus LSH a 0,99 ms, 0,72 a 0,83 et 0,25 a 0,39. Le gain est donc plus fort sur le partitionnement que sur la quantification, ce que les auteurs attendaient.

## 5. Ce qui manque

L'evaluation de la qualite est purement metrique. PSNR 43,8 dB et SSIM 0,98 ne disent rien de la perception : une perturbation structuree qui suit le contenu peut etre tres visible sur les zones planes, et l'article renvoie a ses annexes sans etude utilisateur. Pour un systeme qui modifie les images des utilisateurs, c'est la lacune la plus genante.

La methode est fragile a une deuxieme transformation. L'activation stabilise l'image contre les transformations connues au moment de l'optimisation, mais rien ne dit ce qui se passe si l'image est ensuite recadree, recompressee, ou repostee plusieurs fois. Or c'est le cas d'usage reel (l'image activee est ensuite editee par un utilisateur).

Rien sur les attaques adversariales conscientes : la perturbation etant calculee avec le descripteur, un attaquant qui connait le modele peut optimiser dans l'autre sens (eloigner la representation du centroide) et casser l'indexation active sans que cela se voie.

Le cadre est blanc boite : il faut l'extracteur et l'index pour activer. Cela suppose que la plateforme maitrise toute la chaine, ce qui est realiste pour un reseau social mais exclut le cas « detecter une copie d'une image dont on n'a pas active l'original ».

Enfin, un seul dataset (DISC21) et une seule famille de transformations ; pas de visages, pas de documents, pas de captures d'ecran, qui sont les contenus problematiques en pratique.

## 6. Usage concret en hackathon 24 h

La boucle est courte et le code est conceptuellement trois lignes : charger un descripteur, calculer q(x_o), optimiser l'image, reindexer. En 24 h, on peut faire une demo « indexation active contre attaques sociales » sur 5k images et 20 transformations, avec deux courbes R@1 et un compteur de PSNR. C'est un projet complet, mesurable, sans entrainement.

Deuxieme usage, plus dans l'esprit du hackathon watermarking : traiter l'indexation active comme un watermarking zero-bit d'un genre particulier, et tester sa robustesse aux attaques du papier log-normal (meme equipe, 2409.15119). La question « combien d'iterations de mutation pour faire sortir l'image de son bucket » est ouverte et se mesure en quelques heures.

Troisieme usage, defensif : construire un detecteur d'images activees. Si une plateforme active les images a son insu, la perturbation laisse une signature statistique dans les hautes frequences (le JND suit le contenu). Un petit classifieur sur residus pourrait la reveler, et personne ne l'a publie.
