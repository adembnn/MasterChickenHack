# Watermark Basins : détection en boîte noire d'un LLM distillé

Papier arXiv 2610.37266. Aucune URL de code n'apparaît dans le texte lu.

## 1. Problème posé et revendications

Un professeur filigrané transmet son watermark à un élève par distillation, même quand l'élève ne voit que du texte et ne partage ni tokenizer ni vocabulaire. Le détecteur du professeur ne s'applique pas à l'élève. Les auteurs posent donc la question : peut-on décider, en boîte noire, si un modèle donné a été distillé à partir d'un professeur filigrané, sans entraîner de classifieur supervisé et sans connaître l'architecture de l'élève ?

Le papier commence par un résultat négatif : les détecteurs au niveau du token, du type TextSeal, s'effondrent quand on change de modèle ou de température. Leur puissance vient des tokens rares, précisément ceux qu'un élève ne reproduit pas. Les fenêtres de n tokens règlent la calibration mais diluent le signal : à n = 3, la détection tombe à 1.3% de TPR à 0.1% de FPR.

La revendication centrale est qu'il existe un invariant de distillation plus large que les tokens individuels, qu'ils appellent bassin de watermark : la région de l'espace des paramètres où un modèle porte encore la trace du professeur. Ils proposent de l'exploiter par une signature de gradient et un test de rang, et revendiquent la première détection en boîte noire d'un élève distillé à partir d'un professeur filigrané, sur 24 architectures et 1 200 modèles élèves.

## 2. Méthode

Signature de gradient. Soit Delta_total la différence de paramètres entre le modèle à tester et le modèle de référence non distillé. Cette différence contient à la fois l'effet de la tâche de distillation et l'effet du watermark, noyés ensemble. Les auteurs définissent

Delta_wm = Delta_total - proj_{Tâche}(Delta_total),

où proj_{Tâche} est la projection sur le sous-espace engendré par les directions de gradient de la tâche de distillation, estimées sur un modèle propre. Autrement dit, on retire du delta la composante explicable par la tâche, et on espère que ce qui reste est la composante watermark. La signature est le cosinus entre ce résidu et une direction de référence calculée à partir de plusieurs modèles connus comme distillés du professeur filigrané :

S(k) = cos( Delta_wm(modèle testé), direction de référence(k) ).

Projection aléatoire. Les gradients vivent en très grande dimension. Les auteurs projettent les delta par une projection aléatoire fixe de dimension d = 8192, qui préserve les produits scalaires en espérance (Johnson-Lindenstrauss). Ils retirent ensuite les q = 100 premières composantes principales estimées sur un pool de 43 checkpoints propres, pour éliminer les directions dominantes partagées et ne garder que la variabilité fine.

Sonde. Pour obtenir un gradient propre sans contaminer la mesure, ils utilisent un modèle sonde : Qwen2.5-3B, réchauffé par LoRA sur les données de distillation, puis nettoyé. Le gradient est g = nabla_theta log p(y | x) moyenné sur un ensemble de prompts de construction (512 prompts). La direction de référence est la moyenne des signatures de plusieurs élèves connus, et le score d'un modèle testé est comparé à celui de M = 999 leurres, c'est-à-dire des modèles distillés d'un professeur non filigrané ou entraînés sur la même tâche sans watermark.

Test de rang. La p-value est purement non paramétrique :

p = (1 + #{j : S(k_j) >= S(k*)}) / (M + 1),

avec M = 999 leurres, ce qui donne une granularité de 10^-3 et permet de viser un FPR de 0.1%. Aucune hypothèse distributionnelle n'est faite sur S : la queue de la distribution des scores n'a pas besoin d'être gaussienne, et le test reste valide même si les leurres sont corrélés entre eux, au prix d'une perte de puissance.

Pourquoi cela devrait marcher. Le watermark agirait comme un biais systématique sur les gradients, partagé par tous les élèves, alors que la tâche impose des directions différentes selon l'architecture. Le papier ne prouve pas que ce résidu est identifiable en général ; il le mesure.

## 3. Protocole expérimental

Professeur : DeepSeek-R1-Distill-Qwen-14B, filigrané avec TextSeal, alpha = 0.1. Données de distillation : 1 900 traces de raisonnement OpenR1-Math, générées par le professeur. Élèves : Qwen2.5-3B, entraîné par LoRA sur ces traces, avec 24 architectures différentes (profondeur, largeur, rang LoRA, schéma d'attention) et 50 modèles par architecture, soit 1 200 modèles élèves. Les leurres sont des modèles de la même famille, distillés sur la même tâche à partir d'un professeur non filigrané, ou entraînés sans watermark.

Évaluation : 1 900 prompts de test, premiers 512 tokens de chaque réponse, soit environ 1 million de tokens par modèle. Les prompts de construction sont 512 prompts distincts, pour éviter que la sonde ne voie les prompts de test. Les modèles de référence pour la direction sont des élèves dont le statut est connu à l'avance. Métrique principale : TPR à FPR de 5%, 1% et 0.1%, pour n = 1 et n = 3 (n étant le nombre de fenêtres ou de blocs agrégés). La construction exacte de l'agrégation à n = 3 n'est pas détaillée.

Comparaisons : détecteur au niveau du token (TextSeal), détecteur par fenêtres de n tokens, et le test de rang proposé. Le papier évalue aussi la robustesse à la température d'échantillonnage, au schéma de watermark du professeur, au domaine, à la fraction de données filigranées, au rang LoRA, au nombre d'époques, à la compression, au schéma d'alignement (SFT, GRPO), et à la paraphrase du texte d'entraînement.

## 4. Résultats chiffrés

Effondrement du détecteur token. À FPR de 0.1%, le test de rang détecte 79% des élèves à n = 1 et 45% à n = 3, contre 29% (détecteur token) et 1.3% (détecteur par fenêtres) pour la baseline : le détecteur naïf perd l'essentiel de sa puissance dès qu'on agrège, alors que le test de rang résiste.

Température (tableau 2). À T = 0.5, le test de rang signale encore tous les suspects à n = 1 et environ la moitié à n = 3 pour p <= 0.01, alors que la baseline black-box perd l'essentiel de sa puissance à toutes les fenêtres. La température règle ce que révèlent les tokens, pas ce que révèle le gradient.

Détection du professeur (tableau 3). Sur les professeurs eux-mêmes, le test atteint 96 à 100% de TPR à 5% de FPR, ce qui valide que la signature existe bien chez le modèle source.

Schéma de watermark (tableaux 6 et 7). Le test atteint 100% de TPR à 5% de FPR et n = 1 pour tous les schémas testés (TextSeal, Gumbel-max, SynthID-Text, Maryland) : la signature ne serait pas spécifique à TextSeal mais à la présence d'un biais de génération.

Domaine (tableau 5). Les trois domaines mathématiques restent classés au-dessus des deux domaines non mathématiques dans chaque cellule ; au seuil le plus strict, le TPR tombe à 0 ou 1% en code et en chat. La détection dépend donc de la proximité entre données de distillation et données de test.

Fraction de données filigranées (tableau 8). À 10% de traces filigranées, le TPR est au niveau du hasard ; il dépasse 90% à 75%. La relation est monotone, ce qui donne une lecture directe du taux de contamination.

Rang LoRA et époques (tableaux 9 et 10). À rang 16 le TPR n'est que de 16% ; à rang 512 il atteint 100% (à 1% de FPR). Une seule époque suffit à 78% de TPR (à 1% de FPR), ce qui indique que le signal s'installe vite mais que la capacité du modèle conditionne sa détectabilité.

Compression (tableau 6). Seuls int8 et l'élagage à 10% laissent un modèle utilisable, et les deux coûtent au plus 3 points de TPR. int4 et l'élagage à 30% rendent le modèle inutilisable, avec une précision GSM8K sous 0.9 fois celle du modèle non compressé (70.7) : le papier y voit une destruction du bassin, pas un échec du test.

Alignement (tableau 7). GRPO préserve 100% de TPR sur tous les bras à 5% de FPR et à toutes les fenêtres. Le SFT continu fait tomber le TPR à 0 à 6% selon les bras et les fenêtres : un simple SFT affaiblit fortement la signature observable dans les sorties, sans nécessairement sortir le modèle du bassin.

Géométrie (tableau 17). La composante de la variation de poids le long de la direction watermark atteint au plus 5.3% de sa longueur sous SFT et 0.0% sous chaque bras GRPO. La différence de détectabilité vient donc de la direction du déplacement, pas de son amplitude.

Calibration (tableau 11). Sur les leurres, la p-value du modèle médian est de 4.3% à un seuil nominal de 5%, le 90e percentile est à 9.9%, et le pire cas observé entre 23.4% et 26.2%, avec un plancher de 13.5%. Le test est donc anti-conservateur sur les leurres : à 5% nominal, le FPR réel peut être plus élevé, ce qui est cohérent avec la granularité de 10^-3 et la corrélation entre leurres.

Paraphrase (tableau 19). À n = 3, une paraphrase légère laisse 90%, 70% et 25% de TPR aux FPR de 5%, 1% et 0.1% ; une paraphrase modérée tombe à 5%, 0% et 0% ; une paraphrase agressive donne 0%. Le bassin survit à un bruit lexical léger, pas à une réécriture.

## 5. Ce que le papier ne donne pas

Le coût de calcul n'est jamais quantifié : le texte dit seulement que la procédure est dominée par la génération des traces du professeur et l'entraînement des 1 200 élèves, sans chiffre de temps ni de GPU. Aucune URL de code n'est fournie : la reproductibilité dépend d'une réimplémentation. Les détails de la sonde (étapes LoRA, taux d'apprentissage, jeu de nettoyage, gradient moyenné) sont renvoyés à l'annexe C.6, non lue intégralement ; il ne faut donc pas les supposer. Il n'y a pas de section limitations séparée, mais une section "Scope and outlook" où les limites sont dispersées. Le FPR empirique sur des modèles réellement non distillés n'est pas rapporté séparément de la calibration sur leurres. Enfin, la défense contre un attaquant qui paraphraserait ou distillerait volontairement pour effacer la signature n'est pas étudiée au-delà de la paraphrase des données.

## 6. Ce qu'un participant peut en tirer

Pour une épreuve de 24 h, le test de rang est la brique la plus rentable : aucun classifieur à entraîner, seulement un score par modèle candidat et 999 leurres, calculable en quelques secondes une fois les signatures obtenues. Le point dur est la sonde : sans modèle propre pour estimer les directions de tâche, la signature est contaminée. Trois leviers donnent des expériences d'attaque et de défense à coût raisonnable : la fraction de données filigranées (hasard à 10%, plus de 90% à 75%), le rang LoRA (16% à rang 16, 100% à rang 512) et le SFT de raisonnement (0 à 6% de détection).
